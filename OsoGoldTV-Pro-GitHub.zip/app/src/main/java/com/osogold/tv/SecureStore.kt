package com.osogold.tv

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * AES-256 encrypted storage (AndroidX Security: keys are AES-256-SIV, values AES-256-GCM, the master
 * key lives in the Android Keystore). Used for the subscriptions, the proxy and every API key.
 */
object SecureStore {

    private const val FILE = "oso_secure_prefs"

    @Volatile
    private var cached: SharedPreferences? = null

    fun prefs(context: Context): SharedPreferences {
        cached?.let { return it }
        synchronized(this) {
            cached?.let { return it }
            val app = context.applicationContext
            val created = try {
                create(app)
            } catch (_: Exception) {
                // a damaged keystore: start again with a clean encrypted file
                try {
                    app.deleteSharedPreferences(FILE)
                    create(app)
                } catch (_: Exception) {
                    app.getSharedPreferences(FILE + "_fallback", Context.MODE_PRIVATE)
                }
            }
            cached = created
            return created
        }
    }

    private fun create(app: Context): SharedPreferences {
        val master = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        return EncryptedSharedPreferences.create(
            app,
            FILE,
            master,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }
}
