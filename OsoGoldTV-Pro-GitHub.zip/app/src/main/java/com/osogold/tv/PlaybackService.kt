package com.osogold.tv

import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Owns the ExoPlayer (Media3). Because the player lives in a MediaSessionService it keeps playing
 * Quran / radio / streams in the background and with the screen locked (media notification).
 *
 * Supported formats (HLS m3u8 + TS, DASH mpd, MP4, MKV, MP3, AAC ...) are detected automatically.
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        instance = this

        // The User-Agent comes from Settings and is read for every new connection.
        val dataSourceFactory = NetConfig.dataSourceFactory(this)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        // ---- instant start + stable playback ---------------------------------------------------
        // Playback starts after only 0.5 s of data (500 ms) so a channel opens in under a second;
        // the buffer is kept at 1.5 s minimum, refilled up to 30 s while watching (stable picture), and
        // after a stall it resumes at 1.5 s. The buffer is capped at 120 MB so 4K / 8K cannot exhaust memory.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(1_000, 30_000, 500, 1_000)
            .setTargetBufferBytes(120 * 1024 * 1024)
            .setPrioritizeTimeOverSizeThresholds(false)
            .setBackBuffer(10_000, true)
            .build()

        // ---- 8K / 4K / HEVC / AV1 with hardware acceleration -----------------------------------
        // MediaCodec hardware decoders are always preferred; software decoding is only a fallback.
        val renderers = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)

        // ---- ABR: automatic quality switching by network speed ---------------------------------
        val trackSelector = DefaultTrackSelector(this).apply {
            parameters = buildUponParameters()
                .setAllowVideoMixedMimeTypeAdaptiveness(true)
                .setAllowVideoNonSeamlessAdaptiveness(true)
                .setExceedRendererCapabilitiesIfNecessary(true)
                .setForceHighestSupportedBitrate(false)
                .build()
        }

        // ---- auto reconnect: every failed download is retried 12 times (with a growing delay) ----
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)
            .setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(12))

        val player = ExoPlayer.Builder(this, renderers)
            .setLoadControl(loadControl)
            .setTrackSelector(trackSelector)
            .setMediaSourceFactory(mediaSourceFactory)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        mediaSession = MediaSession.Builder(this, player).build()
        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                SoundFx.attach(audioSessionId)
            }
        })
        SoundFx.attach(player.audioSessionId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    /** The ExoPlayer itself (same process) - used for the audio effects and the real stream info. */
    fun exo(): ExoPlayer? = mediaSession?.player as? ExoPlayer

    /** Audio session of the player, 0 when unknown. */
    fun audioSessionId(): Int = try { exo()?.audioSessionId ?: 0 } catch (_: Exception) { 0 }

    /** Pauses the playback (used when a trailer page is opened). */
    fun pausePlayback() {
        mediaSession?.player?.pause()
    }

    /** Stops the playback (used by the sleep timer). */
    fun stopPlayback() {
        mediaSession?.player?.let {
            it.stop()
            it.clearMediaItems()
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        // The app was swiped away: keep playing only if something is really playing.
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: PlaybackService? = null
            private set
    }
}
