package com.osogold.tv

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import java.net.URI
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Zapping helper: warms up the next and the previous channel in the background, so that when the
 * user presses next / previous the DNS answer, the TCP / TLS connection (kept in the shared OkHttp
 * pool that ExoPlayer uses too) and, for public HLS streams, the playlist and the first bytes of the
 * first segment are already there.
 *
 * Streams of an IPTV subscription (Xtream "live/user/pass" links) are NOT opened in advance, only
 * their DNS name is resolved: most providers allow one or two simultaneous connections and a second
 * stream would kick the running one.
 */
object ZapPrefetcher {

    private val executor = Executors.newFixedThreadPool(2)
    private val warmed = ConcurrentHashMap<String, Long>()

    private fun isSubscriptionStream(url: String): Boolean {
        val lower = url.lowercase(Locale.ROOT)
        return lower.contains("/live/") || lower.contains("/movie/") || lower.contains("/series/") ||
            lower.contains("get.php") || lower.contains("username=") || lower.startsWith("stalker:")
    }

    fun warm(url: String) {
        if (!url.startsWith("http", ignoreCase = true)) return
        val now = System.currentTimeMillis()
        val last = warmed[url]
        if (last != null && now - last < 60_000L) return
        warmed[url] = now
        if (warmed.size > 60) warmed.clear()
        executor.execute {
            try {
                val http = url.toHttpUrlOrNull() ?: return@execute
                val client = NetConfig.client()
                client.dns.lookup(http.host) // DNS (and DoH) answer is cached by the resolver
                if (isSubscriptionStream(url)) return@execute

                val text = if (url.contains(".m3u8", true)) NetConfig.getText(url) else null
                val firstChunk: String? = if (text != null) {
                    var media = text
                    var base = http
                    if (media.contains("#EXT-X-STREAM-INF")) {
                        val variant = media.lines().firstOrNull { it.isNotBlank() && !it.startsWith("#") }
                        val resolved = variant?.let { http.resolve(it.trim()) } ?: return@execute
                        media = NetConfig.getText(resolved.toString())
                        base = resolved
                    }
                    media.lines().firstOrNull { it.isNotBlank() && !it.startsWith("#") }
                        ?.let { base.resolve(it.trim())?.toString() }
                } else {
                    url
                }
                if (firstChunk != null) {
                    val request = Request.Builder().url(firstChunk)
                        .header("User-Agent", NetConfig.userAgent())
                        .header("Range", "bytes=0-65535").build()
                    client.newCall(request).execute().use { it.body?.source()?.request(65536) }
                }
            } catch (_: Exception) {
                // warming up is only a bonus: failures are ignored
            }
        }
    }
}

/**
 * "Instant alternative channel": finds the same channel with another quality or from another
 * source in the user's lists (4K -> FHD -> HD -> SD, or the same name in another list).
 */
object StreamAlternatives {

    private val tags = Regex(
        "(?i)(?<![\\p{L}\\p{N}])(4k|uhd|2160p?|fhd|hd|sd|fullhd|full hd|1080p?|1080i|720p?|576p?|480p?|hevc|h\\.?26[45]|" +
            "50fps|60fps|raw|backup|alt|بديل|مباشر|live|ᴴᴰ|ᵁᴴᴰ)(?![\\p{L}\\p{N}])"
    )

    /** Name without quality tags, prefixes and punctuation: "AR | MBC 1 FHD" -> "mbc1". */
    fun baseName(name: String): String {
        var t = name.replace(Regex("\\[[^\\]]*]|\\([^)]*\\)|\\{[^}]*}"), " ")
        t = t.replace(Regex("^\\s*[A-Za-z]{2,3}\\s*[|:\\-–]\\s*"), "")
        t = t.replace(tags, " ")
        return ArabicText.normalize(t).replace(" ", "")
    }

    /** 4 = 4K, 3 = FHD, 2 = HD (also unknown), 1 = SD. */
    fun quality(name: String): Int {
        val n = name.lowercase(Locale.ROOT)
        return when {
            Regex("4k|uhd|2160").containsMatchIn(n) -> 4
            Regex("fhd|1080|full ?hd").containsMatchIn(n) -> 3
            Regex("(?<![a-z])sd(?![a-z])|480|576").containsMatchIn(n) -> 1
            else -> 2
        }
    }

    private class Cache(val time: Long, val channels: List<Channel>)

    private val lists = ConcurrentHashMap<String, Cache>()

    private suspend fun listFor(prefs: Prefs, id: String): List<Channel> {
        val cached = lists[id]
        if (cached != null && System.currentTimeMillis() - cached.time < 10 * 60_000L) return cached.channels
        val fresh = try {
            Catalog.channels(prefs, id, null)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            emptyList()
        }
        lists[id] = Cache(System.currentTimeMillis(), fresh)
        return fresh
    }

    /**
     * The best working alternative of [current] that is not in [tried], or null. [nearby] (the open
     * list) is searched first; then the Xtream live list, the M3U lists and the live section.
     * Every candidate is checked to answer before it is returned (3 seconds at most each).
     */
    suspend fun find(prefs: Prefs, current: Channel, tried: Set<String>, nearby: List<Channel>): Channel? {
        val wanted = baseName(current.name)
        if (wanted.length < 2) return null
        val currentQuality = quality(current.name)

        val pool = LinkedHashMap<String, Channel>()
        fun add(list: List<Channel>) {
            for (c in list) {
                if (c.url == current.url || c.url in tried || c.url.isBlank()) continue
                if (c.url.contains("/movie/") || c.url.contains("/series/")) continue
                if (baseName(c.name) == wanted) pool.putIfAbsent(c.url, c)
            }
        }
        add(nearby)
        val ids = ArrayList<String>()
        if (prefs.xtreamConfigured()) ids.add("x_live")
        prefs.customLists().forEach { ids.add("m3u:${it.id}") }
        ids.add("live")
        for (id in ids) add(listFor(prefs, id))
        if (pool.isEmpty()) return null

        // lower quality first when the current one is the problem (4K -> FHD -> HD -> SD), then higher ones
        val ordered = pool.values.sortedWith(
            compareBy<Channel> { if (quality(it.name) <= currentQuality) 0 else 1 }
                .thenByDescending { if (quality(it.name) <= currentQuality) quality(it.name) else -quality(it.name) }
        )
        return withContext(Dispatchers.IO) {
            var checked = 0
            for (candidate in ordered) {
                if (checked >= 6) break
                checked++
                val url = try {
                    if (candidate.url.startsWith("stalker:")) Catalog.resolve(prefs, candidate) else candidate.url
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    continue
                }
                if (NetConfig.isReachable(url, 3000L)) return@withContext candidate
            }
            null
        }
    }
}
