package com.osogold.tv

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * Sleep timer: after the chosen time the playback is stopped, the playback service is stopped
 * and every open screen of the app is closed.
 */
object SleepTimer {

    const val ACTION_CLOSE = "com.osogold.tv.ACTION_SLEEP_CLOSE"

    private val handler = Handler(Looper.getMainLooper())
    private var runnable: Runnable? = null
    private var endElapsed = 0L

    val isActive: Boolean
        get() = runnable != null

    /** Minutes that are left (rounded up), 0 when no timer is running. */
    fun remainingMinutes(): Int {
        if (runnable == null) return 0
        val left = endElapsed - SystemClock.elapsedRealtime()
        return if (left <= 0) 0 else ((left + 59_999L) / 60_000L).toInt()
    }

    private var fade: Runnable? = null
    private const val FADE_MS = 40_000L

    private fun setVolume(v: Float) {
        try { PlaybackService.instance?.exo()?.volume = v } catch (_: Exception) {}
    }

    fun start(context: Context, minutes: Int) {
        cancel()
        val app = context.applicationContext
        val task = Runnable {
            runnable = null
            fade = null
            endElapsed = 0L
            PlaybackService.instance?.stopPlayback()
            setVolume(1f)
            app.stopService(Intent(app, PlaybackService::class.java))
            app.sendBroadcast(Intent(ACTION_CLOSE).setPackage(app.packageName))
        }
        runnable = task
        val delay = minutes * 60_000L
        endElapsed = SystemClock.elapsedRealtime() + delay
        handler.postDelayed(task, delay)
        // the volume goes down gradually during the last 40 seconds
        val step = object : Runnable {
            override fun run() {
                val left = endElapsed - SystemClock.elapsedRealtime()
                if (runnable == null || left <= 0) return
                setVolume((left.toFloat() / FADE_MS).coerceIn(0f, 1f))
                handler.postDelayed(this, 500L)
            }
        }
        fade = step
        handler.postDelayed(step, (delay - FADE_MS).coerceAtLeast(0L))
    }

    fun cancel() {
        fade?.let { handler.removeCallbacks(it) }
        if (fade != null) setVolume(1f)
        fade = null
        runnable?.let { handler.removeCallbacks(it) }
        runnable = null
        endElapsed = 0L
    }
}
