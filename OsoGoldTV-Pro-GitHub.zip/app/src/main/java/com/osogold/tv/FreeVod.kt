package com.osogold.tv

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Free, legal movies and series (Archive.org open API) by language. Used by the Movies / Series pages when the
 * user has no subscription. An entry has the address "archive://<id>"; the real file is resolved when it is opened.
 */
object FreeVod {

    val languages: List<Pkg> = listOf(
        Pkg("ar", "عربي", "🇸🇦"),
        Pkg("tr", "تركي", "🇹🇷"),
        Pkg("de", "ألماني", "🇩🇪"),
        Pkg("es", "إسباني", "🇪🇸"),
        Pkg("ku", "كردي", "☀️"),
        Pkg("xx", "أجنبي", "🌍")
    )

    private fun languageQuery(code: String): String = when (code) {
        "ar" -> "(language:(ara OR arabic OR Arabic))"
        "tr" -> "(language:(tur OR turkish OR Turkish))"
        "de" -> "(language:(deu OR ger OR german OR German))"
        "es" -> "(language:(spa OR spanish OR Spanish))"
        "ku" -> "(language:(kur OR kurdish OR Kurdish))"
        else -> "(language:(eng OR English OR fre OR french OR ita OR rus))"
    }

    suspend fun search(series: Boolean, language: String): List<Channel> = withContext(Dispatchers.IO) {
        val kindQuery = if (series) "(series OR episode OR season OR مسلسل)" else "(film OR movie OR فيلم)"
        val query = "mediatype:(movies) AND ${languageQuery(language)} AND $kindQuery AND NOT collection:(podcasts)"
        val url = "https://archive.org/advancedsearch.php?q=" + URLEncoder.encode(query, "UTF-8") +
            "&fl[]=identifier&fl[]=title&sort[]=downloads+desc&rows=80&output=json"
        val docs = JSONObject(NetConfig.getText(url)).optJSONObject("response")?.optJSONArray("docs")
        val out = ArrayList<Channel>()
        if (docs != null) {
            for (i in 0 until docs.length()) {
                val d = docs.optJSONObject(i) ?: continue
                val id = d.optString("identifier")
                val title = d.optString("title")
                if (id.isBlank() || title.isBlank()) continue
                out.add(Channel(name = title, url = "archive://$id", logo = "https://archive.org/services/img/$id"))
            }
        }
        out
    }
}
