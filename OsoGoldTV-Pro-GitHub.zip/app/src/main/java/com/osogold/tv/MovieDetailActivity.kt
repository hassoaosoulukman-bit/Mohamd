package com.osogold.tv

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import coil.load
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * One full screen page for a movie or a series: the trailer in full screen (Arabic subtitles
 * requested), the name, the story, "Play" and "Add to favourites".
 *
 * The information comes from TMDB (Arabic story, poster, rating, trailer) when the TMDB key was added
 * in Settings, completed by the provider (Xtream). "Play" first checks that the title really plays in
 * the current subscription; when it does not it searches the other saved lists and then the free open
 * sources (Archive.org, official YouTube channels). In a series every watched episode gets a small
 * check icon and the second where the user stopped is remembered ("continue watching").
 */
class MovieDetailActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private lateinit var web: WebView
    private lateinit var poster: ImageView
    private lateinit var scrim: View
    private lateinit var panel: View
    private lateinit var btnFav: TextView
    private lateinit var btnEpisodes: TextView
    private lateinit var btnPlay: TextView
    private lateinit var status: TextView

    private lateinit var base: Channel
    private var detail = MovieDetail()
    private var infoShown = true
    private var isSeries = false
    private var playJob: Job? = null

    /** Episodes from another list (found by the search) replace the ones of the provider. */
    private var episodes: List<Channel> = emptyList()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_detail)
        prefs = Prefs(this)

        base = Channel(
            name = intent.getStringExtra(EXTRA_NAME).orEmpty(),
            url = intent.getStringExtra(EXTRA_URL).orEmpty(),
            logo = intent.getStringExtra(EXTRA_LOGO).orEmpty(),
            seriesId = intent.getStringExtra(EXTRA_SERIES_ID).orEmpty(),
            infoId = intent.getStringExtra(EXTRA_INFO_ID).orEmpty()
        )
        isSeries = base.seriesId.isNotEmpty() || intent.getStringExtra(EXTRA_KIND) == "series"

        web = findViewById(R.id.trailerWeb)
        poster = findViewById(R.id.detailPoster)
        scrim = findViewById(R.id.detailScrim)
        panel = findViewById(R.id.infoPanel)
        btnFav = findViewById(R.id.btnDetailFav)
        btnEpisodes = findViewById(R.id.btnDetailEpisodes)
        btnPlay = findViewById(R.id.btnDetailPlay)
        status = findViewById(R.id.detailStatus)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()

        findViewById<View>(R.id.btnDetailBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnToggleInfo).setOnClickListener {
            infoShown = !infoShown
            panel.visibility = if (infoShown) View.VISIBLE else View.GONE
        }
        btnPlay.setOnClickListener { play() }
        btnFav.setOnClickListener { toggleFavorite() }
        btnEpisodes.setOnClickListener { showEpisodes() }

        findViewById<TextView>(R.id.detailTitle).text = base.name
        if (base.logo.isNotBlank()) poster.load(base.logo)
        updateFavoriteButton()
        loadDetail()
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        if (episodes.isNotEmpty()) updatePlayButton()
    }

    override fun onStop() {
        super.onStop()
        // the trailer must not keep playing after the app was left
        if (!AppState.inForeground) web.loadUrl("about:blank")
    }

    override fun onDestroy() {
        web.loadUrl("about:blank")
        web.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ data

    private fun loadDetail() {
        lifecycleScope.launch {
            val provider = try {
                withContext(Dispatchers.IO) {
                    when {
                        base.seriesId.isNotEmpty() && prefs.xtreamConfigured() ->
                            XtreamClient.seriesDetail(prefs, base.seriesId)
                        base.infoId.isNotEmpty() && prefs.xtreamConfigured() ->
                            XtreamClient.vodDetail(prefs, base.infoId)
                        else -> MovieDetail()
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                MovieDetail()
            }
            // show what the provider has right away, then improve it with TMDB
            detail = provider
            episodes = provider.episodes
            show()

            if (TmdbClient.configured(prefs)) {
                val tmdb = try {
                    withContext(Dispatchers.IO) { TmdbClient.detail(prefs, base.name, isSeries) }
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    null
                }
                if (tmdb != null) {
                    detail = merge(provider, tmdb)
                    show()
                }
            }
        }
    }

    private fun hasArabic(text: String) = text.any { it in '؀'..'ۿ' }

    private fun merge(provider: MovieDetail, tmdb: MovieDetail): MovieDetail {
        // the Arabic story wins; an English TMDB story is only used when the provider has nothing Arabic
        val plot = when {
            tmdb.plot.isBlank() -> provider.plot
            hasArabic(tmdb.plot) || !hasArabic(provider.plot) -> tmdb.plot
            else -> provider.plot
        }
        return MovieDetail(
            title = tmdb.title.ifBlank { provider.title },
            plot = plot,
            trailerId = tmdb.trailerId.ifBlank { provider.trailerId },
            poster = tmdb.poster.ifBlank { provider.poster },
            backdrop = tmdb.backdrop,
            genre = tmdb.genre.ifBlank { provider.genre },
            year = tmdb.year.ifBlank { provider.year },
            rating = tmdb.rating.ifBlank { provider.rating },
            episodes = provider.episodes
        )
    }

    private var trailerShown = ""

    private fun show() {
        findViewById<TextView>(R.id.detailTitle).text = detail.title.ifBlank { base.name }
        val meta = listOf(detail.year, detail.genre, if (detail.rating.isNotBlank()) "★ ${detail.rating}" else "")
            .filter { it.isNotBlank() }.joinToString("   •   ")
        findViewById<TextView>(R.id.detailMeta).text = meta
        findViewById<TextView>(R.id.detailPlot).text =
            detail.plot.ifBlank { "لا يتوفر شرح للقصة لهذا العمل." }
        val picture = detail.backdrop.ifBlank { detail.poster }
        if (picture.isNotBlank() && web.visibility != View.VISIBLE) poster.load(picture)

        if (isSeries && episodes.isNotEmpty()) {
            btnEpisodes.visibility = View.VISIBLE
            findViewById<View>(R.id.spaceEpisodes).visibility = View.VISIBLE
            updatePlayButton()
        }

        if (detail.trailerId.isNotBlank()) {
            if (trailerShown != detail.trailerId) {
                trailerShown = detail.trailerId
                startTrailer(detail.trailerId)
            }
        } else {
            // no trailer: offer a YouTube search for it
            val hint = findViewById<TextView>(R.id.detailMeta)
            hint.text = (meta + "   •   اضغط على العنوان للبحث عن الإعلان التشويقي").trim(' ', '•')
            findViewById<View>(R.id.detailTitle).setOnClickListener { searchTrailer() }
            scrim.visibility = View.VISIBLE
        }
    }

    /** Full screen YouTube trailer; Arabic subtitles are requested (shown when the video has them). */
    private fun startTrailer(id: String) {
        val html = """
            <html><body style="margin:0;background:#000">
            <iframe width="100%" height="100%" style="border:0;position:fixed;top:0;left:0;right:0;bottom:0"
              src="https://www.youtube.com/embed/$id?autoplay=1&controls=1&rel=0&modestbranding=1&playsinline=1&cc_load_policy=1&cc_lang_pref=ar&hl=ar&fs=0"
              allow="autoplay; encrypted-media; picture-in-picture" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
            </body></html>
        """.trimIndent()
        poster.visibility = View.GONE
        web.visibility = View.VISIBLE
        web.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
    }

    private fun searchTrailer() {
        val query = Uri.encode((detail.title.ifBlank { base.name }) + " اعلان رسمي مترجم")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$query")))
        } catch (_: Exception) {
            toast("لا يوجد تطبيق لفتح الرابط")
        }
    }

    // ------------------------------------------------------------------ continue watching

    /** The episode "Play" should start: the one in progress, else the first not watched, else the first. */
    private fun nextEpisode(): Channel? {
        val list = episodes
        if (list.isEmpty()) return null
        return list.lastOrNull { prefs.resumePosition(it.url) > 0L }
            ?: list.firstOrNull { !prefs.isWatched(it.url) }
            ?: list.first()
    }

    private fun updatePlayButton() {
        if (!isSeries) {
            if (prefs.resumePosition(base.url) > 0L) btnPlay.text = "▶  استكمال المشاهدة"
            return
        }
        val next = nextEpisode() ?: return
        btnPlay.text = if (prefs.resumePosition(next.url) > 0L) "▶  استكمال: ${next.name.substringBefore(" —")}"
        else if (prefs.isWatched(episodes.first().url)) "▶  الحلقة التالية: ${next.name.substringBefore(" —")}"
        else getString(R.string.play_now)
    }

    private fun clock(ms: Long): String {
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
    }

    // ------------------------------------------------------------------ buttons

    private fun play() {
        if (isSeries) {
            val next = nextEpisode()
            if (next == null) {
                // the provider gave no episodes: look in the other lists and the open sources
                launchPlayback(base, 0L)
                return
            }
            startItem(next)
        } else {
            startItem(base)
        }
    }

    /** Asks "continue from mm:ss or start over" when a position is saved, then plays. */
    private fun startItem(channel: Channel) {
        val saved = prefs.resumePosition(channel.url)
        if (saved < 10_000L) {
            launchPlayback(channel, 0L)
            return
        }
        val dialog = AlertDialog.Builder(this, R.style.GoldDialog)
            .setTitle(channel.name)
            .setMessage("توقفت عند ${clock(saved)}")
            .setPositiveButton("استكمال المشاهدة من ${clock(saved)}") { _, _ -> launchPlayback(channel, saved) }
            .setNegativeButton("البدء من البداية") { _, _ ->
                prefs.clearProgress(channel.url)
                launchPlayback(channel, 0L)
            }
            .create()
        showImmersive(dialog)
    }

    private fun setStatus(text: String?) {
        status.visibility = if (text.isNullOrBlank()) View.GONE else View.VISIBLE
        status.text = text.orEmpty()
    }

    /**
     * Plays [channel]. When it does not answer in the current subscription the other saved lists are
     * searched, then Archive.org and the official YouTube channels, so the work still plays full screen.
     */
    private fun launchPlayback(channel: Channel, startMs: Long) {
        playJob?.cancel()
        playJob = lifecycleScope.launch {
            btnPlay.isEnabled = false
            try {
                setStatus("جارٍ التحقق من توفر العمل في اشتراكك…")
                val available = withContext(Dispatchers.IO) {
                    val resolved = try {
                        Catalog.resolve(prefs, channel)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Exception) {
                        ""
                    }
                    resolved.isNotBlank() && (!resolved.startsWith("http", true) || NetConfig.isReachable(resolved))
                }
                if (available) {
                    setStatus(null)
                    startPlayer(channel.url, titleOf(channel), startMs, progressKey = channel.url)
                    return@launch
                }

                setStatus("غير متوفر في اشتراكك الحالي — جارٍ البحث في قوائمك المحفوظة…")
                val query = base.name
                var found = OpenSources.inUserLists(prefs, query, isSeries, base.url)
                if (found == null) {
                    setStatus("جارٍ البحث في المصادر المفتوحة (Archive.org)…")
                    found = OpenSources.inArchive(query, detail.title)
                }
                if (found == null) {
                    setStatus("جارٍ البحث في القنوات الرسمية على يوتيوب…")
                    found = OpenSources.onYoutube(prefs, detail.title.ifBlank { query })
                }
                val result = found
                if (result == null) {
                    setStatus(null)
                    val hint = if (prefs.youtubeKey.isBlank())
                        "\n\nلتفعيل البحث في يوتيوب أضف مفتاح YouTube Data API من الإعدادات ← إضافة مفتاح API."
                    else ""
                    showMessage("غير متوفر", "لم يُعثر على هذا العمل في اشتراكك ولا في قوائمك ولا في المصادر المجانية الرسمية.$hint")
                } else if (result.youtubeId.isNotBlank()) {
                    setStatus("تم العثور عليه: ${result.source}")
                    startActivity(
                        Intent(this@MovieDetailActivity, WebPlayerActivity::class.java)
                            .putExtra(WebPlayerActivity.EXTRA_VIDEO_ID, result.youtubeId)
                    )
                } else {
                    setStatus("تم العثور عليه في: ${result.source}")
                    val target = if (isSeries) {
                        // the same episode when the other list has it, otherwise its first one
                        result.channels.firstOrNull { it.name.contains(channel.name.substringBefore(" —"), true) }
                            ?: result.channels.first()
                    } else {
                        result.channels.first()
                    }
                    if (isSeries && episodes.isEmpty() && result.channels.size > 1) episodes = result.channels
                    // the watched mark / saved second stay on the original episode
                    startPlayer(target.url, titleOf(channel), startMs, progressKey = channel.url)
                }
            } finally {
                btnPlay.isEnabled = true
            }
        }
    }

    private fun titleOf(channel: Channel): String =
        if (channel === base || channel.url == base.url) detail.title.ifBlank { base.name }
        else detail.title.ifBlank { base.name } + " — " + channel.name

    private fun showMessage(title: String, message: String) {
        val dialog = AlertDialog.Builder(this, R.style.GoldDialog)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("حسناً", null)
            .create()
        showImmersive(dialog)
    }

    private fun startPlayer(url: String, name: String, startMs: Long, progressKey: String) {
        // when the player is closed with "back" the user returns to this page (movies list -> this page)
        val moviesIntent = Intent(this, MoviesActivity::class.java)
            .putExtra(MoviesActivity.EXTRA_KIND, if (isSeries) "series" else "movies")
        val detailIntent = Intent(this, MovieDetailActivity::class.java).putExtras(intent)
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(MainActivity.EXTRA_PLAY_URL, url)
                .putExtra(MainActivity.EXTRA_PLAY_NAME, name)
                .putExtra(MainActivity.EXTRA_PLAY_LOGO, base.logo)
                .putExtra(MainActivity.EXTRA_PLAY_START, startMs)
                .putExtra(MainActivity.EXTRA_PROGRESS_KEY, progressKey)
                .putExtra(MainActivity.EXTRA_RETURN_MOVIES, moviesIntent)
                .putExtra(MainActivity.EXTRA_RETURN_DETAIL, detailIntent)
        )
        finish()
    }

    // ------------------------------------------------------------------ episodes (with the watched icon)

    private sealed class Entry {
        class Header(val title: String) : Entry()
        class Episode(val channel: Channel) : Entry()
    }

    private fun showEpisodes() {
        val list = episodes
        val entries = ArrayList<Entry>()
        var season = ""
        for (ep in list) {
            if (ep.group != season) {
                season = ep.group
                entries.add(Entry.Header(season))
            }
            entries.add(Entry.Episode(ep))
        }
        val listView = ListView(this).apply {
            divider = null
            setPadding(0, 0, 0, 0)
        }
        val adapter = object : ArrayAdapter<Entry>(this, 0, entries) {
            override fun getViewTypeCount() = 2
            override fun getItemViewType(position: Int) = if (getItem(position) is Entry.Header) 0 else 1
            override fun isEnabled(position: Int) = getItem(position) is Entry.Episode

            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val entry = getItem(position)!!
                if (entry is Entry.Header) {
                    val tv = (convertView as? TextView) ?: TextView(context).apply {
                        setTextColor(UiTheme.t(0xFFD4AF37.toInt()))
                        textSize = 13f
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                        setPadding(40, 20, 40, 8)
                        layoutDirection = View.LAYOUT_DIRECTION_RTL
                    }
                    tv.text = entry.title
                    return tv
                }
                val ep = (entry as Entry.Episode).channel
                val row = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_episode, parent, false)
                row.findViewById<TextView>(R.id.epName).text = ep.name
                val watched = prefs.isWatched(ep.url)
                val saved = prefs.resumePosition(ep.url)
                row.findViewById<View>(R.id.epWatched).visibility = if (watched) View.VISIBLE else View.INVISIBLE
                row.findViewById<TextView>(R.id.epResume).text =
                    if (saved > 0L) "⏵ ${clock(saved)}" else ""
                UiTheme.apply(row)
                return row
            }
        }
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ ->
            val entry = adapter.getItem(position)
            if (entry is Entry.Episode) {
                dialogRef?.dismiss()
                startItem(entry.channel)
            }
        }
        val dialog = AlertDialog.Builder(this, R.style.GoldDialog)
            .setTitle("الحلقات (${list.size})")
            .setView(listView)
            .setNegativeButton("إغلاق", null)
            .create()
        dialogRef = dialog
        showImmersive(dialog)
        // open on the episode the user is watching
        val current = nextEpisode()
        val index = entries.indexOfFirst { it is Entry.Episode && it.channel.url == current?.url }
        if (index > 0) listView.post { listView.setSelection((index - 2).coerceAtLeast(0)) }
    }

    private var dialogRef: AlertDialog? = null

    private fun toggleFavorite() {
        prefs.toggleFavorite(base, if (isSeries) "series" else "movie")
        updateFavoriteButton()
    }

    private fun updateFavoriteButton() {
        btnFav.setText(if (prefs.isFavorite(base.url)) R.string.fav_remove else R.string.fav_add)
    }

    companion object {
        const val EXTRA_KIND = "kind"
        const val EXTRA_NAME = "name"
        const val EXTRA_URL = "url"
        const val EXTRA_LOGO = "logo"
        const val EXTRA_SERIES_ID = "series_id"
        const val EXTRA_INFO_ID = "info_id"
    }
}
