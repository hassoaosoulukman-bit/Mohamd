package com.osogold.tv

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/**
 * Sound effects for BOTH engines:
 *  - Media3 / ExoPlayer: Android Equalizer + BassBoost + Virtualizer + LoudnessEnhancer on the audio session of the player;
 *  - LibVLC: its own 10 band equalizer (through [vlcSink]).
 * Every preset is a 5 point curve (bass, low-mid, mid, high-mid, treble) in percent (-100..+100) that is
 * stretched over the real bands of the device. The choice is saved and re-applied whenever a player starts.
 */
object SoundFx {

    class Preset(
        val id: String,
        val title: String,
        val curve: IntArray,
        val bass: Int = 0,        // BassBoost strength 0..1000
        val virtualizer: Int = 0, // Virtualizer strength 0..1000 (3D / surround feel)
        val loudMb: Int = 0       // LoudnessEnhancer gain in millibel
    )

    val presets: List<Preset> = listOf(
        Preset("normal", "طبيعي", intArrayOf(0, 0, 0, 0, 0)),
        Preset("cinema", "ضخم / سينمائي (Bass Boost)", intArrayOf(70, 40, 0, 15, 25), bass = 800, virtualizer = 300),
        Preset("soft", "ناعم / ليلي (Soft)", intArrayOf(-10, 0, 10, -20, -45), bass = 100),
        Preset("pop", "بوب (Pop)", intArrayOf(35, 15, 30, 35, 40), bass = 300),
        Preset("clear", "نقاء الصوت / القرآن (Clear Voice)", intArrayOf(-55, -15, 55, 55, 15)),
        Preset("sport", "رياضة / ملعب", intArrayOf(25, 0, 35, 60, 45), bass = 350, virtualizer = 450),
        Preset("action", "أفلام أكشن", intArrayOf(85, 45, -10, 40, 60), bass = 900, virtualizer = 350),
        Preset("news", "أخبار وحوار", intArrayOf(-65, -10, 65, 55, 0)),
        Preset("surround", "محيطي 3D", intArrayOf(30, 10, 0, 30, 45), bass = 350, virtualizer = 1000),
        Preset("loud", "تعزيز الصوت العالي", intArrayOf(20, 10, 25, 25, 20), bass = 200, loudMb = 1500),
        Preset("custom", "مخصص (Custom)", intArrayOf(0, 0, 0, 0, 0))
    )

    private val bandNames = listOf("جهير", "منخفض", "متوسط", "عالٍ", "حاد")

    private var eq: Equalizer? = null
    private var boost: BassBoost? = null
    private var virt: Virtualizer? = null
    private var loud: LoudnessEnhancer? = null
    private var session = -1

    private var prefsRef: Prefs? = null

    /** Set by the main screen: applies a gain curve (dB per band, null = off) to LibVLC. */
    var vlcSink: ((gainsDb: FloatArray?, preAmpDb: Float) -> Unit)? = null

    fun init(context: Context) {
        if (prefsRef == null) prefsRef = Prefs(context.applicationContext)
    }

    var currentId: String
        get() = prefsRef?.eqPreset ?: "normal"
        set(v) { prefsRef?.eqPreset = v }

    private fun customCurve(): IntArray {
        val saved = prefsRef?.eqCustom.orEmpty().split(',').mapNotNull { it.trim().toIntOrNull() }
        return IntArray(5) { saved.getOrElse(it) { 0 } }
    }

    private fun activePreset(): Preset = presets.firstOrNull { it.id == currentId } ?: presets[0]

    private fun activeCurve(): IntArray = if (currentId == "custom") customCurve() else activePreset().curve

    private fun interpolate(curve: IntArray, bands: Int): IntArray {
        if (bands <= 1) return intArrayOf(curve.average().toInt())
        return IntArray(bands) { i ->
            val pos = i * (curve.size - 1).toFloat() / (bands - 1)
            val lo = pos.toInt().coerceIn(0, curve.size - 1)
            val hi = (lo + 1).coerceAtMost(curve.size - 1)
            (curve[lo] + (curve[hi] - curve[lo]) * (pos - lo)).toInt()
        }
    }

    // ------------------------------------------------------------------ Media3 (audio session)

    @Synchronized
    fun attach(sessionId: Int) {
        if (sessionId <= 0) return
        if (sessionId == session && eq != null) return
        releaseEffects()
        session = sessionId
        try { eq = Equalizer(0, sessionId).also { it.enabled = true } } catch (_: Throwable) { eq = null }
        try { boost = BassBoost(0, sessionId).also { it.enabled = true } } catch (_: Throwable) { boost = null }
        try { virt = Virtualizer(0, sessionId).also { it.enabled = true } } catch (_: Throwable) { virt = null }
        try { loud = LoudnessEnhancer(sessionId).also { it.enabled = true } } catch (_: Throwable) { loud = null }
        applyCurrent()
    }

    /** Re-connects to the live audio session of the player (the session can change after a restart of the service). */
    @Synchronized
    private fun ensureAttached() {
        val id = try { PlaybackService.instance?.audioSessionId() ?: 0 } catch (_: Throwable) { 0 }
        if (id > 0 && (id != session || eq == null)) attach(id)
    }

    private fun releaseEffects() {
        try { eq?.release() } catch (_: Throwable) {}
        try { boost?.release() } catch (_: Throwable) {}
        try { virt?.release() } catch (_: Throwable) {}
        try { loud?.release() } catch (_: Throwable) {}
        eq = null; boost = null; virt = null; loud = null; session = -1
    }

    fun release() = releaseEffects()

    val available: Boolean get() = eq != null || vlcSink != null

    /** Applies the saved preset to whatever player runs (called when a player starts and on every change). */
    @Synchronized
    fun applyCurrent() {
        val preset = activePreset()
        val curve = activeCurve()
        // Media3
        val e = eq
        if (e != null) {
            try {
                e.enabled = true
                val range = e.bandLevelRange
                val lo = range[0].toInt()
                val hi = range[1].toInt()
                val bands = e.numberOfBands.toInt()
                val levels = interpolate(curve, bands)
                for (b in 0 until bands) {
                    val pct = levels[b]
                    val mb = if (pct >= 0) hi * pct / 100 else lo * (-pct) / 100
                    e.setBandLevel(b.toShort(), mb.coerceIn(lo, hi).toShort())
                }
            } catch (_: Throwable) {}
        }
        val bassStrength = if (currentId == "custom") (prefsRef?.eqCustomBass ?: 0) else preset.bass
        try { boost?.setStrength(bassStrength.toShort()) } catch (_: Throwable) {}
        try { virt?.setStrength(preset.virtualizer.toShort()) } catch (_: Throwable) {}
        try { loud?.setTargetGain(preset.loudMb) } catch (_: Throwable) {}
        // LibVLC (10 bands, +-12 dB)
        applyVlc(curve, bassStrength)
    }

    /** LibVLC just started playing: give it the equalizer too. */
    fun reapplyVlc() {
        applyVlc(activeCurve(), if (currentId == "custom") (prefsRef?.eqCustomBass ?: 0) else activePreset().bass)
    }

    private fun applyVlc(curve: IntArray, bassStrength: Int) {
        val sink = vlcSink ?: return
        if (currentId == "normal") {
            sink(null, 0f)
            return
        }
        val gains = interpolate(curve, 10).map { it * 0.12f }.toFloatArray()
        val extraBass = bassStrength / 1000f * 6f
        gains[0] += extraBass
        gains[1] += extraBass * 0.7f
        gains[2] += extraBass * 0.3f
        sink(gains, -2f)
    }

    fun applyPreset(p: Preset) {
        currentId = p.id
        ensureAttached()
        applyCurrent()
    }

    // ------------------------------------------------------------------ dialog

    fun showDialog(context: Context, onChanged: (() -> Unit)? = null) {
        init(context)
        ensureAttached()
        val dp = context.resources.displayMetrics.density
        val dialog = Dialog(context)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_overlay)
            setPadding((16 * dp).toInt(), (12 * dp).toInt(), (16 * dp).toInt(), (12 * dp).toInt())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        box.addView(TextView(context).apply {
            text = "مؤثرات الصوت (EQ)"
            setTextColor(context.getColor(R.color.gold_light))
            textSize = 17f
            gravity = Gravity.CENTER
        })
        if (!available) {
            box.addView(TextView(context).apply {
                text = "ابدأ تشغيل قناة أو إذاعة أولاً ثم اختر النمط."
                setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
                setPadding(0, (6 * dp).toInt(), 0, (6 * dp).toInt())
            })
        }
        val custom = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (currentId == "custom") View.VISIBLE else View.GONE
        }
        val rows = ArrayList<TextView>()
        fun mark() {
            rows.forEachIndexed { i, tv ->
                val sel = presets[i].id == currentId
                tv.setTextColor(if (sel) Color.parseColor("#FFD4AF37") else Color.WHITE)
                tv.text = (if (sel) "✔  " else "      ") + presets[i].title
            }
        }
        val list = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        for (p in presets) {
            rows.add(TextView(context).apply {
                textSize = 15f
                setPadding((6 * dp).toInt(), (8 * dp).toInt(), (6 * dp).toInt(), (8 * dp).toInt())
                setOnClickListener {
                    applyPreset(p)
                    custom.visibility = if (p.id == "custom") View.VISIBLE else View.GONE
                    mark()
                    onChanged?.invoke()
                }
            }.also { list.addView(it) })
        }
        mark()

        // manual bands (5 sliders) + bass: active when "Custom" is chosen, every move is heard at once
        val saved = customCurve()
        for (b in 0 until 5) {
            val line = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            line.addView(TextView(context).apply {
                text = bandNames[b]; setTextColor(Color.WHITE); textSize = 12f
                layoutParams = LinearLayout.LayoutParams((56 * dp).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
            })
            line.addView(SeekBar(context).apply {
                max = 200; progress = saved[b] + 100
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                        if (!fromUser) return
                        saved[b] = v - 100
                        prefsRef?.eqCustom = saved.joinToString(",")
                        currentId = "custom"
                        applyCurrent()
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) { mark() }
                })
            })
            custom.addView(line)
        }
        val bassLine = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bassLine.addView(TextView(context).apply {
            text = "Bass"; setTextColor(Color.WHITE); textSize = 12f
            layoutParams = LinearLayout.LayoutParams((56 * dp).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        })
        bassLine.addView(SeekBar(context).apply {
            max = 1000; progress = prefsRef?.eqCustomBass ?: 0
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    prefsRef?.eqCustomBass = v
                    currentId = "custom"
                    applyCurrent()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { mark() }
            })
        })
        custom.addView(bassLine)

        val scroll = ScrollView(context)
        val inner = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        inner.addView(list)
        inner.addView(custom)
        scroll.addView(inner)
        box.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (300 * dp).toInt()))
        dialog.setContentView(box)
        dialog.window?.setLayout(
            minOf((340 * dp).toInt(), context.resources.displayMetrics.widthPixels - (24 * dp).toInt()),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        dialog.show()
    }
}
