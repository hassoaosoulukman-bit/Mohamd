package com.osogold.tv

import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.dnsoverhttps.DnsOverHttps
import java.net.InetAddress
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Auto Smart Shield.
 *
 *  - Six DNS-over-HTTPS servers (Cloudflare, Google, Quad9, AdGuard, NextDNS, Mullvad). In automatic mode
 *    they are ranked by speed in the background and every lookup walks down the ranking: when one is
 *    blocked or fails the next one answers at once (system DNS is the very last fallback).
 *  - Five player identity cards (User-Agent). When a server answers 403 / 406 / 451 (a block) the request
 *    is repeated with the next identity and the new one is saved in the settings, so the Settings page and the
 *    Protection page always show the same, current card.
 */
object SmartShield {

    class Doh(val id: Int, val name: String, val url: String, val bootstrap: List<String>)

    /** id = the number kept in the settings (1..6). 0 means "off". */
    val providers: List<Doh> = listOf(
        Doh(1, "Cloudflare", "https://cloudflare-dns.com/dns-query", listOf("1.1.1.1", "1.0.0.1")),
        Doh(2, "Google", "https://dns.google/dns-query", listOf("8.8.8.8", "8.8.4.4")),
        Doh(3, "Quad9", "https://dns.quad9.net/dns-query", listOf("9.9.9.9", "149.112.112.112")),
        Doh(4, "AdGuard", "https://dns.adguard-dns.com/dns-query", listOf("94.140.14.14", "94.140.15.15")),
        Doh(5, "NextDNS", "https://dns.nextdns.io/dns-query", listOf("45.90.28.0", "45.90.30.0")),
        Doh(6, "Mullvad", "https://dns.mullvad.net/dns-query", listOf("194.242.2.2"))
    )

    /** The identity cards that are rotated (name, User-Agent text). */
    val agents: List<Pair<String, String>> = listOf(
        "IPTVSmartersPro" to "IPTVSmartersPro",
        "VLC" to "VLC/3.0.20 LibVLC/3.0.20",
        "ExoPlayer" to "ExoPlayer",
        "TiviMate" to "TiviMate/4.7.0 (Android)",
        "Kodi" to "Kodi/20.2 (Linux; Android 13) Android/13 Sys_CPU/aarch64"
    )

    private val bootstrapClient: OkHttpClient by lazy {
        OkHttpClient.Builder().connectTimeout(6, TimeUnit.SECONDS).readTimeout(6, TimeUnit.SECONDS).build()
    }

    private val resolvers = HashMap<Int, DnsOverHttps>()

    private fun resolver(p: Doh): DnsOverHttps = synchronized(resolvers) {
        resolvers.getOrPut(p.id) {
            DnsOverHttps.Builder().client(bootstrapClient)
                .url(p.url.toHttpUrl())
                .bootstrapDnsHosts(p.bootstrap.map { InetAddress.getByName(it) })
                .build()
        }
    }

    @Volatile
    private var ranking: List<Int> = providers.map { it.id }

    @Volatile
    private var lastRank = 0L

    @Volatile
    private var ranking_busy = false

    private val pool = Executors.newSingleThreadExecutor { Thread(it, "SmartShield").apply { isDaemon = true } }

    /** Re-measures the six servers in the background (at most once every 10 minutes). */
    fun rankInBackground(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (ranking_busy || (!force && now - lastRank < 10 * 60_000L)) return
        ranking_busy = true
        pool.execute {
            try {
                val timings = providers.map { p ->
                    val start = System.nanoTime()
                    val ok = try {
                        resolver(p).lookup("www.google.com").isNotEmpty()
                    } catch (_: Throwable) {
                        false
                    }
                    p.id to if (ok) (System.nanoTime() - start) else Long.MAX_VALUE
                }
                ranking = timings.sortedBy { it.second }.map { it.first }
                lastRank = System.currentTimeMillis()
            } catch (_: Throwable) {
            } finally {
                ranking_busy = false
            }
        }
    }

    /** A [Dns] that walks down the ranking; [fixed] > 0 puts that server first. System DNS is the last resort. */
    fun dns(auto: Boolean, fixed: Int): Dns = object : Dns {
        override fun lookup(hostname: String): List<InetAddress> {
            val order = if (auto) ranking else listOf(fixed) + providers.map { it.id }.filter { it != fixed }
            var tried = 0
            for (id in order) {
                val p = providers.firstOrNull { it.id == id } ?: continue
                if (!auto && tried >= 2) break // a fixed choice: its own server + one reserve
                tried++
                try {
                    val result = resolver(p).lookup(hostname)
                    if (result.isNotEmpty()) return result
                } catch (_: Throwable) {
                    if (auto) ranking = ranking.filter { it != id } + id // push the failing one to the end
                }
                if (tried >= 3) break
            }
            return Dns.SYSTEM.lookup(hostname)
        }
    }

    // ------------------------------------------------------------------ identity cards

    @Volatile
    private var lastRotate = 0L

    /** Switches to the next identity card (saved in the settings). Returns the new User-Agent or null (too soon). */
    @Synchronized
    fun rotateAgent(prefs: Prefs): String? {
        val now = System.currentTimeMillis()
        if (now - lastRotate < 15_000L) return null
        lastRotate = now
        val current = prefs.userAgent
        val index = agents.indexOfFirst { it.second == current }
        val next = agents[(index + 1).mod(agents.size)].second
        prefs.userAgent = next
        return next
    }

    /** True for the answers that mean "this server does not like my identity". */
    fun isBlock(code: Int): Boolean = code == 403 || code == 406 || code == 451
}
