package com.osogold.tv

import android.content.Context
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import okhttp3.Authenticator
import okhttp3.ConnectionSpec
import okhttp3.Credentials
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.TlsVersion
import java.io.IOException
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.PasswordAuthentication
import java.net.Proxy
import java.net.URL
import java.util.concurrent.TimeUnit

/**
 * One place for every network setting.
 *
 *  - The User-Agent ("player identity card") is read from the settings every time a request is made.
 *  - Protection (Settings -> Protection and full encryption): DNS-over-HTTPS (so the provider of
 *    the internet cannot see or poison the names of the servers), TLS 1.3 with a TLS 1.2 fallback,
 *    and an optional encrypted SOCKS5 / HTTP proxy. The same OkHttp client is used by ExoPlayer, the
 *    playlist / Xtream / Stalker / TMDB requests, and (as a plain connection with the proxy) by the recorder.
 *
 * Note: TLS can only protect links that start with https://. Plain http:// streams are hidden from
 * DNS filtering by DoH and, when a proxy is on, from the provider by the proxy.
 */
object NetConfig {

    lateinit var app: Context
        private set

    @Volatile
    private var client: OkHttpClient? = null

    @Volatile
    private var clientKey: String = ""

    fun init(context: Context) {
        app = context.applicationContext
    }

    /** The User-Agent chosen in Settings (IPTVSmartersPro, VLC, ExoPlayer or a custom text). */
    fun userAgent(): String = Prefs(app).userAgent

    // ------------------------------------------------------------------ protection state

    /** What is really active right now (used by the settings indicator). */
    class Status(val doh: Boolean, val tls13: Boolean, val proxy: Boolean, val agent: Boolean, val storage: Boolean) {
        val fullyProtected: Boolean get() = doh && tls13 && storage
    }

    fun status(): Status {
        val p = Prefs(app)
        val on = p.protectionOn
        return Status(
            doh = on && p.dohProvider != 0,
            tls13 = on && p.tls13,
            proxy = on && p.proxyConfigured(),
            agent = true,
            storage = true
        )
    }

    private fun javaProxy(p: Prefs): Proxy? {
        if (!p.protectionOn || !p.proxyConfigured()) return null
        val type = if (p.proxyType == 1) Proxy.Type.SOCKS else Proxy.Type.HTTP
        return Proxy(type, InetSocketAddress.createUnresolved(p.proxyHost, p.proxyPort))
    }

    private fun buildClient(p: Prefs): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)

        // IPTV servers are very often plain http:// -> cleartext must stay possible
        val specs = ArrayList<ConnectionSpec>()
        if (p.protectionOn && p.tls13) {
            specs.add(
                ConnectionSpec.Builder(ConnectionSpec.RESTRICTED_TLS)
                    .tlsVersions(TlsVersion.TLS_1_3, TlsVersion.TLS_1_2)
                    .build()
            )
        } else {
            specs.add(ConnectionSpec.MODERN_TLS)
            specs.add(ConnectionSpec.COMPATIBLE_TLS)
        }
        specs.add(ConnectionSpec.CLEARTEXT)
        builder.connectionSpecs(specs)

        // proxy (SOCKS5 / HTTP), with a user name and password when needed
        javaProxy(p)?.let { proxy ->
            builder.proxy(proxy)
            if (p.proxyUser.isNotBlank()) {
                val user = p.proxyUser
                val pass = p.proxyPass
                if (proxy.type() == Proxy.Type.HTTP) {
                    builder.proxyAuthenticator(Authenticator { _, response ->
                        if (response.request.header("Proxy-Authorization") != null) null
                        else response.request.newBuilder()
                            .header("Proxy-Authorization", Credentials.basic(user, pass))
                            .build()
                    })
                } else {
                    java.net.Authenticator.setDefault(object : java.net.Authenticator() {
                        override fun getPasswordAuthentication(): PasswordAuthentication? =
                            if (requestorType == java.net.Authenticator.RequestorType.PROXY)
                                PasswordAuthentication(user, pass.toCharArray()) else null
                    })
                }
            }
        }

        // DNS over HTTPS (not when a proxy resolves the names itself): six servers, automatic switching
        if (p.protectionOn && p.dohProvider != 0 && javaProxy(p) == null) {
            try {
                if (p.shieldAuto) SmartShield.rankInBackground()
                builder.dns(SmartShield.dns(p.shieldAuto, p.dohProvider))
            } catch (_: Exception) {
            }
        }

        // automatic identity switching when a server blocks the current User-Agent
        if (p.protectionOn && p.shieldAuto) {
            builder.addInterceptor { chain ->
                val request = chain.request()
                val response = chain.proceed(request)
                if (SmartShield.isBlock(response.code)) {
                    val next = SmartShield.rotateAgent(Prefs(app))
                    if (next != null) {
                        response.close()
                        return@addInterceptor chain.proceed(request.newBuilder().header("User-Agent", next).build())
                    }
                }
                response
            }
        }
        return builder.build()
    }

    private fun signature(p: Prefs): String =
        listOf(
            p.protectionOn, p.dohProvider, p.shieldAuto, p.tls13, p.proxyType, p.proxyHost, p.proxyPort,
            p.proxyUser, p.proxyPass
        ).joinToString("|")

    /** The shared OkHttp client. It is rebuilt automatically after a change in the protection settings. */
    fun client(): OkHttpClient {
        val p = Prefs(app)
        val key = signature(p)
        val existing = client
        if (existing != null && key == clientKey) return existing
        synchronized(this) {
            val again = client
            if (again != null && key == clientKey) return again
            val fresh = buildClient(p)
            client = fresh
            clientKey = key
            return fresh
        }
    }

    /** Creates a fresh HTTP data source for every request (OkHttp), always with the current User-Agent. */
    fun httpFactory(): DataSource.Factory = DataSource.Factory {
        OkHttpDataSource.Factory(client())
            .setUserAgent(userAgent())
            .createDataSource()
    }

    /** HTTP + file + asset + content sources, used by every ExoPlayer instance of the app. */
    fun dataSourceFactory(context: Context): DataSource.Factory =
        DefaultDataSource.Factory(context, httpFactory())

    /** Opens a plain connection (used by the recorder). Follows redirects. The proxy is respected. */
    fun open(
        address: String,
        headers: Map<String, String> = emptyMap(),
        userAgent: String = userAgent(),
        connectMs: Int = 15_000,
        readMs: Int = 30_000
    ): HttpURLConnection {
        val proxy = javaProxy(Prefs(app))
        client() // makes sure the proxy authenticator is registered
        var current = address
        repeat(6) {
            val url = URL(current)
            val conn = (if (proxy != null) url.openConnection(proxy) else url.openConnection()) as HttpURLConnection
            conn.connectTimeout = connectMs
            conn.readTimeout = readMs
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("User-Agent", userAgent)
            for ((key, value) in headers) conn.setRequestProperty(key, value)
            val code = conn.responseCode
            if (code in 300..399) {
                val location = conn.getHeaderField("Location")
                conn.disconnect()
                if (location.isNullOrBlank()) throw IOException("redirect without location")
                current = URL(URL(current), location).toString()
            } else if (code in 200..299) {
                return conn
            } else {
                conn.disconnect()
                throw IOException("HTTP $code")
            }
        }
        throw IOException("too many redirects")
    }

    /** Downloads a text resource over the protected client. Call from a background thread. */
    fun getText(
        address: String,
        headers: Map<String, String> = emptyMap(),
        userAgent: String = userAgent()
    ): String {
        val builder = Request.Builder().url(address).header("User-Agent", userAgent)
        for ((key, value) in headers) builder.header(key, value)
        client().newCall(builder.build()).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
            return response.body?.string().orEmpty()
        }
    }

    /** True when the address answers (used to decide whether a movie is available). */
    fun isReachable(address: String, timeoutMs: Long = 8000L): Boolean {
        return try {
            val request = Request.Builder().url(address).header("User-Agent", userAgent())
                .header("Range", "bytes=0-1023").build()
            val short = client().newBuilder()
                .callTimeout(timeoutMs, TimeUnit.MILLISECONDS).build()
            short.newCall(request).execute().use { it.code in 200..299 }
        } catch (_: Exception) {
            false
        }
    }
}
