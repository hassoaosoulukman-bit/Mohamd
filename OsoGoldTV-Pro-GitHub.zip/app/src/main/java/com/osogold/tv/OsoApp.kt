package com.osogold.tv

import android.app.Activity
import android.app.Application
import android.os.Bundle

/**
 * Application class: makes the application context available to the network layer, loads the
 * colour theme, and stops EVERY player the moment the user leaves the app (no sound in the background).
 */
class OsoApp : Application() {

    override fun onCreate() {
        super.onCreate()
        NetConfig.init(this)
        SoundFx.init(this)
        UiTheme.load(this)
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                AppState.started++
            }

            override fun onActivityStopped(activity: Activity) {
                AppState.started = (AppState.started - 1).coerceAtLeast(0)
                // the last screen went away (home button, another app, app closed) and it is not a rotation
                if (AppState.started == 0 && !activity.isChangingConfigurations && !AppState.keepAudio) {
                    AppState.stopEverything()
                }
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
    }
}

/** Foreground state of the app and the global "stop all sound" switch. */
object AppState {

    @Volatile
    var started = 0

    /** Audio-only mode: the sound continues in the background instead of being stopped. */
    @Volatile
    var keepAudio = false

    val inForeground: Boolean get() = started > 0

    /** Listeners (the main screen) that must stop ExoPlayer / LibVLC themselves. */
    val stopListeners = java.util.concurrent.CopyOnWriteArrayList<() -> Unit>()

    fun stopEverything() {
        for (listener in stopListeners) {
            try {
                listener()
            } catch (_: Exception) {
            }
        }
        try {
            PlaybackService.instance?.stopPlayback()
            PlaybackService.instance?.stopSelf()
        } catch (_: Exception) {
        }
    }
}
