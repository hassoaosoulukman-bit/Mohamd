package com.osogold.tv

import android.animation.ObjectAnimator
import android.graphics.Color
import android.graphics.Typeface
import android.media.audiofx.Visualizer
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import coil.load
import coil.transform.CircleCropTransformation
import org.json.JSONObject
import java.util.concurrent.Executors
import android.animation.ValueAnimator
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.media3.common.Player

/**
 * The luxury audio player of the Radio and Holy Quran sections. It controls the same background
 * player (Media3 service) the rest of the app uses, so the sound continues with the screen off.
 */
class AudioPanel(private val root: View, private val host: Host) {

    interface Host {
        fun controller(): Player?
        fun next()
        fun previous()
        fun toggleRecord()
        fun onMuteChanged(muted: Boolean)
        fun onClosed()

        /** A row of the floating sections list was touched. */
        fun onSectionRow(row: Row) {}

        /** A row of the floating stations list was touched. */
        fun onChannelRow(row: Row) {}

        fun onStarRow(row: Row) {}
        fun isFavorite(channel: Channel): Boolean = false

        /** The floating lists were opened: the host pushes the current sections / stations. */
        fun onListsOpened() {}

        /** A reciter chosen in the reciter search: open his surahs. */
        fun openReciter(id: String, title: String) {}
    }

    private val disc: View = root.findViewById(R.id.audioDisc)
    private val icon: ImageView = root.findViewById(R.id.audioIcon)
    private val title: TextView = root.findViewById(R.id.audioTitle)
    private val sub: TextView = root.findViewById(R.id.audioSub)
    private val recTimer: TextView = root.findViewById(R.id.audioRecTimer)
    private val seek: SeekBar = root.findViewById(R.id.audioSeek)
    private val pos: TextView = root.findViewById(R.id.audioPos)
    private val dur: TextView = root.findViewById(R.id.audioDur)
    private val btnMute: ImageView = root.findViewById(R.id.btnAudioMute)
    private val btnPrev: ImageView = root.findViewById(R.id.btnAudioPrev)
    private val btnPlay: ImageView = root.findViewById(R.id.btnAudioPlay)
    private val btnNext: ImageView = root.findViewById(R.id.btnAudioNext)
    private val btnRec: ImageView = root.findViewById(R.id.btnAudioRec)
    private val btnClose: ImageView = root.findViewById(R.id.btnAudioClose)

    private val ctx = root.context
    private val dp = ctx.resources.displayMetrics.density
    private val wave = GoldWaveView(ctx)
    private val blurBg = ImageView(ctx)
    private val verseScroll = ScrollView(ctx)
    private val verseText = TextView(ctx)
    private var visualizer: Visualizer? = null
    private var versesFor = ""
    private val net = Executors.newSingleThreadExecutor()

    // floating lists window (touch an empty place of the player to open it)
    private val secAdapter = RowAdapter({ host.onSectionRow(it) }, { }, { false })
    private val chAdapter = RowAdapter({ host.onChannelRow(it) }, { host.onStarRow(it) }, { host.isFavorite(it) })
    private var listsWindow: FrameLayout? = null
    private val tvSecTitle = TextView(ctx)
    private val tvChTitle = TextView(ctx)

    private val prefs = Prefs(ctx)
    private var quranMode = false
    private var currentUrl = ""
    private var currentTitle = ""
    private var currentGroup = ""
    private var lastSaveAt = 0L
    private var ayahs: List<String> = emptyList()
    private val discName = TextView(ctx)
    private var btnMushaf: TextView? = null
    private var btnReciter: TextView? = null
    private var mushafCard: FrameLayout? = null
    private var mushafScroll: ScrollView? = null
    private var mushafText: TextView? = null
    private var mushafTitle: TextView? = null
    private var scrollSpeed = 1f
    private var scrollTouching = false
    private var scrollAcc = 0f
    private val handler = Handler(Looper.getMainLooper())
    private var spin: ObjectAnimator? = null
    private var dragging = false

    var muted = false
        private set

    val isVisible: Boolean
        get() = root.visibility == View.VISIBLE

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500L)
        }
    }

    init {
        buildExtras()
        btnPlay.setOnClickListener {
            host.controller()?.let { if (it.isPlaying || it.playWhenReady) it.pause() else it.play() }
            refresh()
        }
        btnMute.setOnClickListener { setMuted(!muted) }
        btnPrev.setOnClickListener { host.previous() }
        btnNext.setOnClickListener { host.next() }
        btnRec.setOnClickListener { host.toggleRecord() }
        btnClose.setOnClickListener { hide() }
        root.setOnClickListener { showLists() }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) pos.text = format(progress.toLong())
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {
                dragging = true
            }

            override fun onStopTrackingTouch(bar: SeekBar?) {
                dragging = false
                host.controller()?.seekTo((bar?.progress ?: 0).toLong())
            }
        })
    }

    /** Adds the blurred background, the golden visualizer, the verses box and the EQ / sleep timer buttons. */
    private fun buildExtras() {
        val frame = root as? FrameLayout ?: return
        blurBg.scaleType = ImageView.ScaleType.CENTER_CROP
        blurBg.alpha = 0.35f
        if (Build.VERSION.SDK_INT >= 31) {
            blurBg.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(40f, 40f, android.graphics.Shader.TileMode.CLAMP))
        }
        frame.addView(blurBg, 0, FrameLayout.LayoutParams(-1, -1))
        frame.addView(wave, 1, FrameLayout.LayoutParams(-1, (110 * dp).toInt(), Gravity.BOTTOM))

        // verses (Holy Quran): clear font, scrolls with the recitation
        verseText.apply {
            setTextColor(Color.parseColor("#FFF3D98B"))
            textSize = 24f
            typeface = Typeface.SERIF
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            setLineSpacing(0f, 1.45f)
            setPadding((8 * dp).toInt(), (4 * dp).toInt(), (8 * dp).toInt(), (4 * dp).toInt())
        }
        verseScroll.addView(verseText)
        verseScroll.visibility = View.GONE
        verseScroll.isVerticalScrollBarEnabled = false
        (sub.parent as? ViewGroup)?.let { column ->
            column.addView(verseScroll, column.indexOfChild(sub) + 1,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (112 * dp).toInt()).apply { topMargin = (6 * dp).toInt() })
        }

        // Holy Quran extras: reciter search + the mushaf sheet button (shown only in the Quran player)
        (sub.parent as? ViewGroup)?.let { column ->
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            fun pill(text: String, click: () -> Unit) = TextView(ctx).apply {
                this.text = text
                textSize = 14f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.parseColor("#FF1A1204"))
                setBackgroundColor(Color.parseColor("#FFD4AF37"))
                setPadding((14 * dp).toInt(), (7 * dp).toInt(), (14 * dp).toInt(), (7 * dp).toInt())
                setOnClickListener { click() }
            }
            val r = pill("🔎 ابحث عن قارئ") { showReciterSearch() }
            val m = pill("📖 المصحف") { showMushaf() }
            btnReciter = r
            btnMushaf = m
            row.addView(r, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = (8 * dp).toInt() })
            row.addView(m, LinearLayout.LayoutParams(-2, -2))
            row.visibility = View.GONE
            row.tag = "quranRow"
            column.addView(row, column.indexOfChild(sub) + 1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = (6 * dp).toInt() })
        }

        // the surah name above the golden disc (the disc can be dragged anywhere; the name follows)
        (disc.parent as? FrameLayout)?.let { holder ->
            discName.apply {
                setTextColor(Color.parseColor("#FFFFE29A"))
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setShadowLayer(8f, 0f, 0f, Color.BLACK)
                maxLines = 1
                visibility = View.GONE
            }
            holder.addView(discName, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            installDiscDrag(holder)
        }

        // EQ + sleep timer next to the record button
        (btnRec.parent as? LinearLayout)?.let { bar ->
            fun extra(res: Int, desc: String, action: () -> Unit) {
                val v = ImageView(ctx)
                v.setImageResource(res)
                v.contentDescription = desc
                v.background = btnRec.background?.constantState?.newDrawable()
                v.setPadding(btnRec.paddingLeft, btnRec.paddingTop, btnRec.paddingRight, btnRec.paddingBottom)
                v.setOnClickListener { action() }
                val lp = btnRec.layoutParams
                bar.addView(v, if (lp is LinearLayout.LayoutParams) LinearLayout.LayoutParams(lp) else LinearLayout.LayoutParams((44 * dp).toInt(), (44 * dp).toInt()))
            }
            extra(R.drawable.ic_eq, "مؤثرات الصوت (EQ)") { SoundFx.showDialog(ctx) }
            extra(R.drawable.ic_moon, "مؤقت النوم") { showSleepDialog() }
            styleBar(bar)
        }
    }

    /** One tidy rounded bar: all the buttons evenly spaced, the play button bigger in the middle. */
    private fun styleBar(bar: LinearLayout) {
        bar.setBackgroundResource(R.drawable.bg_audio_bar)
        bar.setPadding((10 * dp).toInt(), (8 * dp).toInt(), (10 * dp).toInt(), (8 * dp).toInt())
        bar.gravity = Gravity.CENTER
        for (i in 0 until bar.childCount) {
            val child = bar.getChildAt(i)
            val lp = child.layoutParams as? LinearLayout.LayoutParams ?: continue
            lp.marginStart = (5 * dp).toInt()
            lp.marginEnd = (5 * dp).toInt()
            child.layoutParams = lp
        }
        // order: mute, prev, PLAY, next, record | EQ, sleep (unchanged order, now evenly spaced)
    }

    // ------------------------------------------------------------------ floating lists window

    /** Two independent scrolling columns (sections / stations) floating over the player. */
    private fun showLists() {
        val frame = root as? FrameLayout ?: return
        if (listsWindow != null) return
        val scrim = FrameLayout(ctx).apply {
            setBackgroundColor(0x99000000.toInt())
            isClickable = true
            setOnClickListener { hideLists() }
        }
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_audio_bar)
            setPadding((8 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt())
            isClickable = true
        }
        val columns = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        fun column(title: TextView, adapter: RowAdapter): LinearLayout {
            val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            title.apply {
                setTextColor(Color.parseColor("#FFD4AF37"))
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            box.addView(title, LinearLayout.LayoutParams(-1, (30 * dp).toInt()))
            val list = androidx.recyclerview.widget.RecyclerView(ctx).apply {
                layoutManager = androidx.recyclerview.widget.LinearLayoutManager(ctx)
                this.adapter = adapter
                itemAnimator = null
                isVerticalScrollBarEnabled = true
                scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
                overScrollMode = View.OVER_SCROLL_NEVER
            }
            box.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
            return box
        }
        columns.addView(column(tvChTitle, chAdapter), LinearLayout.LayoutParams(0, -1, 1f).apply { marginEnd = (4 * dp).toInt() })
        columns.addView(column(tvSecTitle, secAdapter), LinearLayout.LayoutParams(0, -1, 1f).apply { marginStart = (4 * dp).toInt() })
        card.addView(columns, LinearLayout.LayoutParams(-1, 0, 1f))
        card.addView(
            TextView(ctx).apply {
                text = "اضغط خارج النافذة لإغلاقها — المحطة تستمر بالعمل"
                setTextColor(Color.parseColor("#FFB8A878"))
                textSize = 11f
                gravity = Gravity.CENTER
            },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = (4 * dp).toInt() }
        )
        val metrics = ctx.resources.displayMetrics
        scrim.addView(
            card,
            FrameLayout.LayoutParams((metrics.widthPixels * 0.86f).toInt(), (metrics.heightPixels * 0.82f).toInt(), Gravity.CENTER)
        )
        frame.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        listsWindow = scrim
        host.onListsOpened()
    }

    fun hideLists() {
        listsWindow?.let { (root as? FrameLayout)?.removeView(it) }
        listsWindow = null
    }

    fun setSections(rows: List<Row>, title: String) {
        secAdapter.submit(rows)
        tvSecTitle.text = title
    }

    fun setChannels(rows: List<Row>, title: String) {
        chAdapter.submit(rows)
        tvChTitle.text = title
    }

    fun setSelectedSection(tag: String?) {
        secAdapter.selectedTag = tag
    }

    fun setPlayingUrl(url: String?) {
        chAdapter.playingUrl = url
    }

    private fun showSleepDialog() {
        val options = arrayOf("15 دقيقة", "30 دقيقة", "45 دقيقة", "60 دقيقة", "90 دقيقة", "إلغاء المؤقت")
        val minutes = intArrayOf(15, 30, 45, 60, 90, 0)
        val title = if (SleepTimer.isActive) "مؤقت النوم — متبقٍ ${SleepTimer.remainingMinutes()} د" else "مؤقت النوم (الصوت يخفت تدريجياً)"
        androidx.appcompat.app.AlertDialog.Builder(ctx, R.style.GoldDialog)
            .setTitle(title)
            .setItems(options) { _, which ->
                if (minutes[which] == 0) {
                    SleepTimer.cancel()
                } else {
                    SleepTimer.start(ctx, minutes[which])
                    android.widget.Toast.makeText(ctx, "سيتوقف الصوت بعد ${options[which]}", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    // ------------------------------------------------------------------ Holy Quran: resume, drag, search, mushaf

    private fun installDiscDrag(holder: FrameLayout) {
        var downX = 0f
        var downY = 0f
        var startTx = 0f
        var startTy = 0f
        disc.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startTx = disc.translationX; startTy = disc.translationY
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val maxX = (root.width / 2f - disc.width / 2f).coerceAtLeast(0f)
                    val maxY = (root.height / 2f - disc.height / 2f).coerceAtLeast(0f)
                    // the holder is the left half: allow moving over the whole screen
                    disc.translationX = (startTx + e.rawX - downX).coerceIn(-maxX * 1.0f - holder.left, maxX * 2f)
                    disc.translationY = (startTy + e.rawY - downY).coerceIn(-maxY, maxY)
                    followDisc()
                    true
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    prefs.discX = disc.translationX / (root.width.coerceAtLeast(1))
                    prefs.discY = disc.translationY / (root.height.coerceAtLeast(1))
                    true
                }
                else -> false
            }
        }
    }

    private fun followDisc() {
        discName.translationX = disc.translationX
        discName.translationY = disc.translationY - (disc.height / 2f + 22 * dp)
    }

    private fun restoreDisc() {
        root.post {
            disc.translationX = prefs.discX * root.width
            disc.translationY = prefs.discY * root.height
            followDisc()
        }
    }

    /** Saves reciter + surah + second (every 4 s while playing, and when the player closes). */
    private fun saveQuranPosition(force: Boolean = false) {
        if (!quranMode || currentUrl.isBlank()) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (!force && now - lastSaveAt < 4000L) return
        val c = host.controller() ?: return
        val position = c.currentPosition
        if (position <= 0L) return
        lastSaveAt = now
        prefs.saveQuranResume(currentUrl, currentTitle, currentGroup, position)
    }

    private fun showReciterSearch() {
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding((12 * dp).toInt(), (8 * dp).toInt(), (12 * dp).toInt(), 0) }
        val input = android.widget.EditText(ctx).apply {
            hint = "اكتب اسم القارئ (يتجاهل التشكيل والهمزات)"
            textSize = 15f
            setTextColor(Color.WHITE)
            setHintTextColor(0x88FFFFFF.toInt())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            isSingleLine = true
        }
        val list = android.widget.ListView(ctx)
        box.addView(input)
        box.addView(list, LinearLayout.LayoutParams(-1, (220 * dp).toInt()))
        val all = ArrayList<Pair<String, String>>() // id to title
        val shown = ArrayList<Pair<String, String>>()
        val adapter = android.widget.ArrayAdapter<String>(ctx, android.R.layout.simple_list_item_1, ArrayList())
        list.adapter = adapter
        fun refreshList() {
            val tokens = ArabicText.normalize(input.text.toString()).split(' ').filter { it.isNotEmpty() }
            shown.clear()
            shown.addAll(all.filter { (_, title) ->
                val n = ArabicText.normalize(title)
                tokens.all { n.contains(it) }
            }.take(120))
            adapter.clear()
            adapter.addAll(shown.map { it.second })
        }
        val dialog = androidx.appcompat.app.AlertDialog.Builder(ctx, R.style.GoldDialog)
            .setTitle("🔎 البحث عن قارئ")
            .setView(box)
            .setNegativeButton("إغلاق", null)
            .create()
        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) = refreshList()
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        list.setOnItemClickListener { _, _, position, _ ->
            val picked = shown.getOrNull(position) ?: return@setOnItemClickListener
            dialog.dismiss()
            host.openReciter(picked.first, picked.second)
            showLists()
        }
        dialog.show()
        net.execute {
            try {
                val pkgs = QuranClient.packages(false)
                root.post { all.addAll(pkgs.map { it.id to it.title }); refreshList() }
            } catch (_: Throwable) {
            }
        }
    }

    private val mushafTick = object : Runnable {
        override fun run() {
            val scroll = mushafScroll
            val c = host.controller()
            if (mushafCard?.visibility == View.VISIBLE && scroll != null && c != null) {
                val inner = (mushafText?.height ?: 0) - scroll.height
                if (inner > 0 && !scrollTouching && scrollSpeed > 0f && (c.isPlaying || c.playWhenReady)) {
                    val duration = c.duration
                    if (duration > 0) {
                        if (scrollSpeed == 1f) {
                            scroll.scrollTo(0, (inner * (c.currentPosition.toFloat() / duration)).toInt()) // exact sync
                        } else {
                            scrollAcc += inner.toFloat() / duration * 100f * scrollSpeed
                            if (scrollAcc >= 1f) {
                                scroll.scrollBy(0, scrollAcc.toInt())
                                scrollAcc -= scrollAcc.toInt()
                            }
                        }
                    }
                }
                handler.postDelayed(this, 100L)
            }
        }
    }

    private val mushafThemes = arrayOf(
        // name, paper, text, frame
        arrayOf("المصحف العثماني الكريمي", "#FFF6EBCB", "#FF2B1B05", "#FFC9A24A"),
        arrayOf("الأخضر الزمردي المزخرف", "#FF0E3B2E", "#FFF4E7B2", "#FFD4AF37"),
        arrayOf("الليلي الأسود والذهبي", "#FF0A0A0A", "#FFE8C766", "#FFB8912F"),
        arrayOf("ورق الرق التراثي", "#FFE3CFA0", "#FF4A2F12", "#FF8B5E34")
    )
    private val fontSizes = floatArrayOf(18f, 24f, 30f, 38f, 48f)
    private val fontNames = arrayOf("صغير", "متوسط", "كبير", "كبير جداً", "ضخم")
    private val speeds = floatArrayOf(0f, 0.5f, 0.75f, 1f, 1.25f, 1.5f)
    private val speedNames = arrayOf("⏸ إيقاف", "0.5x", "0.75x", "1.0x", "1.25x", "1.5x")

    private fun arabicDigits(n: Int): String = n.toString().map { ('٠' + (it - '0')) }.joinToString("")

    private fun applyMushafStyle() {
        val card = mushafCard ?: return
        val t = mushafThemes[prefs.mushafTheme.coerceIn(0, 3)]
        val paper = Color.parseColor(t[1])
        val frame = Color.parseColor(t[3])
        val outer = android.graphics.drawable.GradientDrawable().apply {
            setColor(paper); setStroke((5 * dp).toInt(), frame); cornerRadius = 14 * dp
        }
        val inner = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.TRANSPARENT); setStroke((2 * dp).toInt(), frame); cornerRadius = 8 * dp
        }
        val layers = android.graphics.drawable.LayerDrawable(arrayOf(outer, inner))
        layers.setLayerInset(1, (12 * dp).toInt(), (12 * dp).toInt(), (12 * dp).toInt(), (12 * dp).toInt())
        card.background = layers
        mushafText?.setTextColor(Color.parseColor(t[2]))
        mushafText?.textSize = fontSizes[prefs.mushafFont.coerceIn(0, 4)]
        mushafTitle?.setTextColor(Color.parseColor(t[2]))
    }

    private fun buildMushafText() {
        val tv = mushafText ?: return
        if (ayahs.isEmpty()) {
            tv.text = "جارٍ تحميل الآيات…"
            return
        }
        val sb = StringBuilder("\n")
        for (i in ayahs.indices) sb.append(ayahs[i]).append(" ﴿").append(arabicDigits(i + 1)).append("﴾ ")
        sb.append("\n\n\n")
        tv.text = sb.toString()
    }

    /** The mushaf sheet: ornamented page that rises with the recitation. */
    private fun showMushaf() {
        val frame = root as? FrameLayout ?: return
        if (mushafCard == null) {
            val card = FrameLayout(ctx).apply { isClickable = true }
            val column = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((22 * dp).toInt(), (20 * dp).toInt(), (22 * dp).toInt(), (20 * dp).toInt())
            }
            val title = TextView(ctx).apply {
                textSize = 20f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            }
            mushafTitle = title
            fun scrollRow(): Pair<android.widget.HorizontalScrollView, LinearLayout> {
                val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val sv = android.widget.HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(row) }
                return sv to row
            }
            fun chip(text: String, click: () -> Unit) = TextView(ctx).apply {
                this.text = text; textSize = 12f; gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#FF1A1204"))
                setBackgroundColor(Color.parseColor("#FFD4AF37"))
                setPadding((10 * dp).toInt(), (5 * dp).toInt(), (10 * dp).toInt(), (5 * dp).toInt())
                setOnClickListener { click() }
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins((3 * dp).toInt(), (2 * dp).toInt(), (3 * dp).toInt(), (2 * dp).toInt()) }
            }
            val (sv1, row1) = scrollRow()
            row1.addView(chip("✕ إغلاق") { hideMushaf() })
            row1.addView(chip("▶ / ⏸") { host.controller()?.let { if (it.isPlaying || it.playWhenReady) it.pause() else it.play() } })
            row1.addView(chip("🎨 شكل المصحف") {
                prefs.mushafTheme = (prefs.mushafTheme + 1) % mushafThemes.size
                applyMushafStyle()
                android.widget.Toast.makeText(ctx, mushafThemes[prefs.mushafTheme][0], android.widget.Toast.LENGTH_SHORT).show()
            })
            for (i in fontNames.indices) row1.addView(chip("A " + fontNames[i]) { prefs.mushafFont = i; applyMushafStyle() })
            val (sv2, row2) = scrollRow()
            for (i in speeds.indices) row2.addView(chip("↑ " + speedNames[i]) { scrollSpeed = speeds[i]; scrollAcc = 0f })
            val scroll = ScrollView(ctx).apply {
                isVerticalScrollBarEnabled = false
                setOnTouchListener { _, e ->
                    when (e.actionMasked) {
                        android.view.MotionEvent.ACTION_DOWN -> scrollTouching = true
                        android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                            handler.postDelayed({ scrollTouching = false }, 1500L)
                    }
                    false
                }
            }
            val text = TextView(ctx).apply {
                typeface = Typeface.SERIF
                gravity = Gravity.CENTER
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                textDirection = View.TEXT_DIRECTION_RTL
                setLineSpacing(0f, 1.6f)
            }
            mushafText = text
            mushafScroll = scroll
            scroll.addView(text)
            column.addView(title)
            column.addView(sv1)
            column.addView(sv2)
            column.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = (6 * dp).toInt() })
            card.addView(column, FrameLayout.LayoutParams(-1, -1))
            frame.addView(card, FrameLayout.LayoutParams(-1, -1).apply { setMargins((10 * dp).toInt(), (6 * dp).toInt(), (10 * dp).toInt(), (6 * dp).toInt()) })
            mushafCard = card
        }
        mushafTitle?.text = "﴿ $currentTitle ﴾"
        applyMushafStyle()
        buildMushafText()
        mushafCard?.visibility = View.VISIBLE
        mushafCard?.bringToFront()
        scrollAcc = 0f
        handler.removeCallbacks(mushafTick)
        handler.post(mushafTick)
    }

    private fun hideMushaf() {
        mushafCard?.visibility = View.GONE
        handler.removeCallbacks(mushafTick)
    }

    private fun attachVisualizer() {
        releaseVisualizer()
        try {
            if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECORD_AUDIO)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) return
            val session = PlaybackService.instance?.audioSessionId() ?: 0
            if (session <= 0) return
            val v = Visualizer(session)
            v.captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(visualizer: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(visualizer: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft != null) wave.setFft(fft)
                }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            v.enabled = true
            visualizer = v
        } catch (_: Throwable) {
            visualizer = null // the animated wave is used instead
        }
    }

    private fun releaseVisualizer() {
        try { visualizer?.enabled = false; visualizer?.release() } catch (_: Throwable) {}
        visualizer = null
    }

    private fun loadVerses(url: String) {
        val number = Regex("(\\d{1,3})\\.mp3").find(url)?.groupValues?.get(1)?.toIntOrNull()
        if (number == null || number !in 1..114) {
            verseScroll.visibility = View.GONE
            return
        }
        val key = number.toString()
        verseScroll.visibility = View.VISIBLE
        if (versesFor == key) return
        versesFor = key
        verseText.text = "جارٍ تحميل الآيات…"
        net.execute {
            try {
                val json = JSONObject(NetConfig.getText("https://api.alquran.cloud/v1/surah/$number/quran-simple"))
                val ayahs = json.getJSONObject("data").getJSONArray("ayahs")
                val sb = StringBuilder()
                val list = ArrayList<String>()
                for (i in 0 until ayahs.length()) {
                    val t = ayahs.getJSONObject(i).getString("text")
                    list.add(t)
                    sb.append(t).append(" ﴿").append(i + 1).append("﴾  ")
                }
                root.post {
                    if (versesFor == key) {
                        this.ayahs = list
                        verseText.text = sb.toString()
                        verseScroll.scrollTo(0, 0)
                        buildMushafText()
                    }
                }
            } catch (_: Throwable) {
                root.post { if (versesFor == key) verseText.text = "تعذّر تحميل الآيات — تحقق من الإنترنت" }
            }
        }
    }

    /** [quran] = surah mode (shows the progress bar and the previous / next surah). */
    fun show(name: String, subtitle: String, quran: Boolean, logo: String = "", url: String = "") {
        title.text = name
        sub.text = subtitle
        if (logo.isNotBlank()) {
            icon.layoutParams = icon.layoutParams.apply { width = (150 * dp).toInt(); height = (150 * dp).toInt() }
            icon.load(logo) {
                transformations(CircleCropTransformation())
                error(if (quran) R.drawable.ic_quran else R.drawable.ic_radio)
            }
            blurBg.load(logo) { size(32, 32) }
        } else {
            icon.layoutParams = icon.layoutParams.apply { width = (64 * dp).toInt(); height = (64 * dp).toInt() }
            icon.setImageResource(if (quran) R.drawable.ic_quran else R.drawable.ic_radio)
            blurBg.setImageDrawable(null)
        }
        quranMode = quran
        currentUrl = url
        currentTitle = name
        currentGroup = subtitle
        if (quran) loadVerses(url) else { verseScroll.visibility = View.GONE; versesFor = ""; ayahs = emptyList(); hideMushaf() }
        (btnMushaf?.parent as? View)?.visibility = if (quran) View.VISIBLE else View.GONE
        discName.visibility = if (quran) View.VISIBLE else View.GONE
        discName.text = name
        if (quran && logo.isBlank()) {
            // golden Islamic emblem when the reciter has no picture
            icon.layoutParams = icon.layoutParams.apply { width = (120 * dp).toInt(); height = (120 * dp).toInt() }
            icon.setImageResource(R.drawable.ic_quran)
        }
        restoreDisc()
        root.visibility = View.VISIBLE
        attachVisualizer()
        handler.removeCallbacks(tick)
        handler.post(tick)
        if (spin == null) {
            spin = ObjectAnimator.ofFloat(disc, View.ROTATION, 0f, 360f).apply {
                duration = 14_000L
                interpolator = LinearInterpolator()
                repeatCount = ValueAnimator.INFINITE
                start()
            }
        }
        refresh()
    }

    fun hide() {
        saveQuranPosition(force = true)
        hideMushaf()
        hideLists()
        releaseVisualizer()
        handler.removeCallbacks(tick)
        spin?.cancel()
        spin = null
        root.visibility = View.GONE
        host.onClosed()
    }

    fun setTitle(name: String, subtitle: String) {
        title.text = name
        sub.text = subtitle
    }

    fun setMuted(value: Boolean) {
        muted = value
        btnMute.setImageResource(if (value) R.drawable.ic_mute else R.drawable.ic_volume)
        host.onMuteChanged(value)
    }

    fun resetMute() {
        muted = false
        btnMute.setImageResource(R.drawable.ic_volume)
    }

    /** Shows the running recording time (or hides it when [text] is null). */
    fun setRecording(text: String?) {
        if (text == null) {
            recTimer.visibility = View.INVISIBLE
            btnRec.setImageResource(R.drawable.ic_record)
        } else {
            recTimer.visibility = View.VISIBLE
            recTimer.text = "● $text"
            btnRec.setImageResource(R.drawable.ic_stop)
        }
    }

    private fun refresh() {
        val c = host.controller()
        if (c == null) {
            btnPlay.setImageResource(R.drawable.ic_play)
            return
        }
        val playing = c.isPlaying || (c.playWhenReady && c.playbackState == Player.STATE_BUFFERING)
        wave.playing = playing
        if (visualizer == null && playing && root.visibility == View.VISIBLE && c.isPlaying) attachVisualizer()
        if (verseScroll.visibility == View.VISIBLE && c.duration > 0) {
            val inner = verseText.height - verseScroll.height
            if (inner > 0) verseScroll.scrollTo(0, (inner * (c.currentPosition.toFloat() / c.duration)).toInt())
        }
        btnPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        if (playing) saveQuranPosition()
        val s = spin
        if (s != null) {
            if (playing && s.isPaused) s.resume()
            if (!playing && s.isRunning) s.pause()
        }
        val duration = c.duration
        val known = duration > 0 && !c.isCurrentMediaItemLive
        seek.visibility = if (known) View.VISIBLE else View.INVISIBLE
        dur.text = if (known) format(duration) else "مباشر"
        if (known && !dragging) {
            seek.max = duration.toInt()
            seek.progress = c.currentPosition.toInt()
            pos.text = format(c.currentPosition)
        } else if (!known) {
            pos.text = ""
        }
    }

    private fun format(ms: Long): String {
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    fun release() {
        releaseVisualizer()
        handler.removeCallbacksAndMessages(null)
        spin?.cancel()
        spin = null
    }
}
