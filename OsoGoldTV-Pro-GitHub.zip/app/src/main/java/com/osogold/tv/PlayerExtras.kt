package com.osogold.tv

import android.app.Dialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaFormat
import android.net.TrafficStats
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.PixelCopy
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.Player
import androidx.media3.exoplayer.video.VideoFrameMetadataListener
import coil.load
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.atomic.AtomicInteger

/** Every channel of the user's lists, loaded once and cached (used by the quick search and the match radar). */
object ChannelPool {
    private var cache: List<Channel> = emptyList()
    private var at = 0L

    suspend fun all(prefs: Prefs): List<Channel> {
        if (cache.isNotEmpty() && System.currentTimeMillis() - at < 10 * 60_000L) return cache
        val out = LinkedHashMap<String, Channel>()
        val ids = ArrayList<String>()
        ids.add("live")
        if (prefs.xtreamConfigured()) ids.add("x_live")
        prefs.customLists().forEach { ids.add("m3u:${it.id}") }
        for (id in ids) {
            try {
                for (c in Catalog.channels(prefs, id, null)) {
                    if (c.seriesId.isEmpty() && !c.url.contains("/movie/") && !c.url.contains("/series/")) out.putIfAbsent(c.url, c)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            }
            if (out.size > 60_000) break
        }
        cache = out.values.toList()
        at = System.currentTimeMillis()
        return cache
    }
}

/**
 * The extra tools of the player bar: EQ, quick channel search, last channel recall, clean snapshot,
 * stream info badge, today's matches, audio only, AI Live subtitles and casting to a TV.
 */
class PlayerExtras(
    private val activity: AppCompatActivity,
    private val prefs: Prefs,
    private val host: Host
) {

    interface Host {
        fun nowChannel(): Channel?
        fun streamUrl(): String?
        fun previousChannel(): Channel?
        fun playChannel(channel: Channel)
        fun currentRowsChannels(): List<Channel>
        fun isVlc(): Boolean
        fun vlc(): VlcEngine
        fun controller(): Player?
        fun snapshotRoot(): View?
        fun hideChrome(hidden: Boolean)
        fun rootFrame(): FrameLayout
        fun replayCurrent()
        fun ensureMedia3(then: () -> Unit)
        fun toast(text: String)
    }

    val subs: LiveSubtitleManager = LiveSubtitleManager(
        activity, prefs,
        object : LiveSubtitleManager.Host {
            override fun mainPlayer(): Player? = host.controller()
            override fun streamUrl(): String? = host.streamUrl()?.takeIf { it.startsWith("http") }
            override fun isVlc(): Boolean = host.isVlc()
            override fun overlayRoot(): FrameLayout = host.rootFrame()
            override fun toast(text: String) = host.toast(text)
            override fun setChannelVolume(volume: Float) {
                try { host.controller()?.volume = volume } catch (_: Throwable) {}
            }
        }
    )

    private val ui = Handler(Looper.getMainLooper())
    private val d = activity.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    var audioOnly = false
        private set

    // ------------------------------------------------------------------ the button strip

    /** The extra round gold icons as separate views, keyed like [StageButtons], so they can be placed in any bar. */
    fun buildButtons(sizeDp: Int = 32): List<Pair<String, View>> {
        val list = ArrayList<Pair<String, View>>()
        fun add(key: String, icon: Int, desc: String, action: () -> Unit) {
            list.add(key to ImageView(activity).apply {
                setImageResource(icon)
                setBackgroundResource(R.drawable.bg_control_dark)
                contentDescription = desc
                setPadding(dp(6), dp(6), dp(6), dp(6))
                setOnClickListener { action() }
                layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply {
                    marginStart = dp(3)
                    marginEnd = dp(3)
                }
            })
        }
        add("translate", R.drawable.ic_translate, "ترجمة فورية للعربية (AI Live)") { translateClick() }
        add("eq", R.drawable.ic_eq, "مؤثرات الصوت (EQ)") { SoundFx.showDialog(activity) }
        add("search", R.drawable.ic_search, "بحث سريع عن قناة") { showQuickChannelSearch() }
        add("recall", R.drawable.ic_recall, "القناة السابقة") { recall() }
        add("snap", R.drawable.ic_snap, "لقطة شاشة صافية") { snapshot() }
        add("info", R.drawable.ic_info, "معلومات البث") { toggleInfo() }
        add("matches", R.drawable.ic_ball, "مباريات اليوم") { MatchRadar.show(activity, prefs, host::playChannel) }
        add("audio", R.drawable.ic_headphones, "صوت فقط") { toggleAudioOnly() }
        add("cast", R.drawable.ic_cast, "توصيل بالتلفاز (Cast / TV)") { cast() }
        return list
    }

    /** A scrolling row of round gold icons (the strip inside the live rectangle). */
    fun buildStrip(sizeDp: Int = 32): View {
        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        for ((_, v) in buildButtons(sizeDp)) row.addView(v)
        return HorizontalScrollView(activity).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(row)
        }
    }

    // ------------------------------------------------------------------ AI Live subtitles / Cast

    private fun translateClick() {
        // one tap: LibVLC is switched to Media3 automatically, then the translation starts
        host.ensureMedia3 {
            if (!subs.active) subs.start()
            subs.showPanel(activity)
        }
    }

    private fun cast() {
        host.toast("اختر التلفاز من القائمة — الترجمة العربية المدمجة تظهر على الشاشة المنقولة")
        val intents = listOf(
            Intent(Settings.ACTION_CAST_SETTINGS),
            Intent("android.settings.WIFI_DISPLAY_SETTINGS"),
            Intent(Settings.ACTION_WIRELESS_SETTINGS)
        )
        for (i in intents) {
            try {
                activity.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: Exception) {
            }
        }
        host.toast("جهازك لا يوفّر شاشة البث اللاسلكي — استخدم خيار Cast من لوحة الإعدادات السريعة")
    }

    // ------------------------------------------------------------------ last channel recall

    private fun recall() {
        val prev = host.previousChannel()
        if (prev == null) host.toast("لا توجد قناة سابقة بعد") else host.playChannel(prev)
    }

    // ------------------------------------------------------------------ quick channel search (floating list)

    fun showQuickChannelSearch() {
        val dialog = Dialog(activity)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.TOP or Gravity.CENTER_HORIZONTAL)
            clearFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        }
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_overlay)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val et = EditText(activity).apply {
            hint = "ابحث عن قناة…"
            setHintTextColor(0x88FFFFFF.toInt())
            setTextColor(Color.WHITE)
            textSize = 15f
            setSingleLine()
            setBackgroundResource(R.drawable.bg_search)
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        box.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))
        val list = ListView(activity).apply {
            divider = null
            cacheColorHint = Color.TRANSPARENT
        }
        box.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)))

        var pool: List<Channel> = host.currentRowsChannels()
        var shown: List<Channel> = emptyList()
        val adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(position: Int) = shown[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val c = shown[position]
                val row = (convertView as? LinearLayout) ?: LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(6), dp(4), dp(6), dp(4))
                    addView(ImageView(activity).apply { scaleType = ImageView.ScaleType.FIT_CENTER },
                        LinearLayout.LayoutParams(dp(38), dp(28)))
                    addView(TextView(activity).apply {
                        setTextColor(Color.WHITE); textSize = 14f; maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                        setPadding(dp(10), 0, dp(10), 0)
                    }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                }
                val logo = row.getChildAt(0) as ImageView
                val label = row.getChildAt(1) as TextView
                label.text = c.name
                if (c.logo.isNotBlank()) logo.load(c.logo) { crossfade(false) } else logo.setImageResource(R.drawable.ic_live)
                return row
            }
        }
        list.adapter = adapter
        fun refilter() {
            val q = ArabicText.normalize(et.text.toString().trim())
            shown = if (q.isEmpty()) pool.take(60)
            else pool.filter { ArabicText.normalize(it.name).contains(q) || ArabicText.normalize(it.group).contains(q) }.take(60)
            adapter.notifyDataSetChanged()
        }
        refilter()
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = refilter()
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        list.setOnItemClickListener { _, _, position, _ ->
            host.playChannel(shown[position])
            dialog.dismiss()
        }
        activity.lifecycleScope.launch {
            try {
                val all = ChannelPool.all(prefs)
                if (all.isNotEmpty()) {
                    pool = (host.currentRowsChannels() + all).distinctBy { it.url }
                    refilter()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            }
        }
        dialog.setContentView(box)
        dialog.window?.setLayout(minOf(dp(420), activity.resources.displayMetrics.widthPixels - dp(16)), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
        et.requestFocus()
    }

    // ------------------------------------------------------------------ clean snapshot

    private fun findSurface(v: View?): View? {
        if (v == null || v.visibility != View.VISIBLE) return null
        if ((v is SurfaceView || v is TextureView) && v.width > 0) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) findSurface(v.getChildAt(i))?.let { return it }
        return null
    }

    fun snapshot() {
        val surface = findSurface(host.snapshotRoot())
        if (surface == null) {
            host.toast("لا توجد صورة لالتقاطها")
            return
        }
        host.hideChrome(true)
        ui.postDelayed({
            try {
                // the picture is copied at the real video size (up to 4K), not at the size of the small view
                var w = surface.width
                var h = surface.height
                val size = try { PlaybackService.instance?.exo()?.videoSize } catch (_: Throwable) { null }
                if (!host.isVlc() && size != null && size.width > 0 && size.height > 0) {
                    val aspect = surface.width.toFloat() / surface.height.coerceAtLeast(1)
                    w = minOf(size.width, 3840).coerceAtLeast(surface.width)
                    h = (w / aspect).toInt().coerceAtLeast(1)
                }
                val bmp = Bitmap.createBitmap(w.coerceAtLeast(2), h.coerceAtLeast(2), Bitmap.Config.ARGB_8888)
                when (surface) {
                    is SurfaceView -> PixelCopy.request(surface, bmp, { result ->
                        host.hideChrome(false)
                        if (result == PixelCopy.SUCCESS) save(bmp) else host.toast("تعذّر التقاط الصورة")
                    }, ui)
                    is TextureView -> {
                        val t = surface.getBitmap(bmp)
                        host.hideChrome(false)
                        if (t != null) save(t) else host.toast("تعذّر التقاط الصورة")
                    }
                    else -> host.hideChrome(false)
                }
            } catch (e: Throwable) {
                host.hideChrome(false)
                host.toast("تعذّر التقاط الصورة: ${e.message ?: e.javaClass.simpleName}")
            }
        }, 160L)
    }

    private fun save(bmp: Bitmap) {
        activity.lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val name = "OsoGold_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
                    if (Build.VERSION.SDK_INT >= 29) {
                        val values = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, name)
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/OsoGoldTV")
                            put(MediaStore.Images.Media.IS_PENDING, 1)
                        }
                        val resolver = activity.contentResolver
                        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
                        resolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                        values.clear()
                        values.put(MediaStore.Images.Media.IS_PENDING, 0)
                        resolver.update(uri, values, null, null)
                        true
                    } else {
                        @Suppress("DEPRECATION")
                        MediaStore.Images.Media.insertImage(activity.contentResolver, bmp, name, "OsoGoldTV") != null
                    }
                } catch (_: Throwable) {
                    false
                }
            }
            host.toast(if (ok) "📷 تم حفظ اللقطة في ألبوم الصور" else "تعذّر حفظ اللقطة")
        }
    }

    // ------------------------------------------------------------------ stream info badge

    private var badge: TextView? = null
    private val frames = AtomicInteger(0)
    private var lastBytes = 0L
    private var lastTime = 0L
    private var infoOn = false

    private val infoTick = object : Runnable {
        override fun run() {
            if (!infoOn) return
            updateBadge()
            ui.postDelayed(this, 1000L)
        }
    }

    private val frameListener = VideoFrameMetadataListener { _: Long, _: Long, _: Format, _: MediaFormat? ->
        frames.incrementAndGet()
    }

    fun restoreInfo() {
        if (prefs.infoBadge && !infoOn) startInfo()
    }

    private fun toggleInfo() {
        prefs.infoBadge = !prefs.infoBadge
        if (prefs.infoBadge) startInfo() else stopInfo()
    }

    private fun startInfo() {
        infoOn = true
        val tv = badge ?: TextView(activity).apply {
            setTextColor(Color.parseColor("#FFD4AF37"))
            textSize = 11f
            setBackgroundColor(0xAA000000.toInt())
            setPadding(dp(8), dp(3), dp(8), dp(3))
            elevation = 50f
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }.also {
            host.rootFrame().addView(it, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            ).apply { topMargin = dp(36); marginEnd = dp(8) })
            badge = it
        }
        tv.visibility = View.VISIBLE
        lastBytes = TrafficStats.getUidRxBytes(Process.myUid())
        lastTime = System.currentTimeMillis()
        frames.set(0)
        try { PlaybackService.instance?.exo()?.setVideoFrameMetadataListener(frameListener) } catch (_: Throwable) {}
        ui.removeCallbacks(infoTick)
        ui.post(infoTick)
    }

    private fun stopInfo() {
        infoOn = false
        ui.removeCallbacks(infoTick)
        badge?.visibility = View.GONE
        try { PlaybackService.instance?.exo()?.clearVideoFrameMetadataListener(frameListener) } catch (_: Throwable) {}
    }

    private fun updateBadge() {
        var width = 0
        var height = 0
        var fps = 0f
        try {
            if (host.isVlc()) {
                host.vlc().videoInfo()?.let { width = it.first; height = it.second; fps = it.third }
            } else {
                val exo = PlaybackService.instance?.exo()
                val f = exo?.videoFormat
                if (f != null) {
                    width = f.width; height = f.height
                    fps = frames.getAndSet(0).toFloat().takeIf { it > 0 } ?: f.frameRate.takeIf { it > 0 } ?: 0f
                    // re-register in case the player was recreated
                    exo.setVideoFrameMetadataListener(frameListener)
                }
            }
        } catch (_: Throwable) {
        }
        val now = System.currentTimeMillis()
        val bytes = TrafficStats.getUidRxBytes(Process.myUid())
        val seconds = ((now - lastTime) / 1000.0).coerceAtLeast(0.5)
        val mbps = if (bytes >= lastBytes && lastBytes > 0) (bytes - lastBytes) * 8 / 1_000_000.0 / seconds else 0.0
        lastBytes = bytes
        lastTime = now
        val label = when {
            width <= 0 || height <= 0 -> "—"
            width >= 3800 || height >= 2100 -> "4K ${width}×$height"
            height >= 1400 -> "2K ${width}×$height"
            else -> "${height}p ${width}×$height"
        }
        badge?.text = "$label  |  ${if (fps > 0) String.format(Locale.US, "%.0f", fps) else "—"} FPS  |  " +
            String.format(Locale.US, "%.1f", mbps) + " Mbps"
    }

    // ------------------------------------------------------------------ audio only

    fun toggleAudioOnly() = setAudioOnly(!audioOnly)

    fun setAudioOnly(on: Boolean) {
        if (on == audioOnly) return
        audioOnly = on
        AppState.keepAudio = on
        try {
            if (host.isVlc()) {
                if (on) host.vlc().setVideoEnabled(false) else host.replayCurrent()
            } else {
                val c = host.controller()
                if (c != null) {
                    c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, on).build()
                }
            }
        } catch (_: Throwable) {
        }
        host.toast(if (on) "🎧 وضع الصوت فقط — يستمر الصوت في الخلفية لتوفير البطارية" else "عاد الفيديو")
    }

    /** A new channel starts: audio-only is switched off (the new picture is wanted) and the hidden copy follows. */
    fun onChannelStarted() {
        if (audioOnly) {
            audioOnly = false
            AppState.keepAudio = false
            try {
                val c = host.controller()
                c?.let { it.trackSelectionParameters = it.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false).build() }
            } catch (_: Throwable) {
            }
        }
        subs.onStreamChanged()
        if (infoOn) {
            frames.set(0)
        }
    }

    fun release() {
        stopInfo()
        subs.stop()
    }
}

/** Today's matches (TheSportsDB, free) in the user's time zone; a tap finds the channel that carries it. */
object MatchRadar {

    private class Match(val home: String, val away: String, val league: String, val timeMs: Long, val stations: List<String>)

    fun show(activity: AppCompatActivity, prefs: Prefs, play: (Channel) -> Unit) {
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val dialog = Dialog(activity)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_overlay)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        box.addView(TextView(activity).apply {
            text = "⚽ مباريات اليوم"
            setTextColor(activity.getColor(R.color.gold_light)); textSize = 17f; gravity = Gravity.CENTER
        })
        val status = TextView(activity).apply {
            text = "جارٍ تحميل المباريات…"; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        box.addView(status)
        var matches: List<Match> = emptyList()
        val list = ListView(activity).apply { divider = null; cacheColorHint = Color.TRANSPARENT }
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        list.adapter = object : BaseAdapter() {
            override fun getCount() = matches.size
            override fun getItem(position: Int) = matches[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val m = matches[position]
                return TextView(activity).apply {
                    setTextColor(Color.WHITE); textSize = 14f
                    setPadding(dp(8), dp(9), dp(8), dp(9))
                    text = fmt.format(Date(m.timeMs)) + "   " + m.home + "  ×  " + m.away + "\n" + m.league
                }
            }
        }
        box.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)))
        list.setOnItemClickListener { _, _, position, _ ->
            val m = matches[position]
            dialog.dismiss()
            findChannel(activity, prefs, m, play)
        }
        dialog.setContentView(box)
        dialog.window?.setLayout(minOf(dp(460), activity.resources.displayMetrics.widthPixels - dp(16)), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()

        activity.lifecycleScope.launch {
            try {
                val found = withContext(Dispatchers.IO) { load() }
                matches = found
                (list.adapter as BaseAdapter).notifyDataSetChanged()
                status.text = if (found.isEmpty()) "لا توجد مباريات مسجّلة اليوم" else "اضغط على المباراة لتشغيل القناة الناقلة"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status.text = "تعذّر تحميل المباريات: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    private fun load(): List<Match> {
        val zone = TimeZone.getDefault()
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val today = System.currentTimeMillis()
        val out = ArrayList<Match>()
        val seen = HashSet<String>()
        val parse = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val localDay = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = zone }
        val todayText = localDay.format(Date(today))
        for (shift in listOf(-1, 0, 1)) {
            val date = day.format(Date(today + shift * 86_400_000L))
            val text = try {
                NetConfig.getText("https://www.thesportsdb.com/api/v1/json/3/eventsday.php?d=$date&s=Soccer")
            } catch (_: Exception) { continue }
            val events = JSONObject(text).optJSONArray("events") ?: continue
            for (i in 0 until events.length()) {
                val e = events.optJSONObject(i) ?: continue
                val stamp = e.optString("strTimestamp").take(19)
                val ms = try { parse.parse(stamp)?.time } catch (_: Exception) { null } ?: continue
                if (localDay.format(Date(ms)) != todayText) continue
                val id = e.optString("idEvent")
                if (!seen.add(id)) continue
                val stations = e.optString("strTVStation").split(',', ';', '/').map { it.trim() }.filter { it.length >= 3 }
                out.add(Match(e.optString("strHomeTeam"), e.optString("strAwayTeam"), e.optString("strLeague"), ms, stations))
            }
        }
        return out.sortedBy { it.timeMs }
    }

    private fun words(text: String): List<String> =
        ArabicText.normalize(text).split(' ', '-', '.').filter { it.length >= 4 }

    private fun findChannel(activity: AppCompatActivity, prefs: Prefs, m: Match, play: (Channel) -> Unit) {
        activity.lifecycleScope.launch {
            val pool = try { ChannelPool.all(prefs) } catch (e: CancellationException) { throw e } catch (_: Exception) { emptyList() }
            val teams = words(m.home) + words(m.away)
            val stationWords = m.stations.flatMap { words(it) }
            val sport = Regex("sport|bein|ssc|dazn|eurosport|arryadia|ad sports|tod|spor|match|kora|كأس|رياض|سبورت|بي ان|الكاس")
            val scored = pool.map { c ->
                val n = ArabicText.normalize(c.name)
                var s = 0
                if (stationWords.any { n.contains(it) }) s += 10
                if (teams.any { n.contains(it) }) s += 8
                if (sport.containsMatchIn(n) || sport.containsMatchIn(ArabicText.normalize(c.group))) s += 1
                c to s
            }.filter { it.second > 0 }.sortedByDescending { it.second }
            val top = scored.firstOrNull()
            if (top != null && top.second >= 8) {
                Toasts.show(activity, "تشغيل: ${top.first.name}")
                play(top.first)
            } else if (scored.isNotEmpty()) {
                val choices = scored.take(40).map { it.first }
                androidx.appcompat.app.AlertDialog.Builder(activity, R.style.GoldDialog)
                    .setTitle("القنوات الرياضية في قوائمك — اختر الناقلة")
                    .setItems(choices.map { it.name }.toTypedArray()) { _, which -> play(choices[which]) }
                    .setNegativeButton("إغلاق", null)
                    .show()
            } else {
                Toasts.show(activity, "لم أجد قناة ناقلة في قوائمك")
            }
        }
    }
}

private object Toasts {
    fun show(context: Context, text: String) = android.widget.Toast.makeText(context, text, android.widget.Toast.LENGTH_SHORT).show()
}
