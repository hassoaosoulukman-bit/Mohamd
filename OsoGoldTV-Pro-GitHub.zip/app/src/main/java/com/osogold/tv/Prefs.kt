package com.osogold.tv

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/**
 * Small wrapper around SharedPreferences.
 *
 * - login state ("password asked only once") and password (SHA-256 hash)
 * - welcome video file
 * - playlist (M3U) sources and user playlists (link / file)
 * - Xtream Codes account (with optional pinned server), Stalker portal (MAC)
 * - custom User-Agent
 * - dual screen settings
 * - favourites
 */
class Prefs(context: Context) {

    private val appContext = context.applicationContext
    private val sp: SharedPreferences =
        appContext.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    /** AES-256 encrypted storage (EncryptedSharedPreferences) for subscriptions and API keys. */
    private val secure: SharedPreferences by lazy { SecureStore.prefs(appContext) }

    init {
        migrateSensitive()
    }

    /** Moves the subscription data written by older versions from the plain file to the encrypted one. */
    private fun migrateSensitive() {
        val keys = listOf(
            KEY_CUSTOM_LISTS, KEY_X_SERVER, KEY_X_USER, KEY_X_PASS,
            KEY_S_PORTAL, KEY_S_MAC, KEY_X_NAME, KEY_S_NAME
        )
        if (keys.none { sp.contains(it) }) return
        val target = secure.edit()
        val source = sp.edit()
        for (key in keys) {
            val value = sp.getString(key, null) ?: continue
            if (!secure.contains(key)) target.putString(key, value)
            source.remove(key)
        }
        target.apply()
        source.apply()
    }

    // ---------------------------------------------------------------- login / password

    /** True once the correct password has been entered. Reset when the password is changed. */
    var loggedIn: Boolean
        get() = sp.getBoolean(KEY_LOGGED_IN, false)
        set(value) {
            sp.edit().putBoolean(KEY_LOGGED_IN, value).apply()
        }

    fun checkPassword(input: String): Boolean {
        val stored = sp.getString(KEY_PASSWORD_HASH, null) ?: sha256(DEFAULT_PASSWORD)
        return sha256(input) == stored
    }

    /** Saves a new password. The password screen will be shown again on the next launch. */
    fun changePassword(newPassword: String) {
        sp.edit()
            .putString(KEY_PASSWORD_HASH, sha256(newPassword))
            .putBoolean(KEY_LOGGED_IN, false)
            .apply()
    }

    // ---------------------------------------------------------------- welcome video

    var welcomeVideoPath: String?
        get() = sp.getString(KEY_WELCOME_VIDEO, null)
        set(value) {
            sp.edit().putString(KEY_WELCOME_VIDEO, value).apply()
        }

    /** The saved welcome video, or null if none was chosen (or the file vanished). */
    fun welcomeVideoFile(): File? {
        val path = welcomeVideoPath ?: return null
        val file = File(path)
        return if (file.exists() && file.length() > 0L) file else null
    }

    // ---------------------------------------------------------------- playlist sources

    fun getSource(key: String): String =
        sp.getString(KEY_SOURCE_PREFIX + key, null) ?: DefaultData.defaultSource(key)

    fun setSource(key: String, url: String) {
        sp.edit().putString(KEY_SOURCE_PREFIX + key, url.trim()).apply()
    }

    fun resetSources() {
        val editor = sp.edit()
        DefaultData.sourceKeys.forEach { editor.remove(KEY_SOURCE_PREFIX + it) }
        editor.apply()
    }

    // ---------------------------------------------------------------- user playlists (link / file)

    fun customLists(): List<CustomList> {
        val json = secure.getString(KEY_CUSTOM_LISTS, null) ?: return emptyList()
        val result = ArrayList<CustomList>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                result.add(CustomList(o.optString("id"), o.optString("name"), o.optString("value")))
            }
        } catch (_: Exception) {
        }
        return result
    }

    private fun saveCustomLists(list: List<CustomList>) {
        val array = JSONArray()
        list.forEach {
            array.put(JSONObject().put("id", it.id).put("name", it.name).put("value", it.value))
        }
        secure.edit().putString(KEY_CUSTOM_LISTS, array.toString()).apply()
    }

    fun addCustomList(name: String, value: String): CustomList {
        val entry = CustomList(System.currentTimeMillis().toString(), name.trim().ifEmpty { "قائمة M3U" }, value.trim())
        saveCustomLists(customLists() + entry)
        return entry
    }

    /** Removes a list. A list that was copied from the phone is deleted from the app storage too. */
    fun removeCustomList(id: String) {
        val all = customLists()
        all.firstOrNull { it.id == id }?.let {
            if (it.value.startsWith("file:")) {
                try {
                    File(it.value.removePrefix("file:")).delete()
                } catch (_: Exception) {
                }
            }
        }
        saveCustomLists(all.filter { it.id != id })
    }

    // ---------------------------------------------------------------- Xtream Codes

    var xtreamServer: String
        get() = secure.getString(KEY_X_SERVER, "") ?: ""
        set(value) {
            secure.edit().putString(KEY_X_SERVER, value.trim()).apply()
        }

    var xtreamUser: String
        get() = secure.getString(KEY_X_USER, "") ?: ""
        set(value) {
            secure.edit().putString(KEY_X_USER, value.trim()).apply()
        }

    var xtreamPass: String
        get() = secure.getString(KEY_X_PASS, "") ?: ""
        set(value) {
            secure.edit().putString(KEY_X_PASS, value.trim()).apply()
        }

    /** The typed server was pinned as default: from now on only user name and password are asked. */
    var xtreamPinned: Boolean
        get() = sp.getBoolean(KEY_X_PINNED, false)
        set(value) {
            sp.edit().putBoolean(KEY_X_PINNED, value).apply()
        }

    /** The server really used: the one compiled into the app, otherwise the one typed by the user. */
    fun effectiveXtreamServer(): String =
        DefaultData.XTREAM_DEFAULT_SERVER.ifBlank { xtreamServer }

    fun isServerPinned(): Boolean =
        DefaultData.XTREAM_DEFAULT_SERVER.isNotBlank() || (xtreamPinned && xtreamServer.isNotBlank())

    fun xtreamConfigured(): Boolean =
        effectiveXtreamServer().isNotBlank() && xtreamUser.isNotBlank() && xtreamPass.isNotBlank()

    /** Deletes the account. A pinned server stays. */
    fun clearXtreamAccount() {
        val editor = secure.edit().remove(KEY_X_USER).remove(KEY_X_PASS)
        if (!xtreamPinned) editor.remove(KEY_X_SERVER)
        editor.apply()
    }

    fun unpinXtreamServer() {
        sp.edit().putBoolean(KEY_X_PINNED, false).apply()
    }

    // ---------------------------------------------------------------- Stalker portal (MAC)

    var stalkerPortal: String
        get() = secure.getString(KEY_S_PORTAL, "") ?: ""
        set(value) {
            secure.edit().putString(KEY_S_PORTAL, value.trim()).apply()
        }

    var stalkerMac: String
        get() = secure.getString(KEY_S_MAC, "") ?: ""
        set(value) {
            secure.edit().putString(KEY_S_MAC, value.trim()).apply()
        }

    fun stalkerConfigured(): Boolean = stalkerPortal.isNotBlank() && stalkerMac.isNotBlank()

    fun clearStalker() {
        secure.edit().remove(KEY_S_PORTAL).remove(KEY_S_MAC).apply()
    }

    // ---------------------------------------------------------------- User-Agent

    /** Player identity card sent to every server (IPTVSmartersPro, VLC, ExoPlayer, custom ...). */
    var userAgent: String
        get() = sp.getString(KEY_USER_AGENT, null)?.trim()?.takeIf { it.isNotEmpty() } ?: DEFAULT_USER_AGENT
        set(value) {
            sp.edit().putString(KEY_USER_AGENT, value.trim()).apply()
        }

    /** Names typed by the user for the subscriptions (shown on the "My lists" page). */
    var xtreamName: String
        get() = secure.getString(KEY_X_NAME, "") ?: ""
        set(value) {
            secure.edit().putString(KEY_X_NAME, value.trim()).apply()
        }

    var stalkerName: String
        get() = secure.getString(KEY_S_NAME, "") ?: ""
        set(value) {
            secure.edit().putString(KEY_S_NAME, value.trim()).apply()
        }

    // ---------------------------------------------------------------- dual screen

    /** 0 = medium, 1 = small, 2 = smallest. */
    var pipSize: Int
        get() = sp.getInt(KEY_PIP_SIZE, 1).coerceIn(0, 2)
        set(value) {
            sp.edit().putInt(KEY_PIP_SIZE, value.coerceIn(0, 2)).apply()
        }

    /** true = small screen in the bottom right corner, false = bottom left (default). */
    var pipRight: Boolean
        get() = sp.getBoolean(KEY_PIP_RIGHT, false)
        set(value) {
            sp.edit().putBoolean(KEY_PIP_RIGHT, value).apply()
        }

    /** Video shape of the big screen: 0 fill screen, 1 cinema, 2 original, 3 stretch. */
    var aspectMode: Int
        get() = sp.getInt(KEY_ASPECT_V2, 2).coerceIn(0, 3)
        set(value) {
            sp.edit().putInt(KEY_ASPECT_V2, value.coerceIn(0, 3)).apply()
        }

    // ---------------------------------------------------------------- player engine

    /** "exo" = Media3 / ExoPlayer (default, strongest) or "vlc" = LibVLC (secondary). */
    var playerEngine: String
        get() = sp.getString(KEY_ENGINE, ENGINE_EXO).let { if (it in ENGINES) it!! else ENGINE_EXO }
        set(value) {
            sp.edit().putString(KEY_ENGINE, if (value in ENGINES) value else ENGINE_EXO).apply()
        }

    val useVlc: Boolean
        get() = playerEngine == ENGINE_VLC

    // ---------------------------------------------------------------- subtitles

    /** Subtitle size in sp (12..48). */
    var subSize: Int
        get() = sp.getInt(KEY_SUB_SIZE, 20).coerceIn(12, 48)
        set(value) {
            sp.edit().putInt(KEY_SUB_SIZE, value.coerceIn(12, 48)).apply()
        }

    /** Index in [SubtitleStyle.COLORS]. */
    var subColor: Int
        get() = sp.getInt(KEY_SUB_COLOR, 0).coerceIn(0, SubtitleStyle.COLORS.size - 1)
        set(value) {
            sp.edit().putInt(KEY_SUB_COLOR, value.coerceIn(0, SubtitleStyle.COLORS.size - 1)).apply()
        }

    /** true = subtitles at the top of the screen, false = bottom (default). */
    var subTop: Boolean
        get() = sp.getBoolean(KEY_SUB_TOP, false)
        set(value) {
            sp.edit().putBoolean(KEY_SUB_TOP, value).apply()
        }

    // ---------------------------------------------------------------- favourites

    /** Kind of every favourite: "live", "movie", "series" or "radio" (url -> kind). */
    private var kinds = HashMap<String, String>()

    private fun inferKind(c: Channel): String {
        val ext = c.url.substringBefore('?').substringAfterLast('.', "").lowercase()
        return when {
            c.seriesId.isNotEmpty() -> "series"
            c.infoId.isNotEmpty() || c.url.contains("/movie/") -> "movie"
            c.url.contains("/series/") -> "series"
            ext in setOf("mp3", "aac", "m4a", "ogg", "pls") -> "radio"
            ext in setOf("mp4", "mkv", "avi", "mov") -> "movie"
            else -> "live"
        }
    }

    /** The favourites of one kind: "live", "movie", "series" or "radio". */
    fun favoritesOf(kind: String): List<Channel> {
        val all = favorites()
        return all.filter { kinds[it.url] == kind }
    }

    fun favoriteKind(url: String): String = kinds[url] ?: "live"

    fun removeFavorite(url: String) {
        val c = favorites().firstOrNull { it.url == url } ?: return
        toggleFavorite(c)
    }

    fun favorites(): List<Channel> {
        kinds = HashMap()
        val json = sp.getString(KEY_FAVORITES, null) ?: return emptyList()
        val result = ArrayList<Channel>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                result.add(
                    Channel(
                        name = o.optString("name"),
                        url = o.optString("url"),
                        logo = o.optString("logo"),
                        group = o.optString("group"),
                        seriesId = o.optString("seriesId"),
                        infoId = o.optString("infoId")
                    )
                )
                kinds[o.optString("url")] = o.optString("kind").ifBlank { inferKind(result.last()) }
            }
        } catch (_: Exception) {
            // corrupted data -> start with an empty list
        }
        return result
    }

    fun isFavorite(url: String): Boolean = favorites().any { it.url == url }

    /** Adds or removes the channel. Returns true when it is a favourite afterwards. */
    fun toggleFavorite(channel: Channel, kind: String = ""): Boolean {
        val list = favorites().toMutableList()
        val savedKinds = HashMap(kinds)
        if (kind.isNotEmpty()) savedKinds[channel.url] = kind
        val existing = list.indexOfFirst { it.url == channel.url }
        val nowFavorite: Boolean
        if (existing >= 0) {
            list.removeAt(existing)
            nowFavorite = false
        } else {
            list.add(channel)
            nowFavorite = true
        }
        val array = JSONArray()
        list.forEach {
            array.put(
                JSONObject()
                    .put("name", it.name)
                    .put("url", it.url)
                    .put("logo", it.logo)
                    .put("group", it.group)
                    .put("seriesId", it.seriesId)
                    .put("infoId", it.infoId)
                    .put("kind", savedKinds[it.url] ?: inferKind(it))
            )
        }
        sp.edit().putString(KEY_FAVORITES, array.toString()).apply()
        return nowFavorite
    }

    /** Changes whenever something that influences the lists changes (used to reload on return). */
    fun listsSignature(): String =
        DefaultData.sourceKeys.joinToString("|") { getSource(it) } + "#" +
            effectiveXtreamServer() + xtreamUser + xtreamPass + xtreamName + "#" +
            stalkerPortal + stalkerMac + stalkerName + "#" +
            customLists().joinToString("|") { it.id + it.value }

    // ---------------------------------------------------------------- welcome screen and identity

    /** The welcome message shown before the welcome video ("" = none). */
    var welcomeText: String
        get() = sp.getString(KEY_W_TEXT, "") ?: ""
        set(value) { sp.edit().putString(KEY_W_TEXT, value).apply() }

    /** Background of the welcome screen: "" (none), "builtin:N" or "file:<path>". */
    var welcomeBg: String
        get() = sp.getString(KEY_W_BG, "") ?: ""
        set(value) { sp.edit().putString(KEY_W_BG, value).apply() }

    var welcomeSize: Int
        get() = sp.getInt(KEY_W_SIZE, 30).coerceIn(12, 90)
        set(value) { sp.edit().putInt(KEY_W_SIZE, value.coerceIn(12, 90)).apply() }

    var welcomeColor: Int
        get() = sp.getInt(KEY_W_COLOR, 0xFFFFD86B.toInt())
        set(value) { sp.edit().putInt(KEY_W_COLOR, value).apply() }

    /** Index in [WelcomeStyle.fontNames]; the last entry is the font file chosen by the user. */
    var welcomeFont: Int
        get() = sp.getInt(KEY_W_FONT, 0)
        set(value) { sp.edit().putInt(KEY_W_FONT, value).apply() }

    var welcomeFontPath: String
        get() = sp.getString(KEY_W_FONT_FILE, "") ?: ""
        set(value) { sp.edit().putString(KEY_W_FONT_FILE, value).apply() }

    /** 0 = top, 1 = bottom, 2 = right, 3 = left, 4 = center. */
    var welcomePos: Int
        get() = sp.getInt(KEY_W_POS, 4).coerceIn(0, 4)
        set(value) { sp.edit().putInt(KEY_W_POS, value.coerceIn(0, 4)).apply() }

    /** How long the welcome message stays, in seconds (default 20). */
    var welcomeSeconds: Int
        get() = sp.getInt(KEY_W_SECONDS, 20).coerceIn(3, 120)
        set(value) { sp.edit().putInt(KEY_W_SECONDS, value.coerceIn(3, 120)).apply() }

    /** Background picture of the main screen: "" (black), "builtin:N" or "file:<path>". */
    var mainBg: String
        get() = sp.getString(KEY_MAIN_BG, "") ?: ""
        set(value) { sp.edit().putString(KEY_MAIN_BG, value).apply() }

    /** Index of the enabled app icon (see [AppIcons]). */
    var appIcon: Int
        get() = sp.getInt(KEY_APP_ICON, 0)
        set(value) { sp.edit().putInt(KEY_APP_ICON, value).apply() }

    /** Image of the custom home screen shortcut ("" = none). */
    var customIconPath: String
        get() = sp.getString(KEY_CUSTOM_ICON, "") ?: ""
        set(value) { sp.edit().putString(KEY_CUSTOM_ICON, value).apply() }

    // ---------------------------------------------------------------- API keys (encrypted)

    /** TMDB API key (v3 key or v4 "read access token"). Stored with AES-256. */
    var tmdbKey: String
        get() = secure.getString(KEY_TMDB, "") ?: ""
        set(value) {
            secure.edit().putString(KEY_TMDB, value.trim()).apply()
        }

    /** Optional YouTube Data API key: used to look for free official full movies on YouTube. */
    var youtubeKey: String
        get() = secure.getString(KEY_YOUTUBE, "") ?: ""
        set(value) {
            secure.edit().putString(KEY_YOUTUBE, value.trim()).apply()
        }

    /** Optional key of an AI provider (kept encrypted for the assistant). */
    var aiKey: String
        get() = secure.getString(KEY_AI, "") ?: ""
        set(value) {
            secure.edit().putString(KEY_AI, value.trim()).apply()
        }

    // ---------------------------------------------------------------- Holy Quran player

    var discX: Float
        get() = sp.getFloat("disc_x", 0f)
        set(value) { sp.edit().putFloat("disc_x", value).apply() }

    var discY: Float
        get() = sp.getFloat("disc_y", 0f)
        set(value) { sp.edit().putFloat("disc_y", value).apply() }

    /** 0..3: Kareemi gold / emerald / night gold / parchment. */
    var mushafTheme: Int
        get() = sp.getInt("mushaf_theme", 0).coerceIn(0, 3)
        set(value) { sp.edit().putInt("mushaf_theme", value).apply() }

    /** 0..4: small, medium, large, very large, huge. */
    var mushafFont: Int
        get() = sp.getInt("mushaf_font", 2).coerceIn(0, 4)
        set(value) { sp.edit().putInt("mushaf_font", value).apply() }

    class QuranResume(val url: String, val title: String, val group: String, val positionMs: Long)

    fun saveQuranResume(url: String, title: String, group: String, positionMs: Long) {
        sp.edit().putString("qr_url", url).putString("qr_title", title).putString("qr_group", group)
            .putLong("qr_pos", positionMs).apply()
    }

    fun quranResume(): QuranResume? {
        val url = sp.getString("qr_url", "").orEmpty()
        if (url.isBlank()) return null
        return QuranResume(url, sp.getString("qr_title", "").orEmpty(), sp.getString("qr_group", "").orEmpty(), sp.getLong("qr_pos", 0L))
    }

    // ---------------------------------------------------------------- music player

    /** 0..3: small, medium, large, largest. */
    var songDiscSize: Int
        get() = sp.getInt("song_disc", 1).coerceIn(0, 3)
        set(value) { sp.edit().putInt("song_disc", value).apply() }

    var songDiscX: Float
        get() = sp.getFloat("song_disc_x", 0f)
        set(value) { sp.edit().putFloat("song_disc_x", value).apply() }

    var songDiscY: Float
        get() = sp.getFloat("song_disc_y", 0f)
        set(value) { sp.edit().putFloat("song_disc_y", value).apply() }

    /** Floating lists of the music player: side (0 right, 1 left), width % and height % of the screen. */
    var songListSide: Int
        get() = sp.getInt("song_list_side", 0)
        set(value) { sp.edit().putInt("song_list_side", value).apply() }

    var songListWidth: Int
        get() = sp.getInt("song_list_w", 60).coerceIn(30, 95)
        set(value) { sp.edit().putInt("song_list_w", value).apply() }

    var songListHeight: Int
        get() = sp.getInt("song_list_h", 80).coerceIn(30, 95)
        set(value) { sp.edit().putInt("song_list_h", value).apply() }

    // ---------------------------------------------------------------- five AI key lines (encrypted)

    fun aiSlot(i: Int): String = secure.getString("ai_slot_$i", "") ?: ""

    fun setAiSlot(i: Int, key: String) {
        secure.edit().putString("ai_slot_$i", key.trim()).apply()
    }

    /** "1" = tested and working, "0" = failed / finished, "" = not tested yet. */
    fun aiSlotOk(i: Int): String = secure.getString("ai_ok_$i", "") ?: ""

    fun setAiSlotOk(i: Int, value: String) {
        secure.edit().putString("ai_ok_$i", value).apply()
    }

    // ---------------------------------------------------------------- backup API keys (encrypted)

    fun primaryKey(service: String): String = when (service) {
        ApiKeys.TMDB -> tmdbKey
        ApiKeys.YOUTUBE -> youtubeKey
        else -> aiKey
    }

    fun setPrimaryKey(service: String, value: String) {
        when (service) {
            ApiKeys.TMDB -> tmdbKey = value
            ApiKeys.YOUTUBE -> youtubeKey = value
            else -> aiKey = value
        }
    }

    /** The reserve keys of a service (used one after the other when the free quota of the current key ends). */
    fun backupKeys(service: String): List<String> =
        (secure.getString("kb_$service", "") ?: "").split('\n').map { it.trim() }.filter { it.isNotEmpty() }

    private fun saveBackups(service: String, list: List<String>) {
        secure.edit().putString("kb_$service", list.joinToString("\n")).apply()
    }

    fun addBackupKey(service: String, key: String): Boolean {
        val k = key.trim()
        if (k.isEmpty() || k == primaryKey(service)) return false
        val list = backupKeys(service)
        if (k in list) return false
        saveBackups(service, list + k)
        return true
    }

    fun clearBackupKeys(service: String) = saveBackups(service, emptyList())

    /** Promotes the next reserve key to the current one (the exhausted one goes to the end). False when there is none. */
    @Synchronized
    fun rotateKey(service: String): Boolean {
        val reserve = backupKeys(service)
        if (reserve.isEmpty()) return false
        val old = primaryKey(service)
        setPrimaryKey(service, reserve.first())
        saveBackups(service, reserve.drop(1) + (if (old.isNotBlank()) listOf(old) else emptyList()))
        return true
    }

    // ---------------------------------------------------------------- protection / encryption

    /** Master switch of the protection (DoH + TLS 1.3 + proxy). */
    var protectionOn: Boolean
        get() = sp.getBoolean(KEY_PROT_ON, true)
        set(value) {
            sp.edit().putBoolean(KEY_PROT_ON, value).apply()
        }

    /** DNS-over-HTTPS: 0 = off, 1 Cloudflare, 2 Google, 3 Quad9, 4 AdGuard, 5 NextDNS, 6 Mullvad. */
    var dohProvider: Int
        get() = sp.getInt(KEY_DOH, 1).coerceIn(0, 6)
        set(value) {
            sp.edit().putInt(KEY_DOH, value.coerceIn(0, 6)).apply()
        }

    /** Auto Smart Shield (default ON): fastest DoH server + automatic switching of DoH and User-Agent on a block. */
    var shieldAuto: Boolean
        get() = sp.getBoolean("shield_auto", true)
        set(value) {
            sp.edit().putBoolean("shield_auto", value).apply()
        }

    /** Prefer TLS 1.3 (TLS 1.2 stays as a fallback so that older servers still work). */
    var tls13: Boolean
        get() = sp.getBoolean(KEY_TLS13, true)
        set(value) {
            sp.edit().putBoolean(KEY_TLS13, value).apply()
        }

    /** Proxy type: 0 = none, 1 = SOCKS5, 2 = HTTP. */
    var proxyType: Int
        get() = sp.getInt(KEY_PROXY_TYPE, 0).coerceIn(0, 2)
        set(value) {
            sp.edit().putInt(KEY_PROXY_TYPE, value.coerceIn(0, 2)).apply()
        }

    var proxyHost: String
        get() = secure.getString(KEY_PROXY_HOST, "") ?: ""
        set(value) {
            secure.edit().putString(KEY_PROXY_HOST, value.trim()).apply()
        }

    var proxyPort: Int
        get() = secure.getInt(KEY_PROXY_PORT, 0)
        set(value) {
            secure.edit().putInt(KEY_PROXY_PORT, value).apply()
        }

    var proxyUser: String
        get() = secure.getString(KEY_PROXY_USER, "") ?: ""
        set(value) {
            secure.edit().putString(KEY_PROXY_USER, value.trim()).apply()
        }

    var proxyPass: String
        get() = secure.getString(KEY_PROXY_PASS, "") ?: ""
        set(value) {
            secure.edit().putString(KEY_PROXY_PASS, value.trim()).apply()
        }

    fun proxyConfigured(): Boolean = proxyType != 0 && proxyHost.isNotBlank() && proxyPort in 1..65535

    // ---------------------------------------------------------------- main screen customisation

    /** Index in [UiTheme.all]. */
    var themeIndex: Int
        get() = sp.getInt(KEY_THEME, 0).coerceIn(0, UiTheme.all.size - 1)
        set(value) {
            sp.edit().putInt(KEY_THEME, value.coerceIn(0, UiTheme.all.size - 1)).apply()
        }

    /** Position of the live screen + orbit: 0 = left, 1 = center, 2 = right. */
    var stageSide: Int
        get() = sp.getInt(KEY_STAGE_SIDE, 0).coerceIn(0, 2)
        set(value) {
            sp.edit().putInt(KEY_STAGE_SIDE, value.coerceIn(0, 2)).apply()
        }

    /** Position of the sections + channels lists: 0 = left, 1 = center, 2 = right. */
    var listSide: Int
        get() = sp.getInt(KEY_LIST_SIDE, 2).coerceIn(0, 2)
        set(value) {
            sp.edit().putInt(KEY_LIST_SIDE, value.coerceIn(0, 2)).apply()
        }

    /** Sizes in percent of the screen (30..100). */
    var stageWidthPct: Int
        get() = sp.getInt(KEY_STAGE_W, 68).coerceIn(30, 100)
        set(value) {
            sp.edit().putInt(KEY_STAGE_W, value.coerceIn(30, 100)).apply()
        }

    var stageHeightPct: Int
        get() = sp.getInt(KEY_STAGE_H, 100).coerceIn(30, 100)
        set(value) {
            sp.edit().putInt(KEY_STAGE_H, value.coerceIn(30, 100)).apply()
        }

    var listWidthPct: Int
        get() = sp.getInt(KEY_LIST_W, 32).coerceIn(20, 100)
        set(value) {
            sp.edit().putInt(KEY_LIST_W, value.coerceIn(20, 100)).apply()
        }

    var listHeightPct: Int
        get() = sp.getInt(KEY_LIST_H, 100).coerceIn(30, 100)
        set(value) {
            sp.edit().putInt(KEY_LIST_H, value.coerceIn(30, 100)).apply()
        }

    fun resetLayout() {
        sp.edit().remove(KEY_STAGE_SIDE).remove(KEY_LIST_SIDE).remove(KEY_STAGE_W).remove(KEY_STAGE_H)
            .remove(KEY_LIST_W).remove(KEY_LIST_H).remove(KEY_THEME).apply()
    }

    // ---------------------------------------------------------------- watch progress (series / movies)

    /** Saved position of a movie / episode in milliseconds (0 = none). */
    fun resumePosition(url: String): Long = watchObject().optJSONObject(url)?.optLong("pos", 0L) ?: 0L

    /** True when the episode was watched (to the end, or almost). */
    fun isWatched(url: String): Boolean = watchObject().optJSONObject(url)?.optBoolean("done", false) ?: false

    fun saveProgress(url: String, positionMs: Long, durationMs: Long) {
        if (url.isBlank() || positionMs < 0) return
        val all = watchObject()
        val done = durationMs > 0 && positionMs >= durationMs * 0.92
        val entry = JSONObject()
            .put("pos", if (done) 0L else positionMs)
            .put("dur", durationMs)
            .put("done", done || (all.optJSONObject(url)?.optBoolean("done", false) ?: false))
            .put("t", System.currentTimeMillis())
        all.put(url, entry)
        // keep the file small: only the 400 most recent entries
        if (all.length() > 400) {
            val keys = all.keys().asSequence().toList()
                .sortedBy { all.optJSONObject(it)?.optLong("t", 0L) ?: 0L }
            keys.take(all.length() - 400).forEach { all.remove(it) }
        }
        sp.edit().putString(KEY_WATCH, all.toString()).apply()
    }

    fun clearProgress(url: String) {
        val all = watchObject()
        all.remove(url)
        sp.edit().putString(KEY_WATCH, all.toString()).apply()
    }

    private fun watchObject(): JSONObject = try {
        JSONObject(sp.getString(KEY_WATCH, null) ?: "{}")
    } catch (_: Exception) {
        JSONObject()
    }

    // ---------------------------------------------------------------- helpers

    private fun sha256(text: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    // ---------------------------------------------------------------- full screen player layout

    /** Side of the sections / channels column in the full screen player: 0 = right, 1 = left. */
    var panelSide: Int
        get() = sp.getInt("pl_side", 0)
        set(value) { sp.edit().putInt("pl_side", value).apply() }

    /** Width of that column in dp. */
    var panelWidthDp: Int
        get() = sp.getInt("pl_width", 340).coerceIn(220, 560)
        set(value) { sp.edit().putInt("pl_width", value.coerceIn(220, 560)).apply() }

    /** Height of that column in percent of the free height between the two bars. */
    var panelHeightPct: Int
        get() = sp.getInt("pl_height", 100).coerceIn(40, 100)
        set(value) { sp.edit().putInt("pl_height", value.coerceIn(40, 100)).apply() }

    /** Opacity of that column in percent. */
    var panelAlphaPct: Int
        get() = sp.getInt("pl_alpha", 60).coerceIn(20, 100)
        set(value) { sp.edit().putInt("pl_alpha", value.coerceIn(20, 100)).apply() }

    /** Where a player button lives: 0 = top bar, 1 = bottom bar, 2 = hidden. */
    fun playerBtnPos(key: String, default: Int): Int = sp.getInt("pbtn_$key", default).coerceIn(0, 2)

    fun setPlayerBtnPos(key: String, pos: Int) {
        sp.edit().putInt("pbtn_$key", pos).apply()
    }

    fun resetPlayerLayout() {
        val e = sp.edit()
        for (k in sp.all.keys) if (k.startsWith("pbtn_") || k.startsWith("pl_")) e.remove(k)
        e.apply()
    }

    // ---------------------------------------------------------------- active subscription ("My subscription / servers")

    /** "free" = the built-in free lists, "xtream", "stalker" or "m3u:<id>". */
    var activeSub: String
        get() = sp.getString("active_sub", "free") ?: "free"
        set(value) { sp.edit().putString("active_sub", value).apply() }

    /** Catalog the main screen must open when it comes back to the front (set by the subscriptions page). */
    var pendingCatalog: String
        get() = sp.getString("pending_catalog", "") ?: ""
        set(value) { sp.edit().putString("pending_catalog", value).apply() }

    // ---------------------------------------------------------------- sound effects / live translation / player extras

    var eqPreset: String
        get() = sp.getString("eq_preset", "normal") ?: "normal"
        set(value) { sp.edit().putString("eq_preset", value).apply() }

    var eqCustom: String
        get() = sp.getString("eq_custom", "") ?: ""
        set(value) { sp.edit().putString("eq_custom", value).apply() }

    var eqCustomBass: Int
        get() = sp.getInt("eq_custom_bass", 0)
        set(value) { sp.edit().putInt("eq_custom_bass", value).apply() }

    /** AI Live subtitles: 0 small, 1 medium, 2 large. */
    var liveSubSize: Int
        get() = sp.getInt("live_sub_size", 1).coerceIn(0, 2)
        set(value) { sp.edit().putInt("live_sub_size", value).apply() }

    /** 0 = bottom, 1 = top. */
    var liveSubPos: Int
        get() = sp.getInt("live_sub_pos", 0)
        set(value) { sp.edit().putInt("live_sub_pos", value).apply() }

    var liveSubColor: Int
        get() = sp.getInt("live_sub_color", 0xFFFFFFFF.toInt())
        set(value) { sp.edit().putInt("live_sub_color", value).apply() }

    /** Language the live subtitles translate from: "auto", tr, de, en, fr, es, ku. */
    var liveSubLang: String
        get() = sp.getString("live_sub_lang", "auto") ?: "auto"
        set(value) { sp.edit().putString("live_sub_lang", value).apply() }

    /** Smart buffer delay in seconds (5..60, default 25): how far behind the live edge the picture is played. */
    var liveSubDelay: Int
        get() = sp.getInt("live_sub_delay2", 25).coerceIn(5, 60)
        set(value) { sp.edit().putInt("live_sub_delay2", value.coerceIn(5, 60)).apply() }

    /** AI Dubbing (spoken Arabic translation). */
    var dubEnabled: Boolean
        get() = sp.getBoolean("dub_on", false)
        set(value) { sp.edit().putBoolean("dub_on", value).apply() }

    /** 0 = Modern Standard Arabic, 1 = Syrian / Shami dialect. */
    var dubDialect: Int
        get() = sp.getInt("dub_dialect", 0).coerceIn(0, 1)
        set(value) { sp.edit().putInt("dub_dialect", value.coerceIn(0, 1)).apply() }

    /** Level (percent) of the original channel sound while the dubbing speaks (default 15). */
    var dubDuck: Int
        get() = sp.getInt("dub_duck", 15).coerceIn(0, 100)
        set(value) { sp.edit().putInt("dub_duck", value.coerceIn(0, 100)).apply() }

    var infoBadge: Boolean
        get() = sp.getBoolean("info_badge", false)
        set(value) { sp.edit().putBoolean("info_badge", value).apply() }

    /** When an iptv-org list was last downloaded (they are refreshed automatically once a day). */
    fun iptvStamp(id: String): Long = sp.getLong("iptv_stamp_$id", 0L)

    fun setIptvStamp(id: String) {
        sp.edit().putLong("iptv_stamp_$id", System.currentTimeMillis()).apply()
    }

    companion object {
        private const val FILE_NAME = "oso_gold_prefs"
        private const val KEY_W_TEXT = "welcome_text"
        private const val KEY_W_BG = "welcome_bg"
        private const val KEY_W_SIZE = "welcome_size"
        private const val KEY_W_COLOR = "welcome_color"
        private const val KEY_W_FONT = "welcome_font"
        private const val KEY_W_FONT_FILE = "welcome_font_file"
        private const val KEY_W_POS = "welcome_pos"
        private const val KEY_W_SECONDS = "welcome_seconds"
        private const val KEY_MAIN_BG = "main_bg"
        private const val KEY_APP_ICON = "app_icon"
        private const val KEY_CUSTOM_ICON = "custom_icon"
        private const val KEY_TMDB = "tmdb_key"
        private const val KEY_YOUTUBE = "youtube_key"
        private const val KEY_AI = "ai_key"
        private const val KEY_PROT_ON = "prot_on"
        private const val KEY_DOH = "prot_doh"
        private const val KEY_TLS13 = "prot_tls13"
        private const val KEY_PROXY_TYPE = "proxy_type"
        private const val KEY_PROXY_HOST = "proxy_host"
        private const val KEY_PROXY_PORT = "proxy_port"
        private const val KEY_PROXY_USER = "proxy_user"
        private const val KEY_PROXY_PASS = "proxy_pass"
        private const val KEY_THEME = "ui_theme"
        private const val KEY_STAGE_SIDE = "ui_stage_side"
        private const val KEY_LIST_SIDE = "ui_list_side"
        private const val KEY_STAGE_W = "ui_stage_w"
        private const val KEY_STAGE_H = "ui_stage_h"
        private const val KEY_LIST_W = "ui_list_w"
        private const val KEY_LIST_H = "ui_list_h"
        private const val KEY_WATCH = "watch_progress"
        private const val KEY_LOGGED_IN = "logged_in"
        private const val KEY_PASSWORD_HASH = "password_hash"
        private const val KEY_WELCOME_VIDEO = "welcome_video_path"
        private const val KEY_SOURCE_PREFIX = "source_"
        private const val KEY_FAVORITES = "favorites"
        private const val KEY_CUSTOM_LISTS = "custom_lists"
        private const val KEY_X_SERVER = "x_server"
        private const val KEY_X_USER = "x_user"
        private const val KEY_X_PASS = "x_pass"
        private const val KEY_X_PINNED = "x_pinned"
        private const val KEY_S_PORTAL = "s_portal"
        private const val KEY_S_MAC = "s_mac"
        private const val KEY_USER_AGENT = "user_agent"
        private const val KEY_PIP_SIZE = "pip_size"
        private const val KEY_PIP_RIGHT = "pip_right"
        private const val KEY_ASPECT_V2 = "aspect_mode_v2"
        private const val KEY_ENGINE = "player_engine"
        private const val KEY_X_NAME = "x_name"
        private const val KEY_S_NAME = "s_name"
        private const val KEY_SUB_SIZE = "sub_size"
        private const val KEY_SUB_COLOR = "sub_color"
        private const val KEY_SUB_TOP = "sub_top"

        const val ENGINE_EXO = "exo"
        const val ENGINE_VLC = "vlc"
        const val ENGINE_NATIVE = "native"
        const val ENGINE_EXTERNAL = "external"
        val ENGINES = setOf(ENGINE_EXO, ENGINE_VLC, ENGINE_NATIVE, ENGINE_EXTERNAL)

        /** Password that is valid until the owner changes it in the settings. */
        const val DEFAULT_PASSWORD = "1234"

        /** Default player identity card. Can be changed in Settings. */
        const val DEFAULT_USER_AGENT = "IPTVSmartersPro"

        /** true  = the welcome video is played at every launch (after the password was accepted).
         *  false = only directly after the password was entered. */
        const val WELCOME_EVERY_LAUNCH = true
    }
}
