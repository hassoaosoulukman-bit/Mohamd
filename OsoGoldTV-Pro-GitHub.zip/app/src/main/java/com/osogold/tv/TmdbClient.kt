package com.osogold.tv

import kotlinx.coroutines.CancellationException
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * The Movie Database (TMDB) client: posters, the story in Arabic, ratings and the YouTube trailer
 * of a movie or a series. The key is added by the user in Settings -> "إضافة مفتاح API" (it is
 * stored encrypted). Both key kinds work: the short v3 "API key" and the long v4 "Read access token".
 *
 * All functions are blocking: call them from a background thread.
 */
object TmdbClient {

    private const val BASE = "https://api.themoviedb.org/3"
    private const val IMAGE = "https://image.tmdb.org/t/p/"

    private val detailCache = ConcurrentHashMap<String, MovieDetail>()
    private val posterCache = ConcurrentHashMap<String, String>()

    fun configured(prefs: Prefs): Boolean = prefs.tmdbKey.isNotBlank()

    /** Title without quality / language tags + the year found in the name ("" when there is none). */
    fun parseTitle(raw: String): Pair<String, String> {
        val year = Regex("(?<!\\d)(19|20)\\d{2}(?!\\d)").find(raw)?.value ?: ""
        var t = raw
        t = t.replace(Regex("\\[[^\\]]*]|\\([^)]*\\)|\\{[^}]*}"), " ")
        t = t.replace(Regex("^\\s*[A-Za-z]{2,3}\\s*[|:\\-–]\\s*"), "")
        val tags = "4k|uhd|fhd|hd|sd|1080p|720p|480p|2160p|bluray|web-?dl|webrip|hdrip|dvdrip|x264|x265|hevc|multi|dubbed|sub|" +
            "مدبلج|مترجم|مترجمة|كامل|اون لاين|أون لاين"
        t = t.replace(Regex("(?i)(?<![\\p{L}\\p{N}])($tags)(?![\\p{L}\\p{N}])"), " ")
        t = t.replace(Regex("(?<!\\d)(19|20)\\d{2}(?!\\d)"), " ")
        t = t.replace(Regex("(?i)\\bS\\d{1,2}\\s*E\\d{1,3}\\b"), " ")
        t = t.replace(Regex("^[\\s\\-–|:.]+|[\\s\\-–|:.]+$"), "").replace(Regex("\\s{2,}"), " ")
        if (t.isBlank()) {
            // the name was only a year / tag (e.g. the film "1917"): keep what the user sees
            t = raw.replace(Regex("\\[[^\\]]*]|\\([^)]*\\)|\\{[^}]*}"), " ").trim()
        }
        return t.trim() to year
    }

    private fun get(prefs: Prefs, path: String, query: String): JSONObject {
        var attempts = 0
        while (true) {
            val key = prefs.tmdbKey
            val bearer = key.length > 40
            val url = StringBuilder(BASE).append(path).append('?').append(query)
            if (!bearer) url.append("&api_key=").append(URLEncoder.encode(key, "UTF-8"))
            val builder = Request.Builder().url(url.toString()).header("Accept", "application/json")
            if (bearer) builder.header("Authorization", "Bearer $key")
            NetConfig.client().newCall(builder.build()).execute().use { response ->
                // the key is finished / refused: the next reserve key takes over automatically
                if (ApiKeys.isKeyProblem(response.code) && attempts <= prefs.backupKeys(ApiKeys.TMDB).size &&
                    prefs.rotateKey(ApiKeys.TMDB)
                ) {
                    attempts++
                    return@use
                }
                if (response.code == 401) throw java.io.IOException("مفتاح TMDB غير صحيح")
                if (!response.isSuccessful) throw java.io.IOException("TMDB HTTP ${response.code}")
                return JSONObject(response.body?.string().orEmpty())
            }
        }
    }

    private fun enc(text: String): String = URLEncoder.encode(text, "UTF-8")

    /** Finds the TMDB id of a title (Arabic first, then English results). Returns 0 when not found. */
    private fun findId(prefs: Prefs, title: String, year: String, tv: Boolean): Long {
        val type = if (tv) "tv" else "movie"
        val yearParam = if (year.isNotEmpty()) (if (tv) "&first_air_date_year=$year" else "&year=$year") else ""
        for (lang in listOf("ar", "en-US")) {
            for (withYear in listOf(true, false)) {
                if (!withYear && yearParam.isEmpty()) continue
                val result = get(
                    prefs, "/search/$type",
                    "query=${enc(title)}&language=$lang&include_adult=false" + (if (withYear) yearParam else "")
                )
                val arr = result.optJSONArray("results") ?: continue
                if (arr.length() > 0) return arr.getJSONObject(0).optLong("id", 0L)
            }
        }
        return 0L
    }

    /** Poster address of a title (small size, for the grid). Cached. "" when TMDB has none. */
    fun poster(prefs: Prefs, rawTitle: String, tv: Boolean): String {
        val (title, year) = parseTitle(rawTitle)
        if (title.isBlank()) return ""
        val cacheKey = (if (tv) "t:" else "m:") + title.lowercase(Locale.ROOT) + year
        posterCache[cacheKey]?.let { return it }
        return try {
            val type = if (tv) "tv" else "movie"
            val result = get(prefs, "/search/$type", "query=${enc(title)}&language=ar&include_adult=false")
            val first = result.optJSONArray("results")?.optJSONObject(0)
            val path = first?.optString("poster_path").orEmpty()
            val url = if (path.isNotBlank() && path != "null") IMAGE + "w342" + path else ""
            posterCache[cacheKey] = url
            url
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            ""
        }
    }

    /**
     * Full information of a movie / series: Arabic name and story, poster, wide picture, rating,
     * genres, year and a YouTube trailer (Arabic when TMDB has one, otherwise English). Null when the
     * key is missing or the title is not found.
     */
    fun detail(prefs: Prefs, rawTitle: String, tv: Boolean): MovieDetail? {
        if (!configured(prefs)) return null
        val (title, year) = parseTitle(rawTitle)
        if (title.isBlank()) return null
        val cacheKey = (if (tv) "t:" else "m:") + title.lowercase(Locale.ROOT) + year
        detailCache[cacheKey]?.let { return it }

        val id = findId(prefs, title, year, tv)
        if (id == 0L) return null
        val type = if (tv) "tv" else "movie"
        val obj = get(prefs, "/$type/$id", "language=ar&append_to_response=videos&include_video_language=ar,en,null")

        var overview = obj.optString("overview").trim()
        if (overview.isBlank()) {
            // no Arabic story: use the English one rather than nothing
            overview = try {
                get(prefs, "/$type/$id", "language=en-US").optString("overview").trim()
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                ""
            }
        }

        val genres = obj.optJSONArray("genres")?.let { arr ->
            (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("name") }
                .filter { it.isNotBlank() }.joinToString("، ")
        }.orEmpty()

        val date = obj.optString(if (tv) "first_air_date" else "release_date")
        val vote = obj.optDouble("vote_average", 0.0)
        val posterPath = obj.optString("poster_path").takeIf { it.isNotBlank() && it != "null" }
        val backdropPath = obj.optString("backdrop_path").takeIf { it.isNotBlank() && it != "null" }

        val detail = MovieDetail(
            title = obj.optString(if (tv) "name" else "title").trim(),
            plot = overview,
            trailerId = pickTrailer(obj.optJSONObject("videos")),
            poster = posterPath?.let { IMAGE + "w780" + it }.orEmpty(),
            backdrop = backdropPath?.let { IMAGE + "w1280" + it }.orEmpty(),
            genre = genres,
            year = date.take(4),
            rating = if (vote > 0.0) String.format(Locale.US, "%.1f", vote) else ""
        )
        detailCache[cacheKey] = detail
        return detail
    }

    /** Best YouTube trailer: official Arabic, any Arabic, English trailer, then any teaser. */
    private fun pickTrailer(videos: JSONObject?): String {
        val arr = videos?.optJSONArray("results") ?: return ""
        class V(val key: String, val lang: String, val type: String, val official: Boolean)
        val list = ArrayList<V>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!o.optString("site").equals("YouTube", true)) continue
            val key = o.optString("key")
            if (key.isBlank()) continue
            list.add(V(key, o.optString("iso_639_1"), o.optString("type"), o.optBoolean("official", false)))
        }
        fun score(v: V): Int {
            var s = 0
            if (v.lang == "ar") s += 100 else if (v.lang == "en") s += 40
            if (v.type.equals("Trailer", true)) s += 30 else if (v.type.equals("Teaser", true)) s += 10
            if (v.official) s += 5
            return s
        }
        return list.maxByOrNull { score(it) }?.key.orEmpty()
    }
}
