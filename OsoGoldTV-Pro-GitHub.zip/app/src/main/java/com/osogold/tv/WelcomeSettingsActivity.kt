package com.osogold.tv

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import java.io.File

/**
 * Settings -> "شاشة الترحيب والهوية":
 *  message (write / edit / delete), welcome picture, text size / colour / font / place, duration,
 *  main screen background, app icon (built-in royal icons or a picture as a home screen shortcut).
 */
class WelcomeSettingsActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private lateinit var previewBox: FrameLayout
    private lateinit var previewText: TextView
    private lateinit var sizeLabel: TextView
    private val posChips = ArrayList<TextView>()

    /** Who receives the next picture / font chosen in the phone. */
    private var imageCallback: ((Uri) -> Unit)? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) imageCallback?.invoke(uri)
    }

    private val pickFont = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) importFont(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        root.addView(CosmicBackgroundView(this), FrameLayout.LayoutParams(-1, -1))
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(
            ScrollView(this).apply {
                isFillViewport = true
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(column, FrameLayout.LayoutParams(-1, -2))
            },
            FrameLayout.LayoutParams(-1, -1)
        )

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(title("شاشة الترحيب والهوية", 22f), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("رجوع", false) { finish() }, LinearLayout.LayoutParams(-2, dp(40)))
        column.addView(header)

        // ---------------------------------------------------------------- preview
        previewBox = FrameLayout(this).apply {
            setBackgroundColor(0xFF000000.toInt())
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        previewText = TextView(this).apply {
            gravity = Gravity.CENTER
            setShadowLayer(8f, 0f, 2f, 0xCC000000.toInt())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        previewBox.addView(previewText, FrameLayout.LayoutParams(-2, -2))
        column.addView(previewBox, LinearLayout.LayoutParams(-1, dp(170)).apply { topMargin = dp(10) })

        // ---------------------------------------------------------------- welcome message
        column.addView(section("أ)  رسالة الترحيب"))
        column.addView(button("✍  كتابة رسالة الترحيب", true) { editMessage() }, LinearLayout.LayoutParams(-1, dp(46)))

        column.addView(section("ب)  خلفية الترحيب"))
        column.addView(
            button("🖼  اختيار خلفية الترحيب", false) {
                editBackground("خلفية الترحيب", prefs.welcomeBg, "welcome_bg", { prefs.welcomeBg = it }, { prefs.welcomeBg = "" })
            },
            LinearLayout.LayoutParams(-1, dp(46))
        )

        // ---------------------------------------------------------------- text style
        column.addView(section("ج)  تخصيص نص الترحيب"))
        val sizeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        sizeRow.addView(button("A−", false) { changeSize(-2) }, LinearLayout.LayoutParams(dp(64), dp(42)))
        sizeLabel = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 14f
            setTextColor(0xFFF3E9CF.toInt())
        }
        sizeRow.addView(sizeLabel, LinearLayout.LayoutParams(0, -2, 1f))
        sizeRow.addView(button("A+", false) { changeSize(+2) }, LinearLayout.LayoutParams(dp(64), dp(42)))
        column.addView(sizeRow)

        val styleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
        styleRow.addView(button("🎨  لون الخط", false) { pickColor() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        styleRow.addView(View(this), LinearLayout.LayoutParams(dp(8), 1))
        styleRow.addView(button("🅰  نوع الخط", false) { pickFontDialog() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        column.addView(styleRow)

        column.addView(label("موضع الرسالة على الشاشة:"))
        val pos = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        listOf("أعلى", "أسفل", "يمين", "يسار", "المنتصف").forEachIndexed { i, name ->
            val chip = TextView(this).apply {
                text = name
                gravity = Gravity.CENTER
                textSize = 13f
                setTextColor(0xFFFFD86B.toInt())
                setOnClickListener {
                    prefs.welcomePos = i
                    refresh()
                }
            }
            posChips.add(chip)
            pos.addView(chip, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(2), dp(4), dp(2), dp(4)) })
        }
        column.addView(pos)

        // ---------------------------------------------------------------- duration
        column.addView(section("د)  مدة عرض رسالة الترحيب"))
        val durationLabel = label("")
        column.addView(durationLabel)
        val bar = SeekBar(this).apply {
            max = 117
            progress = prefs.welcomeSeconds - 3
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(b: SeekBar?, p: Int, fromUser: Boolean) {
                    durationLabel.text = "المدة: ${p + 3} ثانية"
                    if (fromUser) prefs.welcomeSeconds = p + 3
                }

                override fun onStartTrackingTouch(b: SeekBar?) {}
                override fun onStopTrackingTouch(b: SeekBar?) {
                    toast("تم الحفظ")
                }
            })
        }
        durationLabel.text = "المدة: ${prefs.welcomeSeconds} ثانية"
        column.addView(bar, LinearLayout.LayoutParams(-1, dp(36)))
        column.addView(note("التسلسل عند فتح التطبيق: رسالة الترحيب وصورتها ← الفيديو الترحيبي ← الواجهة الرئيسية، وزر «تخطي» ظاهر في الشاشتين."))

        // ---------------------------------------------------------------- main background + icon
        column.addView(section("هـ)  خلفية الواجهة الرئيسية"))
        column.addView(
            button("🌌  تغيير خلفية الواجهة الرئيسية", false) {
                editBackground("خلفية الواجهة الرئيسية", prefs.mainBg, "main_bg", { prefs.mainBg = it }, { prefs.mainBg = "" })
            },
            LinearLayout.LayoutParams(-1, dp(46))
        )

        column.addView(section("و)  أيقونة التطبيق"))
        column.addView(button("👑  تغيير أيقونة التطبيق", false) { editIcon() }, LinearLayout.LayoutParams(-1, dp(46)))

        setContentView(root)
        refresh()
    }

    // ------------------------------------------------------------------ preview

    private fun refresh() {
        val bg = Backgrounds.load(prefs.welcomeBg, 1024)
        previewBox.background = bg ?: ColorDrawable(0xFF000000.toInt())
        previewText.text = prefs.welcomeText.ifBlank { "هنا تظهر رسالة الترحيب" }
        previewText.setTextColor(prefs.welcomeColor)
        previewText.textSize = (prefs.welcomeSize / 2.4f).coerceAtLeast(9f)
        previewText.typeface = WelcomeStyle.typeface(prefs)
        previewText.layoutParams = (previewText.layoutParams as FrameLayout.LayoutParams).apply {
            gravity = when (prefs.welcomePos) {
                0 -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
                1 -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                2 -> Gravity.END or Gravity.CENTER_VERTICAL
                3 -> Gravity.START or Gravity.CENTER_VERTICAL
                else -> Gravity.CENTER
            }
        }
        sizeLabel.text = "حجم الخط: ${prefs.welcomeSize}"
        posChips.forEachIndexed { i, chip ->
            chip.setBackgroundResource(if (i == prefs.welcomePos) R.drawable.bg_chip_active else R.drawable.bg_chip)
            UiTheme.apply(chip)
        }
    }

    private fun changeSize(delta: Int) {
        prefs.welcomeSize = prefs.welcomeSize + delta
        refresh()
    }

    // ------------------------------------------------------------------ message editor

    private fun editMessage() {
        val saved = prefs.welcomeText
        val et = EditText(this).apply {
            hint = "اكتب رسالة الترحيب… مثال: أهلاً بكم في عالم…"
            setTextColor(0xFFFFD86B.toInt())
            setHintTextColor(0x99D4AF37.toInt())
            setBackgroundResource(R.drawable.bg_input)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            gravity = Gravity.TOP or Gravity.START
            minLines = 4
            maxLines = 8
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setText(saved)
            // a saved message is shown first and unlocked with "تعديل"
            isEnabled = saved.isBlank()
        }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), dp(4)); addView(et, LinearLayout.LayoutParams(-1, -2)) }
        val dialog = AlertDialog.Builder(this, R.style.GoldDialog)
            .setTitle("رسالة الترحيب")
            .setView(box)
            .setPositiveButton("حفظ", null)
            .setNeutralButton("تعديل", null)
            .setNegativeButton("حذف", null)
            .create()
        dialog.setOnShowListener {
            if (et.isEnabled) focusKeyboard(et)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                prefs.welcomeText = et.text.toString().trim()
                refresh()
                toast("تم الحفظ")
                dialog.dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                et.isEnabled = true
                focusKeyboard(et)
            }
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                prefs.welcomeText = ""
                et.setText("")
                refresh()
                toast("تم حذف الرسالة")
                dialog.dismiss()
            }
        }
        dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        showImmersive(dialog)
    }

    private fun focusKeyboard(et: EditText) {
        et.requestFocus()
        et.setSelection(et.text.length)
        et.postDelayed({
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
        }, 150L)
    }

    // ------------------------------------------------------------------ colour + font

    private fun pickColor() {
        val hsv = FloatArray(3)
        Color.colorToHSV(prefs.welcomeColor, hsv)
        val swatch = View(this)
        fun paint() {
            swatch.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(10).toFloat()
                setColor(Color.HSVToColor(hsv))
                setStroke(dp(2), 0xFFFFFFFF.toInt())
            }
        }
        paint()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(4)) }
        box.addView(swatch, LinearLayout.LayoutParams(-1, dp(46)))

        fun slider(name: String, max: Int, value: Int, onChange: (Int) -> Unit) {
            box.addView(label(name))
            box.addView(
                SeekBar(this).apply {
                    this.max = max
                    progress = value
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(b: SeekBar?, p: Int, fromUser: Boolean) {
                            onChange(p)
                            paint()
                        }

                        override fun onStartTrackingTouch(b: SeekBar?) {}
                        override fun onStopTrackingTouch(b: SeekBar?) {}
                    })
                },
                LinearLayout.LayoutParams(-1, dp(32))
            )
        }
        slider("درجة اللون", 360, hsv[0].toInt()) { hsv[0] = it.toFloat() }
        slider("التشبّع", 100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f }
        slider("السطوع", 100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f }

        val palette = listOf(
            0xFFFFFFFF, 0xFFFFD86B, 0xFFD4AF37, 0xFFFFE600, 0xFFFF9F40, 0xFFFF5C6C, 0xFFFF4DA6, 0xFFB77CFF,
            0xFF4DA3FF, 0xFF4DE1FF, 0xFF3DDC84, 0xFF7CFF6B, 0xFFC0C0C0, 0xFF8B5E3C, 0xFF000000, 0xFF1E88E5
        )
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        palette.chunked(8).forEach { rowColors ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowColors.forEach { c ->
                val dot = View(this).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(c.toInt())
                        setStroke(dp(1), 0x88FFFFFF.toInt())
                    }
                    setTag(R.id.tag_theme_bg, false)
                    setOnClickListener {
                        Color.colorToHSV(c.toInt(), hsv)
                        paint()
                    }
                }
                row.addView(dot, LinearLayout.LayoutParams(0, dp(30), 1f).apply { setMargins(dp(3), dp(6), dp(3), dp(2)) })
            }
            grid.addView(row)
        }
        box.addView(label("ألوان جاهزة"))
        box.addView(grid)

        val dialog = AlertDialog.Builder(this, R.style.GoldDialog)
            .setTitle("لون الخط")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("حفظ") { _, _ ->
                prefs.welcomeColor = Color.HSVToColor(hsv)
                refresh()
                toast("تم الحفظ")
            }
            .setNegativeButton("إلغاء", null)
            .create()
        showImmersive(dialog)
    }

    private fun pickFontDialog() {
        val names = WelcomeStyle.fontNames.toTypedArray()
        val dialog = AlertDialog.Builder(this, R.style.GoldDialog)
            .setTitle("نوع الخط")
            .setSingleChoiceItems(names, prefs.welcomeFont.coerceIn(0, names.size - 1)) { d, which ->
                if (which == names.size - 1) {
                    pickFont.launch("*/*")
                } else {
                    prefs.welcomeFont = which
                    refresh()
                    toast("تم الحفظ")
                }
                d.dismiss()
            }
            .setNegativeButton("إغلاق", null)
            .create()
        showImmersive(dialog)
    }

    /** A .ttf / .otf file chosen in the phone becomes the welcome font. */
    private fun importFont(uri: Uri) {
        try {
            val target = File(filesDir, "welcome_font_${System.currentTimeMillis()}.ttf")
            contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { input.copyTo(it) } }
            Typeface.createFromFile(target) // throws when it is not a font
            if (prefs.welcomeFontPath.isNotBlank()) File(prefs.welcomeFontPath).delete()
            prefs.welcomeFontPath = target.absolutePath
            prefs.welcomeFont = WelcomeStyle.fontNames.size - 1
            refresh()
            toast("تم الحفظ")
        } catch (_: Exception) {
            toast("الملف ليس خطاً صالحاً (TTF / OTF)")
        }
    }

    // ------------------------------------------------------------------ background editor (welcome + main)

    private fun editBackground(
        title: String,
        current: String,
        prefix: String,
        save: (String) -> Unit,
        delete: () -> Unit
    ) {
        var pending = current
        fun open() {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(4)) }
            box.addView(
                ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setImageDrawable(Backgrounds.load(pending, 1024) ?: ColorDrawable(0xFF000000.toInt()))
                    setBackgroundResource(R.drawable.bg_chip)
                },
                LinearLayout.LayoutParams(-1, dp(170))
            )
            box.addView(note(if (pending.isBlank()) "لا توجد خلفية (الافتراضي)" else "اضغط «حفظ» لاعتماد هذه الخلفية"))
            val dialog = AlertDialog.Builder(this, R.style.GoldDialog)
                .setTitle(title)
                .setView(box)
                .setPositiveButton("حفظ", null)
                .setNeutralButton("تغيير", null)
                .setNegativeButton("حذف", null)
                .create()
            dialog.setOnShowListener {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    if (pending != current) Backgrounds.deleteFile(current)
                    save(pending)
                    refresh()
                    toast("تم الحفظ")
                    dialog.dismiss()
                }
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                    dialog.dismiss()
                    chooseBackground(prefix) { chosen ->
                        if (pending != current && pending != chosen) Backgrounds.deleteFile(pending)
                        pending = chosen
                        open()
                    }
                }
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                    Backgrounds.deleteFile(current)
                    if (pending != current) Backgrounds.deleteFile(pending)
                    delete()
                    refresh()
                    toast("تم الحذف")
                    dialog.dismiss()
                }
            }
            showImmersive(dialog)
        }
        open()
    }

    private fun chooseBackground(prefix: String, onChosen: (String) -> Unit) {
        val items = Backgrounds.names.map { "🎨  $it" } + "📂  اختيار صورة من الاستوديو"
        val dialog = AlertDialog.Builder(this, R.style.GoldDialog)
            .setTitle("اختر خلفية")
            .setItems(items.toTypedArray()) { _, which ->
                if (which < Backgrounds.names.size) {
                    onChosen("builtin:$which")
                } else {
                    imageCallback = { uri ->
                        val value = Backgrounds.importImage(this, uri, prefix)
                        if (value != null) onChosen(value) else toast("تعذر قراءة الصورة")
                    }
                    pickImage.launch("image/*")
                }
            }
            .setNegativeButton("إغلاق", null)
            .create()
        showImmersive(dialog)
    }

    // ------------------------------------------------------------------ app icon

    private fun editIcon() {
        var selected = prefs.appIcon
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(4)) }
        val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val cells = ArrayList<LinearLayout>()
        fun mark() {
            cells.forEachIndexed { i, cell ->
                cell.background = GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setStroke(dp(if (i == selected) 3 else 1), if (i == selected) 0xFFFFFFFF.toInt() else 0x44FFFFFF)
                }
            }
        }
        AppIcons.names.forEachIndexed { i, name ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(8), dp(8), dp(6))
                setTag(R.id.tag_theme_bg, false)
                setOnClickListener {
                    selected = i
                    mark()
                }
            }
            cell.addView(ImageView(this).apply { setImageResource(AppIcons.drawables[i]) }, LinearLayout.LayoutParams(dp(64), dp(64)))
            cell.addView(TextView(this).apply {
                text = name
                textSize = 10f
                gravity = Gravity.CENTER
                setTextColor(0xFFF3E9CF.toInt())
            })
            cells.add(cell)
            strip.addView(cell, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        mark()
        box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(strip) })
        box.addView(note("الأيقونات الملكية تغيّر أيقونة التطبيق على شاشة الهاتف فوراً. وبعض الهواتف تحدّثها بعد ثوانٍ."))

        val dialog = AlertDialog.Builder(this, R.style.GoldDialog)
            .setTitle("أيقونة التطبيق")
            .setView(box)
            .setPositiveButton("حفظ", null)
            .setNeutralButton("صورة من الاستوديو", null)
            .setNegativeButton("استعادة الافتراضي", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                prefs.appIcon = selected
                AppIcons.apply(this, selected)
                toast("تم الحفظ")
                dialog.dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                dialog.dismiss()
                imageCallback = { uri -> customShortcutDialog(uri) }
                pickImage.launch("image/*")
            }
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                prefs.appIcon = 0
                AppIcons.apply(this, 0)
                removeCustomShortcut()
                toast("تمت استعادة الأيقونة الافتراضية")
                dialog.dismiss()
            }
        }
        showImmersive(dialog)
    }

    private fun circleBitmap(uri: Uri): Bitmap? {
        val value = Backgrounds.importImage(this, uri, "icon_tmp") ?: return null
        val file = File(value.removePrefix("file:"))
        val source = Backgrounds.decode(file, 512)
        file.delete()
        if (source == null) return null
        val size = 192
        val side = minOf(source.width, source.height)
        val square = Bitmap.createBitmap(source, (source.width - side) / 2, (source.height - side) / 2, side, side)
        val scaled = Bitmap.createScaledBitmap(square, size, size, true)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(scaled, 0f, 0f, paint)
        return out
    }

    /** Preview of the picture as an icon with save (shortcut) / change / delete. */
    private fun customShortcutDialog(uri: Uri?) {
        val bitmap: Bitmap? = if (uri != null) circleBitmap(uri) else {
            prefs.customIconPath.takeIf { it.isNotBlank() }?.let { Backgrounds.decode(File(it), 192) }
        }
        if (bitmap == null) {
            toast("تعذر قراءة الصورة")
            return
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(20), dp(8), dp(20), dp(4)) }
        box.addView(ImageView(this).apply { setImageBitmap(bitmap) }, LinearLayout.LayoutParams(dp(96), dp(96)))
        box.addView(note("سيُنشأ اختصار على الشاشة الرئيسية للهاتف بهذه الصورة (يطلب الهاتف الموافقة)."))
        val dialog = AlertDialog.Builder(this, R.style.GoldDialog)
            .setTitle("أيقونة مخصصة")
            .setView(box)
            .setPositiveButton("حفظ", null)
            .setNeutralButton("تغيير", null)
            .setNegativeButton("حذف", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val bmp = bitmap ?: return@setOnClickListener
                if (!ShortcutManagerCompat.isRequestPinShortcutSupported(this)) {
                    toast("الهاتف لا يدعم إنشاء اختصار من التطبيق")
                } else {
                    val file = File(filesDir, "custom_icon.png")
                    file.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    prefs.customIconPath = file.absolutePath
                    val info = ShortcutInfoCompat.Builder(this, SHORTCUT_ID)
                        .setShortLabel("Oso Gold TV")
                        .setIcon(IconCompat.createWithBitmap(bmp))
                        .setIntent(Intent(this, SplashActivity::class.java).setAction(Intent.ACTION_MAIN))
                        .build()
                    ShortcutManagerCompat.requestPinShortcut(this, info, null)
                    toast("تم الحفظ")
                }
                dialog.dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                dialog.dismiss()
                imageCallback = { u -> customShortcutDialog(u) }
                pickImage.launch("image/*")
            }
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                removeCustomShortcut()
                toast("تم حذف الأيقونة المخصصة")
                dialog.dismiss()
            }
        }
        showImmersive(dialog)
    }

    private fun removeCustomShortcut() {
        try {
            ShortcutManagerCompat.disableShortcuts(this, listOf(SHORTCUT_ID), "تم حذف الاختصار")
            ShortcutManagerCompat.removeAllDynamicShortcuts(this)
        } catch (_: Exception) {
        }
        if (prefs.customIconPath.isNotBlank()) File(prefs.customIconPath).delete()
        prefs.customIconPath = ""
    }

    // ------------------------------------------------------------------ small builders

    private fun title(text: String, size: Float) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(0xFFFFD86B.toInt())
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun section(text: String) = title(text, 16f).apply { setPadding(0, dp(16), 0, dp(6)) }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(0xFFF3E9CF.toInt())
        setPadding(0, dp(6), 0, 0)
    }

    private fun note(text: String) = TextView(this).apply {
        this.text = text
        textSize = 11f
        setTextColor(0xFFD4AF37.toInt())
        setPadding(0, dp(6), 0, 0)
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        gravity = Gravity.CENTER
        textSize = 15f
        setPadding(dp(16), 0, dp(16), 0)
        setTypeface(typeface, Typeface.BOLD)
        if (primary) {
            setBackgroundResource(R.drawable.bg_gold_button)
            setTextColor(0xFF1A1405.toInt())
        } else {
            setBackgroundResource(R.drawable.bg_chip)
            setTextColor(0xFFFFD86B.toInt())
        }
        setOnClickListener { onClick() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val SHORTCUT_ID = "oso_custom_icon"
    }
}
