package com.osogold.tv

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * Taps the PCM audio that ExoPlayer is about to play (before the speakers), converts it to 16 kHz mono
 * and hands it to [sink]. The audio itself passes through untouched.
 */
class PcmTap(private val sink: (ShortArray) -> Unit) : BaseAudioProcessor() {

    private var rate = 48000
    private var channels = 2
    private val buffer = ShortArray(1600)
    private var filled = 0
    private var acc = 0.0
    private var count = 0
    private var phase = 0.0

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) return AudioProcessor.AudioFormat.NOT_SET
        rate = inputAudioFormat.sampleRate.coerceAtLeast(8000)
        channels = inputAudioFormat.channelCount.coerceAtLeast(1)
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val view = inputBuffer.duplicate().order(ByteOrder.nativeOrder()).asShortBuffer()
        try {
            val frames = view.remaining() / channels
            val step = 16000.0 / rate
            for (f in 0 until frames) {
                var sum = 0
                for (c in 0 until channels) sum += view.get()
                acc += sum.toDouble() / channels
                count++
                phase += step
                if (phase >= 1.0) {
                    phase -= 1.0
                    buffer[filled++] = (acc / count).toInt().coerceIn(-32768, 32767).toShort()
                    acc = 0.0
                    count = 0
                    if (filled == buffer.size) {
                        sink(buffer.copyOf())
                        filled = 0
                    }
                }
            }
        } catch (_: Throwable) {
        }
        val out = replaceOutputBuffer(size)
        out.put(inputBuffer)
        out.flip()
    }
}

/** A muted, video-less second player at the live edge whose only job is to feed the translator. */
class TapPlayer(private val context: Context, private val tap: PcmTap) {

    var player: ExoPlayer? = null
        private set

    fun start(url: String, startAtMs: Long) {
        release()
        val renderers = object : DefaultRenderersFactory(context) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink? = DefaultAudioSink.Builder(context)
                .setAudioProcessors(arrayOf<AudioProcessor>(tap))
                .build()
        }
        val p = ExoPlayer.Builder(context, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(NetConfig.dataSourceFactory(context)))
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_SPEECH).build(),
                false
            )
            .build()
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
            .setForceLowestBitrate(true)
            .build()
        p.volume = 0f
        p.setMediaItem(MediaItem.fromUri(url))
        if (startAtMs > 0) p.seekTo(startAtMs)
        p.prepare()
        p.playWhenReady = true
        player = p
    }

    fun release() {
        try { player?.release() } catch (_: Throwable) {}
        player = null
    }
}

/**
 * AI Live subtitles (translation to Arabic).
 *
 * How the lip-sync works: the picture the user sees is played [delay] seconds behind the live edge
 * (the buffer lives only in RAM), while a hidden audio-only copy of the stream runs at the live edge
 * and feeds the speech engine. The translation therefore has [delay] seconds to be produced, and it is
 * shown exactly when the same words are heard on screen. Nothing is written to the phone.
 *
 * Engines: free = on-device Android speech recognition + Google ML Kit translation (tr, de, en, fr, es);
 * high accuracy = Gemini (key saved in Settings) - any language incl. Kurdish, Modern Standard Arabic.
 * Any failure only affects the subtitles: the video is never touched.
 */
class LiveSubtitleManager(
    private val context: Context,
    private val prefs: Prefs,
    private val host: Host
) {

    interface Host {
        fun mainPlayer(): Player?
        fun streamUrl(): String?
        fun isVlc(): Boolean
        fun overlayRoot(): FrameLayout
        fun toast(text: String)

        /** Lowers / restores the original channel sound while the dubbing speaks (1f = normal). */
        fun setChannelVolume(volume: Float) {}
    }

    private val dubber = LiveDubber(context, prefs) { host.setChannelVolume(it) }
    private val main = Handler(Looper.getMainLooper())
    private val net = Executors.newSingleThreadExecutor()
    private val pipeExec = Executors.newSingleThreadExecutor()
    private val pipeQueue = AtomicInteger(0)

    var active = false
        private set
    private var subsPaused = false
    private var shiftMs = 0L
    private var lastCcAt = 0L
    private var overlay: TextView? = null
    private var tapPlayer: TapPlayer? = null
    private var generation = 0
    private var measuredDelayMs = -1L
    private var usingKey = false

    // chunk collector (key engine)
    private val chunk = ByteArrayOutputStream()
    private var chunkStart = 0L
    private var quietSamples = 0

    // free engine
    private var recognizer: SpeechRecognizer? = null
    private var pipeOut: OutputStream? = null
    private var freeLang = "en"
    private var lastPartial = ""
    private var lastPartialAt = 0L

    private val translators = HashMap<String, Translator>()

    // ------------------------------------------------------------------ start / stop

    fun toggle() {
        if (active) stop() else start()
    }

    fun start() {
        if (active) return
        val url = host.streamUrl()
        if (url.isNullOrBlank()) {
            host.toast("شغّل قناة أو فيلماً أولاً")
            return
        }
        active = true
        subsPaused = false
        keyErrorShown = false
        usingKey = AiKeys.hasGemini(prefs)
        ensureOverlay()
        if (prefs.dubEnabled) dubber.start()
        host.toast(if (usingKey) "الترجمة الفورية فائقة الدقة (AI)" else "الترجمة الفورية المجانية (Google ML Kit)")
        launchPipeline(url)
    }

    fun stop() {
        active = false
        dubber.stop()
        generation++
        main.removeCallbacksAndMessages(null)
        tapPlayer?.release()
        tapPlayer = null
        stopFree()
        chunk.reset()
        overlay?.visibility = View.GONE
        for (t in translators.values) try { t.close() } catch (_: Throwable) {}
        translators.clear()
        // bring the picture back to the live edge
        try {
            host.mainPlayer()?.let { if (it.isCurrentMediaItemLive) it.seekToDefaultPosition() }
        } catch (_: Throwable) {}
    }

    /** The channel / movie changed: restart the hidden player on the new address. */
    fun onStreamChanged() {
        if (!active) return
        val url = host.streamUrl() ?: return
        generation++
        tapPlayer?.release()
        stopFree()
        chunk.reset()
        launchPipeline(url)
    }

    private fun delayMs(): Long = prefs.liveSubDelay * 1000L

    private fun launchPipeline(url: String) {
        val gen = generation
        measuredDelayMs = -1L
        try {
            val m = host.mainPlayer()
            val d = delayMs()
            var tapStart = 0L
            if (m != null) {
                if (m.isCurrentMediaItemLive) {
                    val offset = m.currentLiveOffset
                    if (offset != C.TIME_UNSET && offset < d) {
                        m.seekTo((m.currentPosition - (d - offset)).coerceAtLeast(0L))
                    }
                } else {
                    tapStart = m.currentPosition + d
                }
            }
            if (!usingKey) startFree(sourceLanguage())
            val tap = PcmTap { pcm -> if (gen == generation) onPcm(pcm) }
            val tp = TapPlayer(context, tap)
            tapPlayer = tp
            tp.start(url, tapStart)
            tp.player?.addListener(object : Player.Listener {
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    if (gen == generation) host.toast("تعذّر تحليل الصوت لهذه القناة — يستمر الفيديو بدون ترجمة")
                }
            })
            main.postDelayed(object : Runnable {
                override fun run() {
                    if (gen != generation || !active) return
                    calibrate()
                    main.postDelayed(this, 2000L)
                }
            }, 3000L)
        } catch (e: Throwable) {
            host.toast("تعذّر تشغيل الترجمة: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** Real distance between the picture and the hidden live-edge copy. */
    private fun calibrate() {
        try {
            val m = host.mainPlayer() ?: return
            val t = tapPlayer?.player ?: return
            // the VOD copy pauses together with the movie
            if (!m.isCurrentMediaItemLive) {
                val moving = m.isPlaying || m.playbackState == Player.STATE_BUFFERING
                if (t.playWhenReady != moving) t.playWhenReady = moving
            }
            val a = m.currentLiveOffset
            val b = t.currentLiveOffset
            measuredDelayMs = if (a != C.TIME_UNSET && b != C.TIME_UNSET) (a - b).coerceAtLeast(0L) else -1L
        } catch (_: Throwable) {
        }
    }

    private fun effectiveDelay(): Long = if (measuredDelayMs >= 0) measuredDelayMs else delayMs()

    // ------------------------------------------------------------------ audio in

    private fun onPcm(pcm: ShortArray) {
        if (prefs.dubEnabled) dubber.observe(pcm)
        if (usingKey) feedChunk(pcm) else feedFree(pcm)
    }

    // ---- high accuracy engine: chunks of speech -> Gemini

    private fun feedChunk(pcm: ShortArray) {
        if (chunk.size() == 0) {
            chunkStart = SystemClock.elapsedRealtime()
            quietSamples = 0
        }
        var energy = 0.0
        val bytes = ByteArray(pcm.size * 2)
        for (i in pcm.indices) {
            val v = pcm[i].toInt()
            bytes[i * 2] = (v and 0xFF).toByte()
            bytes[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
            energy += (v * v).toDouble()
        }
        chunk.write(bytes)
        val rms = Math.sqrt(energy / pcm.size)
        quietSamples = if (rms < 350) quietSamples + pcm.size else 0
        val seconds = chunk.size() / 32000.0
        val cut = (seconds >= 4.0 && quietSamples >= 5000) || seconds >= 9.0
        if (cut) {
            val data = chunk.toByteArray()
            val start = chunkStart
            chunk.reset() // the buffer is wiped every few seconds
            val gen = generation
            val loud = data.size > 32000 && averageRms(data) > 250
            if (loud) {
                net.execute { if (gen == generation) translateChunk(data, start, seconds, gen) }
            }
        }
    }

    private fun averageRms(data: ByteArray): Double {
        var e = 0.0
        var n = 0
        var i = 0
        while (i + 1 < data.size) {
            val v = ((data[i + 1].toInt() shl 8) or (data[i].toInt() and 0xFF)).toShort().toInt()
            e += (v * v).toDouble()
            n++
            i += 20
        }
        return if (n == 0) 0.0 else Math.sqrt(e / n)
    }

    private fun translateChunk(pcm: ByteArray, startWall: Long, seconds: Double, gen: Int) {
        try {
            val wav = wav(pcm)
            val prompt = "Listen to this audio. The speech may be German, Turkish, English, French, Spanish, " +
                "Kurdish (Kurmanji or Sorani) or any other language or dialect. Translate EVERYTHING that is said " +
                "into complete, correct Modern Standard Arabic (العربية الفصحى), keeping every word and meaning, " +
                "without omitting, shortening or summarising anything. " + dialectNote() +
                "Output ONLY the Arabic translation. " +
                "If there is no speech, output nothing."
            val text = gemini(
                JSONArray()
                    .put(JSONObject().put("text", prompt))
                    .put(JSONObject().put("inline_data", JSONObject()
                        .put("mime_type", "audio/wav")
                        .put("data", Base64.encodeToString(wav, Base64.NO_WRAP))))
            )
            if (gen != generation || text.isNullOrBlank()) return
            scheduleText(text.trim(), startWall, (seconds * 1000).toLong())
        } catch (e: Throwable) {
            keyFailed(e)
        }
    }

    private var keyErrorShown = false
    private fun dialectNote(): String =
        if (prefs.dubEnabled && prefs.dubDialect == 1)
            "Write it in natural Syrian Levantine (Shami) dialect, like a Syrian TV drama dub, instead of Modern Standard Arabic. "
        else ""

    private fun keyFailed(e: Throwable) {
        val code = (e as? java.io.IOException)?.message.orEmpty()
        if (code.contains("401") || code.contains("403") || code.contains("400")) {
            if (!keyErrorShown) {
                keyErrorShown = true
                main.post { host.toast("مفتاح الذكاء الاصطناعي غير صالح — راجع الإعدادات. تم التحويل للترجمة المجانية") }
            }
            main.post {
                if (active) {
                    usingKey = false
                    startFree(sourceLanguage())
                }
            }
        }
    }

    private fun wav(pcm: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        fun int(v: Int) { out.write(v and 0xFF); out.write((v shr 8) and 0xFF); out.write((v shr 16) and 0xFF); out.write((v shr 24) and 0xFF) }
        fun short(v: Int) { out.write(v and 0xFF); out.write((v shr 8) and 0xFF) }
        out.write("RIFF".toByteArray()); int(36 + pcm.size); out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray()); int(16); short(1); short(1); int(16000); int(32000); short(2); short(16)
        out.write("data".toByteArray()); int(pcm.size); out.write(pcm)
        return out.toByteArray()
    }

    /** One Gemini call. [parts] is the "parts" array. Throws IOException("HTTP code") on failure. */
    private fun gemini(parts: JSONArray): String? {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0.2))
            .toString()
        var lastError: java.io.IOException? = null
        for (key in AiKeys.usable(AiKeys.geminiKeys(prefs))) {
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent")
                .header("x-goog-api-key", key)
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()
            try {
                return NetConfig.client().newCall(request).execute().use { r ->
                    val text = r.body?.string().orEmpty()
                    if (!r.isSuccessful) {
                        // free quota finished / key refused -> the next of the five keys, automatically
                        AiKeys.markKeyProblem(key)
                        throw java.io.IOException("HTTP ${r.code}")
                    }
                    val parts = JSONObject(text).optJSONArray("candidates")?.optJSONObject(0)
                        ?.optJSONObject("content")?.optJSONArray("parts")
                    if (parts == null) null
                    else {
                        val sb = StringBuilder()
                        for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text").orEmpty())
                        sb.toString()
                    }
                }
            } catch (e: java.io.IOException) {
                lastError = e
            }
        }
        throw lastError ?: java.io.IOException("no key")
    }

    // ---- free engine: Android speech recognition + ML Kit

    private fun sourceLanguage(): String {
        val chosen = prefs.liveSubLang
        if (chosen != "auto") return chosen
        val fromTrack = try { PlaybackService.instance?.exo()?.audioFormat?.language } catch (_: Throwable) { null }
        val code = fromTrack?.lowercase()?.take(2)
        return if (code in setOf("tr", "de", "en", "fr", "es")) code!! else "en"
    }

    private fun mlLang(code: String): String? = when (code) {
        "tr" -> TranslateLanguage.TURKISH
        "de" -> TranslateLanguage.GERMAN
        "en" -> TranslateLanguage.ENGLISH
        "fr" -> TranslateLanguage.FRENCH
        "es" -> TranslateLanguage.SPANISH
        else -> null
    }

    private fun tag(code: String) = when (code) {
        "tr" -> "tr-TR"
        "de" -> "de-DE"
        "fr" -> "fr-FR"
        "es" -> "es-ES"
        else -> "en-US"
    }

    private fun startFree(lang: String) {
        stopFree()
        freeLang = if (lang == "ku") "en" else lang
        if (Build.VERSION.SDK_INT < 33 || !SpeechRecognizer.isRecognitionAvailable(context)) {
            host.toast("الترجمة المجانية تحتاج أندرويد 13+ ومحرك تعرّف صوتي، أو أضف مفتاح AI في الإعدادات")
            return
        }
        listenFree()
    }

    private fun listenFree() {
        if (!active || usingKey) return
        try {
            val pipe = ParcelFileDescriptor.createPipe()
            pipeOut = ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])
            val rec = SpeechRecognizer.createSpeechRecognizer(context)
            recognizer = rec
            rec.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onPartialResults(partial: Bundle?) = handleFree(partial, false)
                override fun onResults(results: Bundle?) {
                    handleFree(results, true)
                    restartFree()
                }
                override fun onError(error: Int) = restartFree()
            })
            val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag(freeLang))
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra("android.speech.extra.AUDIO_SOURCE", pipe[0])
                .putExtra("android.speech.extra.AUDIO_SOURCE_SAMPLING_RATE", 16000)
                .putExtra("android.speech.extra.AUDIO_SOURCE_CHANNEL_COUNT", 1)
                .putExtra("android.speech.extra.AUDIO_SOURCE_ENCODING", android.media.AudioFormat.ENCODING_PCM_16BIT)
            rec.startListening(intent)
        } catch (e: Throwable) {
            host.toast("تعذّر تشغيل التعرف الصوتي المجاني")
        }
    }

    private fun restartFree() {
        val gen = generation
        main.postDelayed({
            if (gen == generation && active && !usingKey) {
                closeRecognizer()
                listenFree()
            }
        }, 250L)
    }

    private fun closeRecognizer() {
        try { recognizer?.destroy() } catch (_: Throwable) {}
        recognizer = null
        try { pipeOut?.close() } catch (_: Throwable) {}
        pipeOut = null
    }

    private fun stopFree() {
        closeRecognizer()
    }

    private fun feedFree(pcm: ShortArray) {
        val out = pipeOut ?: return
        if (pipeQueue.get() > 40) return
        val bytes = ByteArray(pcm.size * 2)
        for (i in pcm.indices) {
            bytes[i * 2] = (pcm[i].toInt() and 0xFF).toByte()
            bytes[i * 2 + 1] = ((pcm[i].toInt() shr 8) and 0xFF).toByte()
        }
        pipeQueue.incrementAndGet()
        pipeExec.execute {
            try { out.write(bytes) } catch (_: Throwable) {} finally { pipeQueue.decrementAndGet() }
        }
    }

    private fun handleFree(bundle: Bundle?, final: Boolean) {
        val text = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
        if (text.isEmpty()) return
        val now = SystemClock.elapsedRealtime()
        if (!final && (text == lastPartial || now - lastPartialAt < 800)) return
        lastPartial = if (final) "" else text
        lastPartialAt = now
        translateFree(text, now)
    }

    private fun translateFree(text: String, wall: Long) {
        val lang = mlLang(freeLang) ?: return
        val key = freeLang
        try {
            val translator = translators.getOrPut(key) {
                Translation.getClient(
                    TranslatorOptions.Builder().setSourceLanguage(lang).setTargetLanguage(TranslateLanguage.ARABIC).build()
                )
            }
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
                .addOnSuccessListener {
                    translator.translate(text)
                        .addOnSuccessListener { ar -> if (active) scheduleText(ar, wall, 3500L) }
                        .addOnFailureListener { }
                }
                .addOnFailureListener { host.toast("تعذّر تحميل نموذج الترجمة المجانية — تحقق من الإنترنت") }
        } catch (_: Throwable) {
        }
    }

    // ------------------------------------------------------------------ embedded captions (CC / DVB)

    /** Text of a closed caption / DVB subtitle of the channel: translated and shown at once (it is already in sync). */
    fun onEmbeddedCue(text: String) {
        if (!active || subsPaused || text.isBlank()) return
        lastCcAt = SystemClock.elapsedRealtime()
        val clean = text.trim()
        net.execute {
            try {
                val ar = if (AiKeys.hasAny(prefs)) AiKeys.complete(
                    prefs,
                    "Translate to " + (if (prefs.dubEnabled && prefs.dubDialect == 1) "natural Syrian Levantine (Shami) dialect as spoken in Syrian drama" else "complete correct Modern Standard Arabic") + ", no omissions. Output only the translation:\n$clean"
                ) else null
                if (ar != null) main.post { showNow(ar.trim(), 4500L) }
                else main.post { translateEmbeddedFree(clean) }
            } catch (_: Throwable) {
                main.post { translateEmbeddedFree(clean) }
            }
        }
    }

    private fun translateEmbeddedFree(text: String) {
        val lang = mlLang(sourceLanguage()) ?: return
        try {
            val translator = translators.getOrPut("cc_" + sourceLanguage()) {
                Translation.getClient(
                    TranslatorOptions.Builder().setSourceLanguage(lang).setTargetLanguage(TranslateLanguage.ARABIC).build()
                )
            }
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).addOnSuccessListener {
                translator.translate(text).addOnSuccessListener { showNow(it, 4500L) }
            }
        } catch (_: Throwable) {
        }
    }

    // ------------------------------------------------------------------ showing

    /** Shows [text] when its words are heard on screen: capture time + delay + manual shift. */
    private fun scheduleText(text: String, captureWall: Long, spanMs: Long) {
        if (SystemClock.elapsedRealtime() - lastCcAt < 10_000L) return // real captions win
        val pieces = splitPieces(text)
        val total = pieces.sumOf { it.length }.coerceAtLeast(1)
        var offset = 0L
        for (piece in pieces) {
            val share = (spanMs * piece.length / total).coerceAtLeast(1800L)
            val showAt = captureWall + effectiveDelay() + shiftMs + offset
            val wait = (showAt - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
            val gen = generation
            main.postDelayed({ if (gen == generation && active && !subsPaused) showNow(piece, share + 400L) }, wait)
            offset += share
        }
    }

    private fun splitPieces(text: String): List<String> {
        val sentences = text.split(Regex("(?<=[.!?؟،,;])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        var current = ""
        for (s in sentences) {
            if (current.isNotEmpty() && (current.length + s.length) > 90) {
                out.add(current)
                current = s
            } else {
                current = if (current.isEmpty()) s else "$current $s"
            }
        }
        if (current.isNotEmpty()) out.add(current)
        return if (out.isEmpty()) listOf(text) else out
    }

    private val hideTask = Runnable { overlay?.visibility = View.GONE }

    private fun showNow(text: String, holdMs: Long) {
        if (prefs.dubEnabled && active) dubber.speak(text)
        val tv = ensureOverlay()
        tv.text = text
        styleOverlay(tv)
        tv.visibility = View.VISIBLE
        tv.bringToFront()
        main.removeCallbacks(hideTask)
        main.postDelayed(hideTask, holdMs.coerceIn(2500L, 12000L))
    }

    private fun ensureOverlay(): TextView {
        overlay?.let { return it }
        val tv = TextView(context).apply {
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
            setBackgroundColor(0x88000000.toInt())
            val d = context.resources.displayMetrics.density
            setPadding((10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt())
            visibility = View.GONE
            elevation = 60f
        }
        host.overlayRoot().addView(
            tv,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        overlay = tv
        styleOverlay(tv)
        return tv
    }

    fun styleOverlay(tv: TextView? = overlay) {
        val v = tv ?: return
        v.textSize = when (prefs.liveSubSize) { 0 -> 14f; 2 -> 26f; else -> 19f }
        v.setTextColor(prefs.liveSubColor)
        val d = context.resources.displayMetrics.density
        val lp = v.layoutParams as FrameLayout.LayoutParams
        lp.gravity = (if (prefs.liveSubPos == 1) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        lp.topMargin = (28 * d).toInt()
        lp.bottomMargin = (28 * d).toInt()
        v.layoutParams = lp
    }

    // ------------------------------------------------------------------ manual controls

    fun togglePauseSubs(): Boolean {
        subsPaused = !subsPaused
        if (subsPaused) overlay?.visibility = View.GONE
        return subsPaused
    }

    fun nudge(ms: Long) {
        shiftMs += ms
        host.toast("إزاحة الترجمة: " + String.format("%+.1f", shiftMs / 1000.0) + " ث")
    }

    fun toggleLivePause() {
        val m = host.mainPlayer() ?: return
        if (m.isPlaying || m.playWhenReady) m.pause() else m.play()
    }

    // ------------------------------------------------------------------ quick panel

    fun showPanel(ctx: Context) {
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val dialog = Dialog(ctx)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setGravity(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_overlay)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun label(t: String) = TextView(ctx).apply {
            text = t; setTextColor(ctx.getColor(R.color.gold_light)); textSize = 12f
            setPadding(0, dp(6), 0, dp(2))
        }
        fun chip(t: String, selected: Boolean, onClick: () -> Unit) = TextView(ctx).apply {
            text = t; textSize = 12f; gravity = Gravity.CENTER
            setTextColor(if (selected) Color.BLACK else Color.WHITE)
            setBackgroundColor(if (selected) Color.parseColor("#FFD4AF37") else 0x33FFFFFF)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(dp(3), dp(2), dp(3), dp(2)) }
        }
        fun scrollRow(): Pair<HorizontalScrollView, LinearLayout> {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            val sv = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(row) }
            return sv to row
        }

        val status = TextView(ctx).apply {
            textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            text = (if (active) "● الترجمة تعمل — " else "○ الترجمة متوقفة — ") +
                if (AiKeys.hasGemini(prefs)) "محرك AI فائق الدقة" else "محرك Google ML Kit المجاني"
        }
        box.addView(status)

        // main buttons
        val (sv0, row0) = scrollRow()
        row0.addView(chip(if (active) "⏹ إيقاف الترجمة" else "▶ تشغيل الترجمة", false) {
            toggle(); dialog.dismiss()
        })
        row0.addView(chip(if (subsPaused) "▶ استئناف الترجمة" else "⏸ إيقاف مؤقت للترجمة", false) {
            val p = togglePauseSubs(); host.toast(if (p) "الترجمة متوقفة مؤقتاً" else "الترجمة تعمل")
            dialog.dismiss()
        })
        row0.addView(chip("⏯ تجميد/تشغيل البث", false) { toggleLivePause() })
        row0.addView(chip("−0.5 ث", false) { nudge(-500) })
        row0.addView(chip("+0.5 ث", false) { nudge(500) })
        box.addView(sv0)

        box.addView(label("حجم الخط"))
        val (sv1, row1) = scrollRow()
        listOf("صغير", "متوسط", "كبير").forEachIndexed { i, t ->
            row1.addView(chip(t, prefs.liveSubSize == i) { prefs.liveSubSize = i; styleOverlay(); preview("نص تجريبي للترجمة"); dialog.dismiss() })
        }
        row1.addView(chip("أعلى", prefs.liveSubPos == 1) { prefs.liveSubPos = 1; styleOverlay(); preview("نص تجريبي للترجمة"); dialog.dismiss() })
        row1.addView(chip("أسفل", prefs.liveSubPos == 0) { prefs.liveSubPos = 0; styleOverlay(); preview("نص تجريبي للترجمة"); dialog.dismiss() })
        box.addView(sv1)

        box.addView(label("لون الترجمة"))
        val (sv2, row2) = scrollRow()
        listOf("#FFFFFF", "#FFD700", "#FFEB3B", "#4FC3F7", "#81C784", "#FF8A65", "#F48FB1", "#CE93D8").forEach { hex ->
            val c = Color.parseColor(hex)
            row2.addView(TextView(ctx).apply {
                setBackgroundColor(c)
                text = if (prefs.liveSubColor == c) "✔" else ""
                gravity = Gravity.CENTER; setTextColor(Color.BLACK)
                setOnClickListener { prefs.liveSubColor = c; styleOverlay(); preview("نص تجريبي للترجمة"); dialog.dismiss() }
                layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(dp(4), dp(2), dp(4), dp(2)) }
            })
        }
        box.addView(sv2)

        box.addView(label("لغة الصوت (المحرك المجاني) — الذكاء الاصطناعي يكتشفها تلقائياً"))
        val (sv3, row3) = scrollRow()
        listOf("auto" to "تلقائي", "tr" to "التركية", "de" to "الألمانية", "en" to "الإنجليزية", "fr" to "الفرنسية", "es" to "الإسبانية").forEach { (code, name) ->
            row3.addView(chip(name, prefs.liveSubLang == code) {
                prefs.liveSubLang = code; dialog.dismiss(); if (active) onStreamChanged()
            })
        }
        box.addView(sv3)

        val syncLabel = label("التخزين المؤقت الذكي / مزامنة الشفاه: ${prefs.liveSubDelay} ثانية (5 – 60)")
        box.addView(syncLabel)
        box.addView(SeekBar(ctx).apply {
            max = 55; progress = prefs.liveSubDelay - 5
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    if (fromUser) syncLabel.text = "التخزين المؤقت الذكي / مزامنة الشفاه: ${v + 5} ثانية (5 – 60)"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    prefs.liveSubDelay = (s?.progress ?: 10) + 5
                    if (active) onStreamChanged()
                }
            })
        })
        // ---- AI Dubbing
        box.addView(label("الدبلجة الفورية الذكية (AI Dubbing) — نطق الترجمة بصوت يناسب المتحدث"))
        val (svD, rowD) = scrollRow()
        rowD.addView(chip(if (prefs.dubEnabled) "الدبلجة: مفعّلة ✓" else "تفعيل الدبلجة الفورية", prefs.dubEnabled) {
            prefs.dubEnabled = !prefs.dubEnabled
            if (prefs.dubEnabled) {
                if (active) dubber.start()
                if (!active) start()
            } else dubber.stop()
            dialog.dismiss()
        })
        rowD.addView(chip("العربية الفصحى", prefs.dubDialect == 0) { prefs.dubDialect = 0; dialog.dismiss() })
        rowD.addView(chip("اللهجة السورية / الشامية", prefs.dubDialect == 1) { prefs.dubDialect = 1; dialog.dismiss() })
        box.addView(svD)
        val duckLabel = label("صوت القناة الأصلي أثناء الدبلجة: ${prefs.dubDuck}%")
        box.addView(duckLabel)
        box.addView(SeekBar(ctx).apply {
            max = 100; progress = prefs.dubDuck
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    if (fromUser) { duckLabel.text = "صوت القناة الأصلي أثناء الدبلجة: $v%"; prefs.dubDuck = v }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        box.addView(TextView(ctx).apply {
            text = "الصوت المستخدم الآن: " + dubber.currentVoice().label + "  (يُحلَّل تردد صوت المتحدث تلقائياً)"
            setTextColor(0xAAFFFFFF.toInt()); textSize = 10f; gravity = Gravity.CENTER
        })
        box.addView(TextView(ctx).apply {
            text = "يُحفظ البث مؤقتاً في الذاكرة فقط ويُمسح تلقائياً، ولا يُكتب أي ملف على الهاتف."
            setTextColor(0xAAFFFFFF.toInt()); textSize = 10f; gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        })
        dialog.setContentView(box)
        dialog.window?.setLayout(
            minOf(dp(520), ctx.resources.displayMetrics.widthPixels - dp(16)),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        dialog.show()
    }

    private fun preview(text: String) {
        if (active) showNow(text, 2500L)
    }
}
